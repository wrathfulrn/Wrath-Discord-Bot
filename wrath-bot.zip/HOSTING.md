# Hosting

## Local

```bash
npm run build && npm start
```

## VPS / panel

1. Install Node 20+.
2. Clone the repo, copy `.env.example` → `.env`, fill secrets.
3. `npm install && npm run build`.
4. Run with a process manager (systemd, pm2, Docker).

Example pm2:

```bash
pm2 start dist/src/index.js --name wrath
```

Keep `data/` on persistent storage so economy and settings survive restarts.

## Discord privileges

Invite the bot with the permissions your modules need (Manage Messages, Kick, Ban, Manage Channels, Connect/Speak for voice, etc.). Prefer least privilege over Administrator when you can.
