# Feature map

High-level list of systems shipped in this repository.

## Security
Automod, antiraid, antinuke whitelist config, channel logging, autoresponders, counting channels.

## Server
Welcome and goodbye messages, setup roles, join alerts, announcements, bump reminders, command aliases.

## Roles
Reaction roles, fake permissions for staff commands, booster role config.

## Engagement
Levels / rank, starboard, giveaways, community (marry, AFK, family), fun utilities.

## Economy & games
Balance, work, daily, shop, crafting, jobs, farm, pets, war, lottery, gambling.

## Music
Queue commands and a transition planner. Real dual-deck audio needs your own Lavalink setup.

## AI
`,ask` using Google Gemini (OpenAI-compatible endpoint).

## Scripts
Named message/embed templates with variables like `{user.name}` and `{guild.name}`.

## Workflows
Simple trigger → action rules (join, leave, message, level-up).
