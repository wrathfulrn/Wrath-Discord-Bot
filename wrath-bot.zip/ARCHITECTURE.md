# Architecture

Wrath runs as a single Node process using Discordeno.

## Design choices

- **One declaration per command** for prefix (and slash where registered).
- **JSON file store** (`data/wrath.json`) for economy and guild settings — fine for small/medium bots.
- **Single-flight cache** (`src/utils/remember.ts`) so concurrent misses share one fetch.
- **REST retries** (`src/utils/rest.ts`) for 429 and selected 5xx responses.
- **Slash auto-defer** after ~2s so slow handlers do not expire.

## Scaling later

If you outgrow one process:

1. Measure lag and rate limits.
2. Split gateway from command workers if needed.
3. Move the store to Postgres or Redis.
4. Shard by Discord’s shard count when you approach large guild totals.

## Command limits

Discord allows 100 global slash commands and 25 subcommands per group. The loader enforces group size. The data-driven pack fills many utility names without exploding slash registration.
