import type { UserLike } from "./utils/users.js";

/** The bot's own user, filled in when the gateway reports ready. Used for the help avatar. */
export const botState: { user?: UserLike } = {};
