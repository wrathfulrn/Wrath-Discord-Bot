import type { KvKey } from "./store.js";
import { kv, mutate } from "./index.js";

const key = (guildId: string, part: string): KvKey => ["guild", guildId, part];

export interface AutomodConfig {
  enabled: boolean;
  blockInvites: boolean;
  maxMentions: number;
  maxLines: number;
  maxEmoji: number;
  punish: "delete" | "timeout" | "warn";
  timeoutSeconds: number;
  ignoredChannels: string[];
  ignoredRoles: string[];
}

export interface AntiraidConfig {
  enabled: boolean;
  joinThreshold: number;
  windowSeconds: number;
  action: "kick" | "ban" | "timeout" | "alert";
  alertChannelId?: string;
  timeoutSeconds: number;
}

export interface AntinukeConfig {
  enabled: boolean;
  whitelist: string[]; // user ids
  punish: "ban" | "kick" | "strip";
  logChannelId?: string;
}

export interface StarboardConfig {
  enabled: boolean;
  channelId?: string;
  emoji: string;
  minStars: number;
}

export interface LogConfig {
  enabled: boolean;
  channelId?: string;
  mod: boolean;
  message: boolean;
  member: boolean;
}

export interface LevelConfig {
  enabled: boolean;
  xpPerMessage: number;
  cooldownMs: number;
  announceChannelId?: string;
}

export interface CountingConfig {
  enabled: boolean;
  channelId?: string;
  next: number;
  lastUserId?: string;
}

export interface Autoresponse {
  trigger: string;
  response: string;
  exact: boolean;
}

const defaultAutomod = (): AutomodConfig => ({
  enabled: false,
  blockInvites: true,
  maxMentions: 5,
  maxLines: 20,
  maxEmoji: 15,
  punish: "delete",
  timeoutSeconds: 60,
  ignoredChannels: [],
  ignoredRoles: [],
});

const defaultAntiraid = (): AntiraidConfig => ({
  enabled: true,
  joinThreshold: 8,
  windowSeconds: 12,
  action: "alert",
  timeoutSeconds: 300,
});

const defaultAntinuke = (): AntinukeConfig => ({
  enabled: false,
  whitelist: [],
  punish: "ban",
});

const defaultStarboard = (): StarboardConfig => ({
  enabled: false,
  emoji: "⭐",
  minStars: 3,
});

const defaultLog = (): LogConfig => ({
  enabled: false,
  mod: true,
  message: false,
  member: true,
});

const defaultLevels = (): LevelConfig => ({
  enabled: true,
  xpPerMessage: 15,
  cooldownMs: 60_000,
});

const defaultCounting = (): CountingConfig => ({
  enabled: false,
  next: 1,
});

async function get<T>(guildId: string, part: string, empty: () => T): Promise<T> {
  return (await kv.get<T>(key(guildId, part))).value ?? empty();
}

async function set<T>(guildId: string, part: string, value: T): Promise<void> {
  await kv.atomic().set(key(guildId, part), value).commit();
}

export const guildConfig = {
  getAutomod: (g: string) => get(g, "automod", defaultAutomod),
  setAutomod: (g: string, v: AutomodConfig) => set(g, "automod", v),
  getAntiraid: (g: string) => get(g, "antiraid", defaultAntiraid),
  setAntiraid: (g: string, v: AntiraidConfig) => set(g, "antiraid", v),
  getAntinuke: (g: string) => get(g, "antinuke", defaultAntinuke),
  setAntinuke: (g: string, v: AntinukeConfig) => set(g, "antinuke", v),
  getStarboard: (g: string) => get(g, "starboard", defaultStarboard),
  setStarboard: (g: string, v: StarboardConfig) => set(g, "starboard", v),
  getLog: (g: string) => get(g, "log", defaultLog),
  setLog: (g: string, v: LogConfig) => set(g, "log", v),
  getLevels: (g: string) => get(g, "levels", defaultLevels),
  setLevels: (g: string, v: LevelConfig) => set(g, "levels", v),
  getCounting: (g: string) => get(g, "counting", defaultCounting),
  setCounting: (g: string, v: CountingConfig) => set(g, "counting", v),
  getAutoresponses: async (g: string) =>
    (await kv.get<Autoresponse[]>(key(g, "autorespond"))).value ?? [],
  setAutoresponses: (g: string, v: Autoresponse[]) => set(g, "autorespond", v),
};

export interface UserLevel {
  xp: number;
  level: number;
  lastXpAt: number;
}

export async function getUserLevel(guildId: string, userId: string): Promise<UserLevel> {
  return (
    (await kv.get<UserLevel>(["levels", guildId, userId])).value ?? {
      xp: 0,
      level: 0,
      lastXpAt: 0,
    }
  );
}

export async function addMessageXp(
  guildId: string,
  userId: string,
  amount: number,
  cooldownMs: number,
): Promise<{ leveled: boolean; level: number; xp: number } | null> {
  const k: KvKey = ["levels", guildId, userId];
  let result: { leveled: boolean; level: number; xp: number } | null = null;
  await mutate<UserLevel>(
    k,
    () => ({ xp: 0, level: 0, lastXpAt: 0 }),
    (u) => {
      if (Date.now() - u.lastXpAt < cooldownMs) return false;
      u.lastXpAt = Date.now();
      u.xp += amount;
      const need = (u.level + 1) * 100;
      let leveled = false;
      while (u.xp >= need) {
        u.xp -= need;
        u.level += 1;
        leveled = true;
      }
      result = { leveled, level: u.level, xp: u.xp };
      return true;
    },
  );
  return result;
}

export interface Giveaway {
  id: string;
  channelId: string;
  messageId: string;
  prize: string;
  endsAt: number;
  winners: number;
  hostId: string;
  entries: string[];
  ended: boolean;
}

export async function saveGiveaway(g: Giveaway): Promise<void> {
  await kv.atomic().set(["giveaway", g.id], g).commit();
}

export async function getGiveaway(id: string): Promise<Giveaway | null> {
  return (await kv.get<Giveaway>(["giveaway", id])).value ?? null;
}

export interface VoiceMasterConfig {
  enabled: boolean;
  hubChannelId?: string;
  categoryId?: string;
  nameTemplate: string;
}

export interface ReactionRole {
  messageId: string;
  channelId: string;
  emoji: string;
  roleId: string;
}

export interface FakePerm {
  roleId: string;
  /** Command names this role may run (e.g. ban, kick, purge). */
  commands: string[];
}

export interface Workflow {
  id: string;
  name: string;
  trigger: "member_join" | "member_leave" | "message" | "level_up";
  /** Optional substring for message trigger. */
  match?: string;
  action: "reply" | "dm" | "add_role" | "log";
  payload: string;
  enabled: boolean;
}

export interface BumpConfig {
  enabled: boolean;
  channelId?: string;
  reminderHours: number;
  lastBumpAt: number;
}

export interface BoosterConfig {
  enabled: boolean;
  roleId?: string;
}

export interface AliasMap {
  [alias: string]: string; // alias -> command name
}

const defaultVm = (): VoiceMasterConfig => ({
  enabled: false,
  nameTemplate: "{user}'s channel",
});
const defaultBump = (): BumpConfig => ({ enabled: false, reminderHours: 2, lastBumpAt: 0 });
const defaultBooster = (): BoosterConfig => ({ enabled: false });

export const extraConfig = {
  getVoiceMaster: (g: string) => get(g, "voicemaster", defaultVm),
  setVoiceMaster: (g: string, v: VoiceMasterConfig) => set(g, "voicemaster", v),
  getReactionRoles: async (g: string) =>
    (await kv.get<ReactionRole[]>(key(g, "reactionroles"))).value ?? [],
  setReactionRoles: (g: string, v: ReactionRole[]) => set(g, "reactionroles", v),
  getFakePerms: async (g: string) =>
    (await kv.get<FakePerm[]>(key(g, "fakeperms"))).value ?? [],
  setFakePerms: (g: string, v: FakePerm[]) => set(g, "fakeperms", v),
  getWorkflows: async (g: string) =>
    (await kv.get<Workflow[]>(key(g, "workflows"))).value ?? [],
  setWorkflows: (g: string, v: Workflow[]) => set(g, "workflows", v),
  getBump: (g: string) => get(g, "bump", defaultBump),
  setBump: (g: string, v: BumpConfig) => set(g, "bump", v),
  getBooster: (g: string) => get(g, "booster", defaultBooster),
  setBooster: (g: string, v: BoosterConfig) => set(g, "booster", v),
  getAliases: async (g: string) =>
    (await kv.get<AliasMap>(key(g, "aliases"))).value ?? {},
  setAliases: (g: string, v: AliasMap) => set(g, "aliases", v),
  getScripts: async (g: string) =>
    (await kv.get<Record<string, string>>(key(g, "scripts"))).value ?? {},
  setScripts: (g: string, v: Record<string, string>) => set(g, "scripts", v),
  /** Temp voice channels created by VoiceMaster: channelId -> ownerId */
  getVmOwned: async (g: string) =>
    (await kv.get<Record<string, string>>(key(g, "vm_owned"))).value ?? {},
  setVmOwned: (g: string, v: Record<string, string>) => set(g, "vm_owned", v),
};
