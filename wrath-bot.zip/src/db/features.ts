import { TROOPS } from "../data/troops.js";
import type { KvKey } from "./store.js";
import { addBalance, kv, mutate, trySpend, updateUser, type User } from "./index.js";

// ---------------------------------------------------------------- jobs ----

export interface JobRecord {
  jobId: string | null;
  lastShift: number;
}

const jobKey = (uid: string): KvKey => ["jobs", uid];
const emptyJob = (): JobRecord => ({ jobId: null, lastShift: 0 });

export async function getJobRecord(uid: string): Promise<JobRecord> {
  return (await kv.get<JobRecord>(jobKey(uid))).value ?? emptyJob();
}

export function setJob(uid: string, jobId: string | null): Promise<boolean> {
  return mutate<JobRecord>(jobKey(uid), emptyJob, (r) => {
    r.jobId = jobId;
    return true;
  });
}

/** Starts a shift if the cooldown has passed. Returns false if still cooling down. */
export function claimShift(uid: string, cooldownMs: number): Promise<boolean> {
  return mutate<JobRecord>(jobKey(uid), emptyJob, (r) => {
    if (Date.now() - r.lastShift < cooldownMs) return false;
    r.lastShift = Date.now();
    return true;
  });
}

// ---------------------------------------------------------------- pets ----

/** Hard ceiling (premium max). Adopt command applies free/premium limits. */
export const MAX_PETS = 10;

export interface Pet {
  id: string;
  name: string;
  species: string;
  adoptedAt: number;
  fedAt: number;
  playedAt: number;
}

const petsKey = (uid: string): KvKey => ["pets", uid];

export async function getPets(uid: string): Promise<Pet[]> {
  return (await kv.get<Pet[]>(petsKey(uid))).value ?? [];
}

export function findPet(pets: Pet[], name: string): Pet | undefined {
  const wanted = name.trim().toLowerCase();
  return pets.find((p) => p.name.toLowerCase() === wanted);
}

export function addPet(uid: string, pet: Pet): Promise<boolean> {
  return mutate<Pet[]>(petsKey(uid), () => [], (list) => {
    if (list.length >= MAX_PETS) return false;
    list.push(pet);
    return true;
  });
}

export function updatePet(uid: string, petId: string, change: (p: Pet) => void): Promise<boolean> {
  return mutate<Pet[]>(petsKey(uid), () => [], (list) => {
    const pet = list.find((p) => p.id === petId);
    if (!pet) return false;
    change(pet);
    return true;
  });
}

export function removePet(uid: string, petId: string): Promise<boolean> {
  return mutate<Pet[]>(petsKey(uid), () => [], (list) => {
    const index = list.findIndex((p) => p.id === petId);
    if (index === -1) return false;
    list.splice(index, 1);
    return true;
  });
}

// ---------------------------------------------------------------- farm ----

export const PLOT_COUNT = 4;

export interface Plot {
  crop: string;
  plantedAt: number;
}

export type Farm = (Plot | null)[];

const farmKey = (uid: string): KvKey => ["farm", uid];
const emptyFarm = (): Farm => Array.from({ length: PLOT_COUNT }, () => null);

export async function getFarm(uid: string): Promise<Farm> {
  return (await kv.get<Farm>(farmKey(uid))).value ?? emptyFarm();
}

export function plantPlot(uid: string, index: number, crop: string): Promise<boolean> {
  return mutate<Farm>(farmKey(uid), emptyFarm, (farm) => {
    if (index < 0 || index >= farm.length || farm[index] !== null) return false;
    farm[index] = { crop, plantedAt: Date.now() };
    return true;
  });
}

/** Harvests every ready plot and returns the total coins earned. */
export async function harvestReady(
  uid: string,
  growMsOf: (crop: string) => number,
  valueOf: (crop: string) => number,
): Promise<number> {
  let total = 0;
  await mutate<Farm>(farmKey(uid), emptyFarm, (farm) => {
    total = 0;
    let harvested = false;
    farm.forEach((plot, i) => {
      if (plot && Date.now() - plot.plantedAt >= growMsOf(plot.crop)) {
        total += valueOf(plot.crop);
        farm[i] = null;
        harvested = true;
      }
    });
    return harvested;
  });
  if (total > 0) await addBalance(uid, total);
  return total;
}

// ------------------------------------------------------------- lottery ----

export const LOTTERY_TICKET_PRICE = 100;
export const DRAW_INTERVAL_MS = 24 * 60 * 60 * 1000;

export interface Lottery {
  pot: number;
  tickets: string[];
  lastDraw: number;
}

const lotteryKey: KvKey = ["lottery"];
const emptyLottery = (): Lottery => ({ pot: 0, tickets: [], lastDraw: 0 });

export async function getLottery(): Promise<Lottery> {
  return (await kv.get<Lottery>(lotteryKey)).value ?? emptyLottery();
}

export async function buyTickets(uid: string, count: number): Promise<boolean> {
  const cost = count * LOTTERY_TICKET_PRICE;
  if (!(await trySpend(uid, cost))) return false;

  await mutate<Lottery>(lotteryKey, emptyLottery, (s) => {
    s.pot += cost;
    for (let i = 0; i < count; i++) s.tickets.push(uid);
    return true;
  });
  return true;
}

export type DrawResult =
  | { status: "cooldown"; waitMs: number }
  | { status: "empty" }
  | { status: "won"; winner: string; prize: number };

/** Anyone can draw once the interval has passed. The winner takes the pot. */
export async function drawLottery(): Promise<DrawResult> {
  let result = { status: "empty" } as DrawResult;

  const committed = await mutate<Lottery>(lotteryKey, emptyLottery, (s) => {
    const waitMs = s.lastDraw + DRAW_INTERVAL_MS - Date.now();
    if (waitMs > 0) {
      result = { status: "cooldown", waitMs };
      return false;
    }
    if (s.tickets.length === 0) {
      result = { status: "empty" };
      return false;
    }
    const winner = s.tickets[Math.floor(Math.random() * s.tickets.length)];
    result = { status: "won", winner, prize: s.pot };
    s.pot = 0;
    s.tickets = [];
    s.lastDraw = Date.now();
    return true;
  });

  if (committed && result.status === "won") {
    await addBalance(result.winner, result.prize);
  }
  return result;
}

// ------------------------------------------------------------ crafting ----

/** Removes the ingredients and adds one output item, atomically. */
export function craft(uid: string, ingredients: Record<string, number>, output: string): Promise<boolean> {
  return updateUser(uid, (u) => {
    const inv = { ...(u.inventory ?? {}) };
    for (const [id, n] of Object.entries(ingredients)) {
      if ((inv[id] ?? 0) < n) return false;
    }
    for (const [id, n] of Object.entries(ingredients)) {
      inv[id] = (inv[id] ?? 0) - n;
    }
    inv[output] = (inv[output] ?? 0) + 1;
    u.inventory = inv;
    return true;
  });
}

// ------------------------------------------------------------------ war ----

export interface Army {
  troops: Record<string, number>;
  training: number;
  lastBattle: number;
}

const armyKey = (uid: string): KvKey => ["army", uid];
const emptyArmy = (): Army => ({ troops: {}, training: 0, lastBattle: 0 });

export async function getArmy(uid: string): Promise<Army> {
  return (await kv.get<Army>(armyKey(uid))).value ?? emptyArmy();
}

export function armyPower(army: Army): number {
  const fromTroops = TROOPS.reduce((sum, t) => sum + (army.troops[t.id] ?? 0) * t.power, 0);
  return fromTroops + army.training;
}

export function addTroops(uid: string, troopId: string, count: number): Promise<boolean> {
  return mutate<Army>(armyKey(uid), emptyArmy, (a) => {
    a.troops[troopId] = (a.troops[troopId] ?? 0) + count;
    return true;
  });
}

export function addTraining(uid: string, points: number): Promise<boolean> {
  return mutate<Army>(armyKey(uid), emptyArmy, (a) => {
    a.training += points;
    return true;
  });
}

/** Starts a battle if the cooldown has passed. Returns false if the army is still resting. */
export function claimBattle(uid: string, cooldownMs: number): Promise<boolean> {
  return mutate<Army>(armyKey(uid), emptyArmy, (a) => {
    if (Date.now() - a.lastBattle < cooldownMs) return false;
    a.lastBattle = Date.now();
    return true;
  });
}

// -------------------------------------------------------- server settings ----

export interface Greeting {
  channelId: string;
  message: string;
}

const greetKey = (guildId: string, kind: "welcome" | "goodbye"): KvKey => ["greet", guildId, kind];

export async function getGreeting(guildId: string, kind: "welcome" | "goodbye"): Promise<Greeting | null> {
  return (await kv.get<Greeting | null>(greetKey(guildId, kind))).value;
}

export async function setGreeting(
  guildId: string,
  kind: "welcome" | "goodbye",
  value: Greeting | null,
): Promise<boolean> {
  return (await kv.atomic().set(greetKey(guildId, kind), value).commit()).ok;
}

// ------------------------------------------------------------ community ----

export interface Afk {
  reason: string;
  since: number;
}

const afkKey = (uid: string): KvKey => ["afk", uid];

export async function getAfk(uid: string): Promise<Afk | null> {
  return (await kv.get<Afk | null>(afkKey(uid))).value;
}

export async function setAfk(uid: string, value: Afk | null): Promise<boolean> {
  return (await kv.atomic().set(afkKey(uid), value).commit()).ok;
}

const marriageKey = (uid: string): KvKey => ["marriage", uid];

export async function getPartner(uid: string): Promise<string | null> {
  return (await kv.get<string | null>(marriageKey(uid))).value;
}

/** Marries two players, but only if neither is married already. */
export async function marry(a: string, b: string): Promise<boolean> {
  const aKey = marriageKey(a);
  const bKey = marriageKey(b);
  for (let attempt = 0; attempt < 10; attempt++) {
    const ea = await kv.get<string | null>(aKey);
    const eb = await kv.get<string | null>(bKey);
    if (ea.value || eb.value) return false;

    const result = await kv.atomic()
      .check({ key: aKey, versionstamp: ea.versionstamp })
      .check({ key: bKey, versionstamp: eb.versionstamp })
      .set(aKey, b)
      .set(bKey, a)
      .commit();
    if (result.ok) return true;
  }
  return false;
}

export async function divorce(a: string): Promise<boolean> {
  const partner = await getPartner(a);
  if (!partner) return false;

  const aKey = marriageKey(a);
  const pKey = marriageKey(partner);
  for (let attempt = 0; attempt < 10; attempt++) {
    const ea = await kv.get<string | null>(aKey);
    const ep = await kv.get<string | null>(pKey);

    const result = await kv.atomic()
      .check({ key: aKey, versionstamp: ea.versionstamp })
      .check({ key: pKey, versionstamp: ep.versionstamp })
      .set(aKey, null)
      .set(pKey, null)
      .commit();
    if (result.ok) return true;
  }
  return false;
}

const proposalKey = (targetId: string): KvKey => ["proposal", targetId];

export async function getProposal(targetId: string): Promise<string | null> {
  return (await kv.get<string | null>(proposalKey(targetId))).value;
}

export async function setProposal(targetId: string, proposerId: string | null): Promise<boolean> {
  return (await kv.atomic().set(proposalKey(targetId), proposerId).commit()).ok;
}

export interface RpStats {
  sent: number;
  received: number;
}

const rpKey = (uid: string): KvKey => ["rp", uid];

export async function getRp(uid: string): Promise<RpStats> {
  return (await kv.get<RpStats>(rpKey(uid))).value ?? { sent: 0, received: 0 };
}

export function bumpRp(uid: string, field: keyof RpStats): Promise<boolean> {
  return mutate<RpStats>(rpKey(uid), () => ({ sent: 0, received: 0 }), (s) => {
    s[field] += 1;
    return true;
  });
}

export type RankMetric = "wealth" | "wins" | "xp" | "rp";

/** Top players for a metric. Scans all stored players, so it suits small and medium servers. */
export async function rankPlayers(metric: RankMetric, limit: number): Promise<{ id: string; score: number }[]> {
  const scores = new Map<string, number>();

  if (metric === "rp") {
    for await (const entry of kv.list<RpStats>({ prefix: ["rp"] })) {
      scores.set(String(entry.key[1]), entry.value.sent + entry.value.received);
    }
  } else {
    for await (const entry of kv.list<User>({ prefix: ["users"] })) {
      const u = entry.value;
      const score =
        metric === "wealth" ? u.balance + u.bank : metric === "wins" ? u.wins : u.xp;
      scores.set(String(entry.key[1]), score);
    }
  }

  return [...scores.entries()]
    .map(([id, score]) => ({ id, score }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

// ------------------------------------------------------ server protection ----

export interface GuardSettings {
  enabled: boolean;
  alertChannelId: string | null;
}
const guardKey = (guildId: string): KvKey => ["guard", guildId];
const defaultGuard = (): GuardSettings => ({ enabled: false, alertChannelId: null });
export async function getGuardSettings(guildId: string): Promise<GuardSettings> {
  return (await kv.get<GuardSettings>(guardKey(guildId))).value ?? defaultGuard();
}
export function setGuardSettings(guildId: string, settings: GuardSettings): Promise<boolean> {
  return mutate<GuardSettings>(guardKey(guildId), defaultGuard, (current) => {
    current.enabled = settings.enabled;
    current.alertChannelId = settings.alertChannelId;
    return true;
  });
}
