import { config } from "../config.js";
import { getUser, kv, updateUser, type User } from "./index.js";
import type { KvKey } from "./store.js";

export function isPremiumUser(u: User, now = Date.now()): boolean {
  return Boolean(u.premiumUntil && u.premiumUntil > now);
}

export async function isPremium(userId: string, roleIds?: string[]): Promise<boolean> {
  if (config.premiumRoleId && roleIds?.includes(config.premiumRoleId)) return true;
  const u = await getUser(userId);
  return isPremiumUser(u);
}

export async function getPremiumStatus(userId: string, roleIds?: string[]): Promise<{
  active: boolean;
  until: number;
  viaRole: boolean;
}> {
  const viaRole = Boolean(config.premiumRoleId && roleIds?.includes(config.premiumRoleId));
  const u = await getUser(userId);
  const until = u.premiumUntil ?? 0;
  const active = viaRole || isPremiumUser(u);
  return { active, until: viaRole ? 0 : until, viaRole };
}

/** Grant or extend premium by `days` from max(now, currentUntil). */
export async function grantPremium(userId: string, days: number): Promise<number> {
  let until = 0;
  await updateUser(userId, (u) => {
    const base = Math.max(Date.now(), u.premiumUntil ?? 0);
    until = base + Math.max(1, days) * 24 * 60 * 60 * 1000;
    u.premiumUntil = until;
    return true;
  });
  return until;
}

export async function revokePremium(userId: string): Promise<void> {
  await updateUser(userId, (u) => {
    u.premiumUntil = 0;
    return true;
  });
}

export function maxPetsFor(premium: boolean): number {
  return premium ? config.maxPetsPremium : config.maxPetsFree;
}

export function askLimits(premium: boolean): { cooldownMs: number; daily: number } {
  return premium
    ? { cooldownMs: config.askCooldownPremiumMs, daily: config.askDailyPremium }
    : { cooldownMs: config.askCooldownFreeMs, daily: config.askDailyFree };
}

function utcDay(now = Date.now()): string {
  return new Date(now).toISOString().slice(0, 10);
}

/**
 * Reserve one ask for the user. Returns remaining or an error reason.
 */
export async function consumeAsk(
  userId: string,
  premium: boolean,
): Promise<{ ok: true; remaining: number; daily: number } | { ok: false; reason: string }> {
  const { daily } = askLimits(premium);
  let remaining = 0;
  let blocked: string | null = null;

  await updateUser(userId, (u) => {
    const day = utcDay();
    if (u.askDay !== day) {
      u.askDay = day;
      u.askCount = 0;
    }
    const used = u.askCount ?? 0;
    if (used >= daily) {
      blocked = premium
        ? `Daily AI limit reached (**${daily}**/day). Resets at UTC midnight.`
        : `Free plan limit: **${daily}** asks/day. Upgrade with \`,premium\` (${config.premiumPriceLabel}) for **${config.askDailyPremium}**/day.`;
      return false;
    }
    u.askCount = used + 1;
    remaining = daily - u.askCount;
    return true;
  });

  if (blocked) return { ok: false, reason: blocked };
  return { ok: true, remaining, daily };
}

// ------------------------- redeem codes -------------------------

export interface PremiumCode {
  code: string;
  days: number;
  /** Max redemptions; 1 = single-use. */
  maxUses: number;
  uses: number;
  createdAt: number;
}

const codeKey = (code: string): KvKey => ["premiumCodes", code.toUpperCase()];

export async function createPremiumCode(days: number, maxUses = 1): Promise<string> {
  const code = `WRATH-${randomChunk()}-${randomChunk()}`;
  const record: PremiumCode = {
    code,
    days: Math.max(1, days),
    maxUses: Math.max(1, maxUses),
    uses: 0,
    createdAt: Date.now(),
  };
  await kv.atomic().set(codeKey(code), record).commit();
  return code;
}

function randomChunk(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 4; i++) s += alphabet[Math.floor(Math.random() * alphabet.length)];
  return s;
}

export async function redeemPremiumCode(
  userId: string,
  raw: string,
): Promise<{ ok: true; until: number; days: number } | { ok: false; reason: string }> {
  const code = raw.trim().toUpperCase();
  if (!code) return { ok: false, reason: "Provide a code." };

  const key = codeKey(code);
  let days = 0;

  for (let attempt = 0; attempt < 10; attempt++) {
    const entry = await kv.get<PremiumCode>(key);
    const rec = entry.value;
    if (!rec) return { ok: false, reason: "Invalid code." };
    if (rec.uses >= rec.maxUses) return { ok: false, reason: "That code has already been fully used." };

    const next: PremiumCode = { ...rec, uses: rec.uses + 1 };
    days = rec.days;
    const result = await kv.atomic().check({ key, versionstamp: entry.versionstamp }).set(key, next).commit();
    if (result.ok) {
      const until = await grantPremium(userId, days);
      return { ok: true, until, days };
    }
  }
  return { ok: false, reason: "Could not redeem right now. Try again." };
}
