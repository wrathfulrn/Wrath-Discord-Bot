import fs from "node:fs";
import path from "node:path";

export type KvKey = readonly unknown[];

interface Entry {
  raw: string;
  version: number;
}

interface Check {
  key: KvKey;
  versionstamp: string | null;
}

interface Write {
  key: KvKey;
  value: unknown;
}

const idOf = (key: KvKey): string => JSON.stringify(key);

/**
 * A small key-value store that keeps everything in one JSON file. It supports
 * the parts of Deno KV the economy code uses (get, list, and atomic
 * check-and-set). Each commit is synchronous, so it is atomic within this
 * process. Every commit rewrites the whole file, which is fine for small bots.
 */
export class KvStore {
  private entries = new Map<string, Entry>();
  private version = 0;

  constructor(private readonly file: string) {
    if (fs.existsSync(file)) {
      const saved = JSON.parse(fs.readFileSync(file, "utf8")) as {
        version: number;
        entries: Record<string, Entry>;
      };
      this.version = saved.version;
      this.entries = new Map(Object.entries(saved.entries));
    } else {
      fs.mkdirSync(path.dirname(file), { recursive: true });
    }
  }

  async get<T>(key: KvKey): Promise<{ key: KvKey; value: T | null; versionstamp: string | null }> {
    const entry = this.entries.get(idOf(key));
    return {
      key,
      value: entry ? (JSON.parse(entry.raw) as T) : null,
      versionstamp: entry ? String(entry.version) : null,
    };
  }

  async *list<T>(selector: { prefix: KvKey }): AsyncGenerator<{ key: KvKey; value: T }> {
    for (const [id, entry] of this.entries) {
      const key = JSON.parse(id) as unknown[];
      const matches = selector.prefix.every((part, i) => key[i] === part);
      if (matches) {
        yield { key, value: JSON.parse(entry.raw) as T };
      }
    }
  }

  atomic(): Atomic {
    return new Atomic(this);
  }

  /** Applies the writes only if every check still matches. Used by Atomic. */
  apply(checks: Check[], writes: Write[]): boolean {
    for (const check of checks) {
      const entry = this.entries.get(idOf(check.key));
      const current = entry ? String(entry.version) : null;
      if (current !== check.versionstamp) return false;
    }

    for (const write of writes) {
      this.version += 1;
      this.entries.set(idOf(write.key), { raw: JSON.stringify(write.value), version: this.version });
    }
    this.save();
    return true;
  }

  private save(): void {
    const tmp = `${this.file}.tmp`;
    const data = { version: this.version, entries: Object.fromEntries(this.entries) };
    fs.writeFileSync(tmp, JSON.stringify(data));
    fs.renameSync(tmp, this.file);
  }
}

export class Atomic {
  private checks: Check[] = [];
  private writes: Write[] = [];

  constructor(private readonly store: KvStore) {}

  check(...checks: Check[]): this {
    this.checks.push(...checks);
    return this;
  }

  set(key: KvKey, value: unknown): this {
    this.writes.push({ key, value });
    return this;
  }

  async commit(): Promise<{ ok: boolean }> {
    return { ok: this.store.apply(this.checks, this.writes) };
  }
}
