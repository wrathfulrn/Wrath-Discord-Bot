import { KvStore, type KvKey } from "./store.js";
import { config } from "../config.js";

export const kv = new KvStore(config.dbPath);

export interface User {
  balance: number;
  bank: number;
  lastDaily: number;
  lastWork: number;
  xp: number;
  wins: number;
  losses: number;
  inventory?: Record<string, number>;
  /** Unix ms when premium expires. 0 / missing = not premium. */
  premiumUntil?: number;
  /** Asks used since askDay reset. */
  askCount?: number;
  /** YYYY-MM-DD (UTC) for askCount. */
  askDay?: string;
}

const defaultUser = (): User => ({
  balance: config.startBalance,
  bank: 0,
  lastDaily: 0,
  lastWork: 0,
  xp: 0,
  wins: 0,
  losses: 0,
  premiumUntil: 0,
  askCount: 0,
  askDay: "",
});

const MAX_ATTEMPTS = 10;

/**
 * Read-modify-write with optimistic concurrency. `fn` mutates the value and
 * returns true to commit, or false to abort without writing.
 */
export async function mutate<T>(
  key: KvKey,
  init: () => T,
  fn: (value: T) => boolean,
): Promise<boolean> {
  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const entry = await kv.get<T>(key);
    const value = entry.value ?? init();
    if (!fn(value)) return false;

    const result = await kv.atomic()
      .check({ key, versionstamp: entry.versionstamp })
      .set(key, value)
      .commit();
    if (result.ok) return true;
  }
  throw new Error(`Too much contention writing ${JSON.stringify(key)}`);
}

export async function getUser(userId: string): Promise<User> {
  const entry = await kv.get<User>(["users", userId]);
  return entry.value ?? defaultUser();
}

export function updateUser(userId: string, fn: (u: User) => boolean): Promise<boolean> {
  return mutate(["users", userId], defaultUser, fn);
}

export async function addBalance(userId: string, amount: number): Promise<void> {
  await updateUser(userId, (u) => {
    u.balance += amount;
    return true;
  });
}

/** Removes coins from the wallet. Returns false if funds are short. */
export function trySpend(userId: string, amount: number): Promise<boolean> {
  return updateUser(userId, (u) => {
    if (u.balance < amount) return false;
    u.balance -= amount;
    return true;
  });
}

export function deposit(userId: string, amount: number): Promise<boolean> {
  return updateUser(userId, (u) => {
    if (u.balance < amount) return false;
    u.balance -= amount;
    u.bank += amount;
    return true;
  });
}

export function withdraw(userId: string, amount: number): Promise<boolean> {
  return updateUser(userId, (u) => {
    if (u.bank < amount) return false;
    u.bank -= amount;
    u.balance += amount;
    return true;
  });
}

/** Moves coins between two users in one atomic commit. */
export async function transfer(from: string, to: string, amount: number): Promise<boolean> {
  const fromKey: KvKey = ["users", from];
  const toKey: KvKey = ["users", to];

  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const fromEntry = await kv.get<User>(fromKey);
    const toEntry = await kv.get<User>(toKey);
    const sender = fromEntry.value ?? defaultUser();
    const receiver = toEntry.value ?? defaultUser();

    if (sender.balance < amount) return false;
    sender.balance -= amount;
    receiver.balance += amount;

    const result = await kv.atomic()
      .check({ key: fromKey, versionstamp: fromEntry.versionstamp })
      .check({ key: toKey, versionstamp: toEntry.versionstamp })
      .set(fromKey, sender)
      .set(toKey, receiver)
      .commit();
    if (result.ok) return true;
  }
  throw new Error("Too much contention during transfer");
}

export function markWorked(userId: string, xpGain: number): Promise<boolean> {
  return updateUser(userId, (u) => {
    u.lastWork = Date.now();
    u.xp += xpGain;
    return true;
  });
}

export function markDaily(userId: string): Promise<boolean> {
  return updateUser(userId, (u) => {
    u.lastDaily = Date.now();
    return true;
  });
}

export function recordResult(userId: string, won: boolean): Promise<boolean> {
  return updateUser(userId, (u) => {
    if (won) u.wins += 1;
    else u.losses += 1;
    return true;
  });
}

/** Top users by wallet plus bank. Scans all users, so fine for small servers. */
export async function topUsers(limit: number): Promise<{ id: string; total: number }[]> {
  const rows: { id: string; total: number }[] = [];
  for await (const entry of kv.list<User>({ prefix: ["users"] })) {
    rows.push({
      id: String(entry.key[1]),
      total: entry.value.balance + entry.value.bank,
    });
  }
  return rows.sort((a, b) => b.total - a.total).slice(0, limit);
}

export async function addWarning(guildId: string, userId: string, reason: string): Promise<number> {
  const key: KvKey = ["warnings", guildId, userId];
  await mutate<string[]>(key, () => [], (list) => {
    list.push(reason);
    return true;
  });
  return (await getWarnings(guildId, userId)).length;
}

export async function getWarnings(guildId: string, userId: string): Promise<string[]> {
  const entry = await kv.get<string[]>(["warnings", guildId, userId]);
  return entry.value ?? [];
}

export function buyItem(userId: string, itemId: string, price: number): Promise<boolean> {
  return updateUser(userId, (u) => {
    if (u.balance < price) return false;
    u.balance -= price;
    u.inventory = { ...(u.inventory ?? {}), [itemId]: (u.inventory?.[itemId] ?? 0) + 1 };
    return true;
  });
}

export function sellItem(userId: string, itemId: string, price: number): Promise<boolean> {
  return updateUser(userId, (u) => {
    const owned = u.inventory?.[itemId] ?? 0;
    if (owned < 1) return false;
    u.inventory = { ...(u.inventory ?? {}), [itemId]: owned - 1 };
    u.balance += price;
    return true;
  });
}

/** Moves one item between two users in one atomic commit. */
export async function giftItem(from: string, to: string, itemId: string): Promise<boolean> {
  const fromKey: KvKey = ["users", from];
  const toKey: KvKey = ["users", to];

  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const fromEntry = await kv.get<User>(fromKey);
    const toEntry = await kv.get<User>(toKey);
    const sender = fromEntry.value ?? defaultUser();
    const receiver = toEntry.value ?? defaultUser();

    const owned = sender.inventory?.[itemId] ?? 0;
    if (owned < 1) return false;
    sender.inventory = { ...(sender.inventory ?? {}), [itemId]: owned - 1 };
    receiver.inventory = {
      ...(receiver.inventory ?? {}),
      [itemId]: (receiver.inventory?.[itemId] ?? 0) + 1,
    };

    const result = await kv.atomic()
      .check({ key: fromKey, versionstamp: fromEntry.versionstamp })
      .check({ key: toKey, versionstamp: toEntry.versionstamp })
      .set(fromKey, sender)
      .set(toKey, receiver)
      .commit();
    if (result.ok) return true;
  }
  throw new Error("Too much contention during gift");
}

/** Remove every stored warning for a member. */
export async function clearWarnings(guildId: string, userId: string): Promise<number> {
  const key: KvKey = ["warnings", guildId, userId];
  const current = await kv.get<string[]>(key);
  const count = current.value?.length ?? 0;
  if (count > 0) await kv.atomic().check({ key, versionstamp: current.versionstamp }).set(key, []).commit();
  return count;
}
