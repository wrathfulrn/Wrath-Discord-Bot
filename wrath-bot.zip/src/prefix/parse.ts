import { OptionType, type Command, type OptionDef } from "../types.js";

export type ParseResult =
  | { ok: true; values: Map<string, string> }
  | { ok: false; error: string };

/** Builds a usage hint like `,feed <pet>`. */
export function usageOf(prefix: string, cmd: Command): string {
  const args = (cmd.options ?? [])
    .map((o) => (o.required ? `<${o.name}>` : `[${o.name}]`))
    .join(" ");
  return `${prefix}${cmd.name}${args ? ` ${args}` : ""}`;
}

/**
 * Maps positional words onto a command's options in order. The last option,
 * if it is free text, takes the rest of the message.
 */
export function parseArgs(cmd: Command, tokens: string[]): ParseResult {
  const options = cmd.options ?? [];
  const values = new Map<string, string>();
  let i = 0;

  for (let idx = 0; idx < options.length; idx++) {
    const opt = options[idx];

    if (i >= tokens.length) {
      if (opt.required) return { ok: false, error: `Missing <${opt.name}>.` };
      continue;
    }

    const isLast = idx === options.length - 1;
    const greedy = isLast && opt.type === OptionType.STRING && !opt.choices;
    const raw = greedy ? tokens.slice(i).join(" ") : tokens[i];
    i = greedy ? tokens.length : i + 1;

    const checked = checkValue(opt, raw);
    if (!checked.ok) return checked;
    values.set(opt.name, checked.value);
  }

  if (i < tokens.length) {
    return { ok: false, error: "Too many arguments." };
  }
  return { ok: true, values };
}

type Checked = { ok: true; value: string } | { ok: false; error: string };

function checkValue(opt: OptionDef, raw: string): Checked {
  switch (opt.type) {
    case OptionType.INTEGER: {
      const n = Number(raw);
      if (!Number.isInteger(n)) return { ok: false, error: `<${opt.name}> must be a whole number.` };
      if (opt.min_value !== undefined && n < opt.min_value) {
        return { ok: false, error: `<${opt.name}> must be at least ${opt.min_value}.` };
      }
      if (opt.max_value !== undefined && n > opt.max_value) {
        return { ok: false, error: `<${opt.name}> must be at most ${opt.max_value}.` };
      }
      return { ok: true, value: String(n) };
    }

    case OptionType.USER: {
      const id = extractUserId(raw);
      if (!id) return { ok: false, error: `<${opt.name}> must be a mention or a user ID.` };
      return { ok: true, value: id };
    }

    default: {
      if (opt.choices) {
        const wanted = raw.toLowerCase();
        const match = opt.choices.find(
          (c) => c.value.toLowerCase() === wanted || c.name.toLowerCase() === wanted,
        );
        if (!match) {
          const allowed = opt.choices.map((c) => `\`${c.value}\``).join(", ");
          return { ok: false, error: `<${opt.name}> must be one of: ${allowed}.` };
        }
        return { ok: true, value: match.value };
      }
      return { ok: true, value: raw };
    }
  }
}

function extractUserId(raw: string): string | null {
  const mention = /^<@!?(\d+)>$/.exec(raw);
  if (mention) return mention[1];
  if (/^\d{5,25}$/.test(raw)) return raw;
  return null;
}
