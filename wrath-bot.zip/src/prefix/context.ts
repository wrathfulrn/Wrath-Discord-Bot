import type { Bot } from "@discordeno/bot";
import type { Ctx, ReplyOptions, ResolvedUser } from "../types.js";
import { asEmbed } from "../utils/embed.js";
import { avatarUrl, snowflakeTime } from "../utils/format.js";
import { hasBit, toResolved, type UserLike } from "../utils/users.js";
import { guildInfo } from "../discord.js";

/** The parts of a message payload this bot reads. */
export interface RawMessage {
  id: bigint;
  channelId: bigint;
  guildId?: bigint;
  content: string;
  author: UserLike;
  member?: { roles?: (bigint | string)[]; permissions?: string | bigint };
}

/** IDs of the users mentioned in a message, in order. */
export function mentionedIds(content: string): string[] {
  return [...content.matchAll(/<@!?(\d+)>/g)].map((m) => m[1]);
}

/** Sends a message in the same channel as the command. Prefix replies are always public. */
export function sendPrefixReply(bot: Bot, message: RawMessage, input: ReplyOptions): Promise<unknown> {
  return bot.helpers.sendMessage(message.channelId, {
    content: input.content,
    embeds: input.embeds,
    components: input.components,
  } as never);
}

/**
 * Builds the same Ctx that slash commands get, backed by a message instead of
 * an interaction. `values` holds the parsed option values, keyed by name.
 */
export function createPrefixCtx(
  bot: Bot,
  message: RawMessage,
  values: Map<string, string>,
  permissions: bigint,
  label = "",
): Ctx {
  const self: ResolvedUser = toResolved(message.author);
  const embedContext = {
    userId: self.id,
    label,
    username: self.username,
    userAvatar: avatarUrl(self.id, self.avatar),
  };

  // Mentions only give IDs here, so the mention itself shows the name in Discord.
  const resolveUser = (name: string): ResolvedUser | undefined => {
    const id = values.get(name);
    if (id === undefined) return undefined;
    return { id, username: id, bot: false, avatar: null };
  };

  return {
    bot,
    userId: self.id,
    username: self.username,
    userAvatar: embedContext.userAvatar,
    guildId: message.guildId !== undefined ? String(message.guildId) : undefined,
    channelId: String(message.channelId),
    createdAt: snowflakeTime(message.id),

    async reply(input) {
      await sendPrefixReply(bot, message, asEmbed(input, embedContext));
    },

    str: (name) => values.get(name),

    int(name) {
      const v = values.get(name);
      return v === undefined ? undefined : Number(v);
    },

    user: resolveUser,

    userOrSelf: (name) => resolveUser(name) ?? self,

    hasPermission: (bit) => hasBit(permissions, bit),

    guildInfo: () => (message.guildId !== undefined ? guildInfo(bot, String(message.guildId)) : Promise.resolve(null)),
  };
}
