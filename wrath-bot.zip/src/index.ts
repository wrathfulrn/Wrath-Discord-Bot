import "dotenv/config";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createBot, Intents } from "@discordeno/bot";
import { config } from "./config.js";
import { loadGroups, validateGroups } from "./loader.js";
import { registry } from "./registry.js";
import { onReady } from "./events/ready.js";
import { onInteraction } from "./events/interactionCreate.js";
import { onMessage } from "./events/messageCreate.js";
import { onMemberAdd, onMemberRemove } from "./events/memberEvents.js";
import { handleVoiceState } from "./modules/voicemaster.js";
import { onReactionAdd, onReactionRemove } from "./modules/reactionRoles.js";
import { maybeStarboard } from "./modules/starboardRuntime.js";
import type { RawInteraction } from "./context.js";
import type { RawMessage } from "./prefix/context.js";
import { packGroups, packCommands } from "./packs/index.js";
import type { Group } from "./types.js";

if (!config.token) {
  throw new Error("Missing DISCORD_TOKEN. Add it to your .env file.");
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const folderGroups = await loadGroups(path.join(__dirname, "commands"));
validateGroups(folderGroups);

/** Existing folder command names win over pack duplicates. */
const reserved = new Set<string>();
for (const g of folderGroups) {
  for (const s of g.subcommands) reserved.add(s.name);
}

const packs = packGroups().map((g) => ({
  ...g,
  subcommands: g.subcommands.filter((c) => !reserved.has(c.name)),
}));

/** Merge: folder groups keep their names; pack categories merge into same name or stand alone. */
const byName = new Map<string, Group>();
for (const g of folderGroups) byName.set(g.name, { ...g, subcommands: [...g.subcommands] });
for (const g of packs) {
  const existing = byName.get(g.name);
  if (existing) {
    existing.subcommands = [...existing.subcommands, ...g.subcommands];
  } else {
    byName.set(g.name, g);
  }
}

for (const g of byName.values()) {
  registry.set(g.name, g);
}

const groups = [...registry.values()];
const total = groups.reduce((n, g) => n + g.subcommands.length, 0);
const packOnly = packCommands().filter((c) => !reserved.has(c.name)).length;

/*
 * Discordeno only returns the fields listed here, so every field the bot reads
 * must be listed. The library's type definitions reject this object's shape, so
 * it is cast. The runtime receives the same fields.
 */
const desiredProperties = {
  interaction: { id: true, token: true, type: true, data: true, guildId: true, channelId: true, user: true, member: true },
  message: { id: true, channelId: true, guildId: true, content: true, author: true, member: true },
  member: { id: true, user: true, roles: true, permissions: true },
  user: { id: true, username: true, bot: true, avatar: true },
  guild: { id: true, name: true, memberCount: true, ownerId: true },
} as any;

const bot = createBot({
  token: config.token,
  intents: Intents.Guilds | Intents.GuildMembers | Intents.GuildMessages | Intents.MessageContent | ((Intents as unknown as Record<string, number>).GuildMessageReactions ?? 0) | ((Intents as unknown as Record<string, number>).GuildVoiceStates ?? 0),
  desiredProperties,
  events: {
    ready: (payload) => {
      onReady(bot, payload as never).catch(console.error);
    },
    interactionCreate: (interaction) => {
      onInteraction(bot, interaction as unknown as RawInteraction).catch(console.error);
    },
    messageCreate: (message) => {
      onMessage(bot, message as unknown as RawMessage).catch(console.error);
    },
    guildMemberAdd: (member, guild) => {
      onMemberAdd(bot, guild as never, String((member as { id?: unknown }).id)).catch(console.error);
    },
    guildMemberRemove: (member, guild) => {
      onMemberRemove(bot, guild as never, String((member as { id?: unknown }).id)).catch(console.error);
    },
    voiceStateUpdate: (voiceState) => {
      handleVoiceState(bot, voiceState as never).catch(console.error);
    },
    reactionAdd: (payload) => {
      const p = payload as {
        guildId?: string | bigint;
        channelId?: string | bigint;
        messageId?: string | bigint;
        userId?: string | bigint;
        emoji?: { id?: string | bigint | null; name?: string | null };
        count?: number;
      };
      onReactionAdd(bot, p).catch(console.error);
      if (p.guildId && p.channelId && p.messageId && p.emoji?.name) {
        maybeStarboard(
          bot,
          String(p.guildId),
          String(p.channelId),
          String(p.messageId),
          p.emoji.name,
          p.count ?? 1,
        ).catch(console.error);
      }
    },
    reactionRemove: (payload) => {
      onReactionRemove(bot, payload as never).catch(console.error);
    },
  },
});

console.log(`Loaded ${groups.length} groups with ${total} commands (${packOnly} from 1600-pack, rest builtins)`);
bot.start().catch((error: unknown) => {
  console.error("Failed to start the bot:", error);
  process.exit(1);
});
