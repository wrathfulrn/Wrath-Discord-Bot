import { CROPS } from "../../data/crops.js";
import type { Command } from "../../types.js";
import { coins, fmtDuration } from "../../utils/format.js";

const command: Command = {
  name: "crops",
  description: "Show crops you can plant",

  async execute(ctx) {
    const lines = CROPS.map((c) =>
      `${c.emoji} **${c.name}**: ready in ${fmtDuration(c.growMs)}, sells for ${coins(c.sellPrice)}`
    );

    await ctx.reply({
      embeds: [{ title: "🌱 Crops", color: 0x27ae60, description: lines.join("\n") }],
    });
  },
};

export default command;
