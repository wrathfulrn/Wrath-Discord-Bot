import type { Group } from "../../types.js";
import crops from "./crops.js";
import plant from "./plant.js";
import harvest from "./harvest.js";
import field from "./field.js";

const group: Group = {
  name: "farm",
  description: "Plant crops and harvest coins",
  subcommands: [crops, plant, harvest, field],
};

export default group;
