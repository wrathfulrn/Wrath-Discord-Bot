import { CROP_CHOICES, findCrop } from "../../data/crops.js";
import { plantPlot, PLOT_COUNT } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "plant",
  description: "Plant a crop on one of your plots",
  options: [
    { name: "crop", description: "What to plant", type: OptionType.STRING, required: true, choices: CROP_CHOICES },
    {
      name: "plot",
      description: `Plot number (1 to ${PLOT_COUNT})`,
      type: OptionType.INTEGER,
      required: true,
      min_value: 1,
      max_value: PLOT_COUNT,
    },
  ],

  async execute(ctx) {
    const crop = findCrop(ctx.str("crop"));
    const plot = ctx.int("plot") ?? 0;

    if (!crop) {
      await ctx.reply(privateError("That crop doesn't exist."));
      return;
    }
    if (!(await plantPlot(ctx.userId, plot - 1, crop.id))) {
      await ctx.reply(privateError(`Plot ${plot} is already in use.`));
      return;
    }
    await ctx.reply(`${crop.emoji} Planted ${crop.name} in plot ${plot}.`);
  },
};

export default command;
