import { findCrop } from "../../data/crops.js";
import { getFarm } from "../../db/features.js";
import type { Command } from "../../types.js";
import { fmtDuration } from "../../utils/format.js";

const command: Command = {
  name: "field",
  description: "Show the state of your plots",

  async execute(ctx) {
    const farm = await getFarm(ctx.userId);

    const lines = farm.map((plot, i) => {
      if (!plot) return `**${i + 1}.** empty`;
      const crop = findCrop(plot.crop);
      const elapsed = Date.now() - plot.plantedAt;
      const grow = crop?.growMs ?? 0;
      const status = elapsed >= grow ? "ready" : `${fmtDuration(grow - elapsed)} left`;
      return `**${i + 1}.** ${crop?.emoji ?? "🌱"} ${crop?.name ?? plot.crop}: ${status}`;
    });

    await ctx.reply({
      embeds: [{ title: "🌾 Your field", color: 0x27ae60, description: lines.join("\n") }],
    });
  },
};

export default command;
