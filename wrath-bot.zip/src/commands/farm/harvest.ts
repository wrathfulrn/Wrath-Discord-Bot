import { findCrop } from "../../data/crops.js";
import { harvestReady } from "../../db/features.js";
import type { Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "harvest",
  description: "Harvest and sell every ready crop",

  async execute(ctx) {
    const total = await harvestReady(
      ctx.userId,
      (id) => findCrop(id)?.growMs ?? Infinity,
      (id) => findCrop(id)?.sellPrice ?? 0,
    );

    if (total === 0) {
      await ctx.reply(privateError("Nothing is ready to harvest yet."));
      return;
    }
    await ctx.reply(`🧺 Harvested and sold your crops for ${coins(total)}.`);
  },
};

export default command;
