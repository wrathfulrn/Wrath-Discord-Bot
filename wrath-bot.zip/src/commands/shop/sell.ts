import { findItem, ITEM_CHOICES } from "../../data/shop.js";
import { sellItem } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "sell",
  description: "Sell one of your items back to the shop",
  options: [{
    name: "item",
    description: "Item to sell",
    type: OptionType.STRING,
    required: true,
    choices: ITEM_CHOICES,
  }],

  async execute(ctx) {
    const item = findItem(ctx.str("item") ?? "");
    if (!item) {
      await ctx.reply(privateError("That item doesn't exist."));
      return;
    }
    if (!(await sellItem(ctx.userId, item.id, item.sellPrice))) {
      await ctx.reply(privateError(`You don't have a ${item.name} to sell.`));
      return;
    }
    await ctx.reply(`${item.emoji} Sold a **${item.name}** for ${coins(item.sellPrice)}.`);
  },
};

export default command;
