import { findItem, ITEM_CHOICES } from "../../data/shop.js";
import { giftItem } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "gift",
  description: "Give one of your items to another member",
  options: [
    { name: "user", description: "Recipient", type: OptionType.USER, required: true },
    { name: "item", description: "Item to give", type: OptionType.STRING, required: true, choices: ITEM_CHOICES },
  ],

  async execute(ctx) {
    const target = ctx.user("user");
    const item = findItem(ctx.str("item") ?? "");

    if (!target || target.bot || target.id === ctx.userId) {
      await ctx.reply(privateError("Pick a real person to gift to."));
      return;
    }
    if (!item) {
      await ctx.reply(privateError("That item doesn't exist."));
      return;
    }
    if (!(await giftItem(ctx.userId, target.id, item.id))) {
      await ctx.reply(privateError(`You don't have a ${item.name} to give.`));
      return;
    }
    await ctx.reply(`🎁 <@${ctx.userId}> gave <@${target.id}> a ${item.emoji} **${item.name}**.`);
  },
};

export default command;
