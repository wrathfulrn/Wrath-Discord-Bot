import { findItem, ITEM_CHOICES } from "../../data/shop.js";
import { buyItem } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "buy",
  description: "Buy an item from the shop",
  options: [{
    name: "item",
    description: "Item to buy",
    type: OptionType.STRING,
    required: true,
    choices: ITEM_CHOICES,
  }],

  async execute(ctx) {
    const item = findItem(ctx.str("item") ?? "");
    if (!item) {
      await ctx.reply(privateError("That item doesn't exist."));
      return;
    }
    if (!(await buyItem(ctx.userId, item.id, item.price))) {
      await ctx.reply(privateError(`You need ${coins(item.price)} to buy a ${item.name}.`));
      return;
    }
    await ctx.reply(`${item.emoji} You bought a **${item.name}** for ${coins(item.price)}.`);
  },
};

export default command;
