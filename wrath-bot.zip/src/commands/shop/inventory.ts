import { getUser } from "../../db/index.js";
import { findItem } from "../../data/shop.js";
import { OptionType, type Command } from "../../types.js";

const command: Command = {
  name: "inventory",
  description: "Show what you or someone else owns",
  options: [{ name: "user", description: "Member to check", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    const u = await getUser(target.id);

    const lines = Object.entries(u.inventory ?? {})
      .filter(([, count]) => count > 0)
      .map(([id, count]) => {
        const item = findItem(id);
        return `${item?.emoji ?? "•"} **${item?.name ?? id}** × ${count}`;
      });

    await ctx.reply({
      embeds: [{
        title: `🎒 ${target.username}'s inventory`,
        color: 0x3498db,
        description: lines.join("\n") || "Empty.",
      }],
    });
  },
};

export default command;
