import { SHOP } from "../../data/shop.js";
import type { Command } from "../../types.js";
import { coins } from "../../utils/format.js";

const command: Command = {
  name: "shop",
  description: "Show items for sale",

  async execute(ctx) {
    const lines = SHOP.map((i) =>
      `${i.emoji} **${i.name}** (\`${i.id}\`): ${coins(i.price)}\n_${i.description}_`
    );

    await ctx.reply({
      embeds: [{
        title: "🛒 Shop",
        color: 0x2ecc71,
        description: lines.join("\n\n"),
      }],
    });
  },
};

export default command;
