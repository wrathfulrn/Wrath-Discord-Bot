import type { Group } from "../../types.js";
import list from "./list.js";
import buy from "./buy.js";
import sell from "./sell.js";
import inventory from "./inventory.js";
import gift from "./gift.js";

const group: Group = {
  name: "shop",
  description: "Buy, sell, and gift items",
  subcommands: [list, buy, sell, inventory, gift],
};

export default group;
