import type { Group } from "../../types.js";
import workflow from "./workflow.js";
const group: Group = { name: "workflows", description: "Simple automation workflows", guildOnly: true, subcommands: [workflow] };
export default group;
