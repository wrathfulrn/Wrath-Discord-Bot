import { OptionType, type Command } from "../../types.js";
import { extraConfig, type Workflow } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "workflow",
  description: "Add a simple trigger → action workflow",
  options: [
    { name: "name", description: "Workflow name", type: OptionType.STRING, required: true },
    { name: "trigger", description: "member_join, member_leave, message, level_up", type: OptionType.STRING, required: true, choices: [
      { name: "member_join", value: "member_join" },
      { name: "member_leave", value: "member_leave" },
      { name: "message", value: "message" },
      { name: "level_up", value: "level_up" },
    ]},
    { name: "action", description: "reply, dm, add_role, log", type: OptionType.STRING, required: true, choices: [
      { name: "reply", value: "reply" }, { name: "dm", value: "dm" }, { name: "add_role", value: "add_role" }, { name: "log", value: "log" },
    ]},
    { name: "payload", description: "Message text or role id", type: OptionType.STRING, required: true },
    { name: "match", description: "Substring for message trigger", type: OptionType.STRING },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const list = await extraConfig.getWorkflows(ctx.guildId);
    if (list.length >= 25) { await ctx.reply(privateError("Max 25 workflows.")); return; }
    const w: Workflow = {
      id: `${Date.now()}`,
      name: (ctx.str("name") ?? "flow").slice(0, 32),
      trigger: ctx.str("trigger") as Workflow["trigger"],
      action: ctx.str("action") as Workflow["action"],
      payload: (ctx.str("payload") ?? "").slice(0, 1500),
      match: ctx.str("match") ?? undefined,
      enabled: true,
    };
    list.push(w);
    await extraConfig.setWorkflows(ctx.guildId, list);
    await ctx.reply(`Workflow **${w.name}** saved: \`${w.trigger}\` → \`${w.action}\`.`);
  },
};
export default command;
