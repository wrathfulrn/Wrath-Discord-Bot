import { getUser } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";

const command: Command = {
  name: "stats",
  description: "Show win/loss record and XP",
  options: [{ name: "user", description: "Member to check", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    const u = await getUser(target.id);
    const games = u.wins + u.losses;
    const winRate = games ? `${Math.round((u.wins / games) * 100)}%` : "n/a";

    await ctx.reply({
      embeds: [{
        title: `${target.username}'s stats`,
        color: 0x9b59b6,
        fields: [
          { name: "XP", value: u.xp.toLocaleString("en-GB"), inline: true },
          { name: "Wins", value: String(u.wins), inline: true },
          { name: "Losses", value: String(u.losses), inline: true },
          { name: "Win rate", value: winRate, inline: true },
        ],
      }],
    });
  },
};

export default command;
