import { withdraw } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "withdraw",
  description: "Move coins from your bank to your wallet",
  options: [{
    name: "amount",
    description: "How many coins",
    type: OptionType.INTEGER,
    required: true,
    min_value: 1,
  }],

  async execute(ctx) {
    const amount = ctx.int("amount") ?? 0;

    if (!(await withdraw(ctx.userId, amount))) {
      await ctx.reply(privateError("You don't have that many coins in the bank."));
      return;
    }
    await ctx.reply(`💵 Withdrew ${coins(amount)} to your wallet.`);
  },
};

export default command;
