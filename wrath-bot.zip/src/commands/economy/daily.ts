import { config } from "../../config.js";
import { addBalance, getUser, markDaily } from "../../db/index.js";
import type { Command } from "../../types.js";
import { coins, cooldownLeft, cooldownNotice } from "../../utils/format.js";

const command: Command = {
  name: "daily",
  description: "Claim your daily reward",

  async execute(ctx) {
    const u = await getUser(ctx.userId);
    const wait = cooldownLeft(u.lastDaily, config.dailyCooldownMs);

    if (wait > 0) {
      await ctx.reply({ content: cooldownNotice(wait), ephemeral: true });
      return;
    }

    await addBalance(ctx.userId, config.dailyAmount);
    await markDaily(ctx.userId);
    await ctx.reply(`💰 You claimed ${coins(config.dailyAmount)}!`);
  },
};

export default command;
