import { getUser } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins } from "../../utils/format.js";

const command: Command = {
  name: "balance",
  description: "Check your wallet and bank",
  options: [{ name: "user", description: "Member to check", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    const u = await getUser(target.id);

    await ctx.reply({
      embeds: [{
        title: `${target.username}'s balance`,
        color: 0xf1c40f,
        fields: [
          { name: "Wallet", value: coins(u.balance), inline: true },
          { name: "Bank", value: coins(u.bank), inline: true },
          { name: "Net worth", value: coins(u.balance + u.bank), inline: true },
        ],
      }],
    });
  },
};

export default command;
