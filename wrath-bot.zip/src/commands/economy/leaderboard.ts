import { topUsers } from "../../db/index.js";
import type { Command } from "../../types.js";
import { coins } from "../../utils/format.js";

const command: Command = {
  name: "leaderboard",
  description: "Show the richest players",

  async execute(ctx) {
    const rows = await topUsers(10);
    // Mentions render as names inside embeds, so no extra user lookups are needed.
    const lines = rows.map((row, i) => `\`${i + 1}.\` <@${row.id}> — ${coins(row.total)}`);

    await ctx.reply({
      embeds: [{
        title: "🏆 Richest players",
        color: 0xf1c40f,
        description: lines.join("\n") || "Nobody yet.",
      }],
    });
  },
};

export default command;
