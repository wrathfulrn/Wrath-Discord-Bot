import { transfer } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "pay",
  description: "Send coins to another member",
  options: [
    { name: "user", description: "Recipient", type: OptionType.USER, required: true },
    {
      name: "amount",
      description: "How many coins",
      type: OptionType.INTEGER,
      required: true,
      min_value: 1,
    },
  ],

  async execute(ctx) {
    const target = ctx.user("user");
    const amount = ctx.int("amount") ?? 0;

    if (!target || target.bot || target.id === ctx.userId) {
      await ctx.reply(privateError("Pick a real person to pay."));
      return;
    }
    if (!(await transfer(ctx.userId, target.id, amount))) {
      await ctx.reply(privateError("You don't have enough coins."));
      return;
    }
    await ctx.reply(`💸 <@${ctx.userId}> paid <@${target.id}> ${coins(amount)}.`);
  },
};

export default command;
