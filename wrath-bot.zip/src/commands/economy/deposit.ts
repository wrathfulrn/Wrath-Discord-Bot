import { deposit } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "deposit",
  description: "Move coins from your wallet to your bank",
  options: [{
    name: "amount",
    description: "How many coins",
    type: OptionType.INTEGER,
    required: true,
    min_value: 1,
  }],

  async execute(ctx) {
    const amount = ctx.int("amount") ?? 0;

    if (!(await deposit(ctx.userId, amount))) {
      await ctx.reply(privateError("You don't have that many coins in your wallet."));
      return;
    }
    await ctx.reply(`🏦 Deposited ${coins(amount)} into your bank.`);
  },
};

export default command;
