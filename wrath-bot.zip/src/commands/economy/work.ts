import { config } from "../../config.js";
import { addBalance, getUser, markWorked } from "../../db/index.js";
import type { Command } from "../../types.js";
import { coins, cooldownLeft, cooldownNotice } from "../../utils/format.js";

const JOBS = [
  "coded a Discord bot",
  "delivered pizzas",
  "walked some dogs",
  "fixed a leaking sink",
  "streamed for six hours",
  "sold lemonade",
];

const command: Command = {
  name: "work",
  description: "Work a job for coins",

  async execute(ctx) {
    const u = await getUser(ctx.userId);
    const wait = cooldownLeft(u.lastWork, config.workCooldownMs);

    if (wait > 0) {
      await ctx.reply({ content: cooldownNotice(wait), ephemeral: true });
      return;
    }

    const [min, max] = config.workRange;
    const earned = min + Math.floor(Math.random() * (max - min + 1));
    const job = JOBS[Math.floor(Math.random() * JOBS.length)];

    await addBalance(ctx.userId, earned);
    await markWorked(ctx.userId, config.workXp);
    await ctx.reply(`🛠️ You ${job} and earned ${coins(earned)}.`);
  },
};

export default command;
