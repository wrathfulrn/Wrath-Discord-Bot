import type { Group } from "../../types.js";
import balance from "./balance.js";
import daily from "./daily.js";
import work from "./work.js";
import deposit from "./deposit.js";
import withdraw from "./withdraw.js";
import pay from "./pay.js";
import leaderboard from "./leaderboard.js";
import stats from "./stats.js";

const group: Group = {
  name: "economy",
  description: "Wallet, bank, jobs, and rankings",
  subcommands: [balance, daily, work, deposit, withdraw, pay, leaderboard, stats],
};

export default group;
