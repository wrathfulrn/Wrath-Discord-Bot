import { OptionType, type Command } from "../../types.js";
import { guildConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "starboard",
  description: "Set starboard channel and threshold",
  options: [
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
    { name: "min", description: "Minimum stars", type: OptionType.INTEGER, min_value: 1, max_value: 25 },
  ],
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const cfg = await guildConfig.getStarboard(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    cfg.channelId = ctx.channelId;
    const min = ctx.int("min");
    if (min !== undefined) cfg.minStars = min;
    await guildConfig.setStarboard(ctx.guildId, cfg);
    await ctx.reply(
      `Starboard **${cfg.enabled ? "on" : "off"}** → <#${ctx.channelId}> · min **${cfg.minStars}** ⭐\n` +
      `_React with ⭐ on messages; full reaction gateway event wiring posts when threshold is met._`,
    );
  },
};
export default command;
