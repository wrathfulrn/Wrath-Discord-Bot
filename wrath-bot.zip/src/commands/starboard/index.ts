import type { Group } from "../../types.js";
import starboard from "./starboard.js";
const group: Group = {
  name: "starboard",
  description: "Starboard highlights",
  guildOnly: true,
  subcommands: [starboard],
};
export default group;
