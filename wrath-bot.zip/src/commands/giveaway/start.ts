import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { saveGiveaway } from "../../db/guildConfig.js";

const command: Command = {
  name: "gstart",
  description: "Start a giveaway",
  options: [
    { name: "duration", description: "Minutes", type: OptionType.INTEGER, required: true, min_value: 1, max_value: 10080 },
    { name: "winners", description: "Winner count", type: OptionType.INTEGER, required: true, min_value: 1, max_value: 20 },
    { name: "prize", description: "Prize", type: OptionType.STRING, required: true },
  ],
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 13n)) {
      await ctx.reply(privateError("Need Manage Server or Manage Messages.")); return;
    }
    const mins = ctx.int("duration") ?? 10;
    const winners = ctx.int("winners") ?? 1;
    const prize = (ctx.str("prize") ?? "Prize").slice(0, 200);
    const id = `${ctx.guildId}-${Date.now()}`;
    const endsAt = Date.now() + mins * 60_000;
    await saveGiveaway({
      id,
      channelId: ctx.channelId,
      messageId: "",
      prize,
      endsAt,
      winners,
      hostId: ctx.userId,
      entries: [],
      ended: false,
    });
    await ctx.reply({
      embeds: [{
        title: "🎉 Giveaway",
        description: `**${prize}**\nWinners: **${winners}**\nEnds: <t:${Math.floor(endsAt / 1000)}:R>\nHost: <@${ctx.userId}>\n\nReact with 🎉 on the announcement (or use entry tracking in a full reaction build).\nID: \`${id}\``,
        color: 0xe91e63,
      }],
    });
  },
};
export default command;
