import type { Group } from "../../types.js";
import gstart from "./start.js";
const group: Group = {
  name: "giveaway",
  description: "Server giveaways",
  guildOnly: true,
  subcommands: [gstart],
};
export default group;
