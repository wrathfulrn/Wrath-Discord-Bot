import type { Command } from "../../types.js";

const command: Command = {
  name: "ping",
  description: "Check how quickly the bot responds",

  async execute(ctx) {
    // Time between Discord creating the interaction and the bot responding.
    const delay = Date.now() - ctx.createdAt;
    await ctx.reply(`🏓 Pong! Response delay: ${delay} ms`);
  },
};

export default command;
