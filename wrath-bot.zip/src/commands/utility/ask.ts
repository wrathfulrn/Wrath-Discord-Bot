import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { askLimits, consumeAsk, isPremium } from "../../db/premium.js";
import { askOpenAI, checkAskGate, markAskEnd, markAskStart } from "../../utils/openai.js";
import { config } from "../../config.js";

const command: Command = {
  name: "ask",
  description: "Ask the AI a question",
  options: [
    {
      name: "prompt",
      description: "Your question or prompt",
      type: OptionType.STRING,
      required: true,
    },
  ],

  async execute(ctx) {
    const prompt = (ctx.str("prompt") ?? "").trim();
    if (!prompt) {
      await ctx.reply(privateError("Ask me something — `,ask your question here`."));
      return;
    }
    if (prompt.length > 1500) {
      await ctx.reply(privateError("Keep questions under 1500 characters."));
      return;
    }

    const premium = await isPremium(ctx.userId);
    const limits = askLimits(premium);

    // Temporarily align OpenAI helper cooldown with plan
    process.env.OPENAI_COOLDOWN_MS = String(limits.cooldownMs);

    const gated = checkAskGate(ctx.userId);
    if (gated !== null) {
      await ctx.reply(privateError(gated.error));
      return;
    }

    const quota = await consumeAsk(ctx.userId, premium);
    if (!quota.ok) {
      await ctx.reply(privateError(quota.reason));
      return;
    }

    markAskStart(ctx.userId);
    await ctx.reply(`🤔 Thinking… (${quota.remaining} asks left today)`);

    try {
      const result = await askOpenAI(prompt, ctx.username);
      if (!result.ok) {
        await ctx.reply(privateError(result.error));
        return;
      }

      await ctx.reply({
        embeds: [
          {
            title: premium ? "⭐ Answer" : "💬 Answer",
            description: result.text.slice(0, 4000),
            color: premium ? 0xf5b942 : 0x6c5ce7,
            footer: {
              text: premium
                ? `Premium · ${ctx.username}`
                : `Free plan · ${ctx.username} · ,premium for ${config.premiumPriceLabel}`,
            },
          },
        ],
      });
    } finally {
      markAskEnd(ctx.userId);
    }
  },
};

export default command;
