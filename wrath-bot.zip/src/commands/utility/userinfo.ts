import { OptionType, type Command } from "../../types.js";
import { avatarUrl, discordDate, snowflakeTime } from "../../utils/format.js";

const command: Command = {
  name: "userinfo",
  description: "Show information about a member",
  options: [{ name: "user", description: "Member to inspect", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");

    await ctx.reply({
      embeds: [{
        title: target.username,
        color: 0x5865f2,
        thumbnail: { url: avatarUrl(target.id, target.avatar) },
        fields: [
          { name: "ID", value: target.id },
          { name: "Account created", value: discordDate(snowflakeTime(target.id)) },
          { name: "Bot", value: target.bot ? "Yes" : "No", inline: true },
        ],
      }],
    });
  },
};

export default command;
