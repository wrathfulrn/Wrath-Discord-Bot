import type { Group } from "../../types.js";
import help from "./help.js";
import ping from "./ping.js";
import userinfo from "./userinfo.js";
import serverinfo from "./serverinfo.js";
import avatar from "./avatar.js";
import about from "./about.js";
import invite from "./invite.js";
import uptime from "./uptime.js";
import ask from "./ask.js";
import premium from "./premium.js";
import redeem from "./redeem.js";

/** Core utility — kept under Discord's 25-subcommand limit. */
const group: Group = {
  name: "utility",
  description: "Help, info, AI, and premium",
  subcommands: [
    help,
    ask,
    premium,
    redeem,
    ping,
    userinfo,
    serverinfo,
    avatar,
    about,
    invite,
    uptime,
  ],
};

export default group;
