import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { botAvatar, commandView, homeView } from "../../utils/help.js";

const command: Command = {
  name: "help",
  description: "Open the help index, or show how to use one command",
  options: [{ name: "command", description: "Command name, e.g. pay", type: OptionType.STRING }],

  async execute(ctx) {
    const name = ctx.str("command");
    if (!name) {
      await ctx.reply(await homeView(botAvatar(), ctx.userId, ctx.guildId));
      return;
    }

    const view = commandView(name, ctx.userId, {
      username: ctx.username,
      avatarUrl: ctx.userAvatar,
    });
    if (!view) {
      await ctx.reply(privateError(`There's no command called \`${name}\`.`));
      return;
    }
    await ctx.reply(view);
  },
};

export default command;
