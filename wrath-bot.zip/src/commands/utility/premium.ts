import { config } from "../../config.js";
import { getPremiumStatus } from "../../db/premium.js";
import type { Command } from "../../types.js";

const command: Command = {
  name: "premium",
  description: "View premium status and how to upgrade (£5)",

  async execute(ctx) {
    const status = await getPremiumStatus(ctx.userId);
    const price = config.premiumPriceLabel;
    const link = config.premiumUrl?.trim();

    const lines: string[] = [];
    if (status.active) {
      if (status.viaRole) {
        lines.push("**Status:** Active (premium role)");
      } else {
        const until = status.until
          ? `<t:${Math.floor(status.until / 1000)}:F> (<t:${Math.floor(status.until / 1000)}:R>)`
          : "active";
        lines.push(`**Status:** Active until ${until}`);
      }
    } else {
      lines.push("**Status:** Free plan");
    }

    lines.push("");
    lines.push(`**Price:** ${price}`);
    lines.push("**Premium perks**");
    lines.push(`• \`,ask\` — ${config.askDailyPremium}/day (free: ${config.askDailyFree}) · faster cooldown`);
    lines.push(`• Pets — up to **${config.maxPetsPremium}** (free: ${config.maxPetsFree})`);
    lines.push("• Premium badge on `,premium`");
    lines.push("");
    if (link) {
      lines.push(`**Subscribe / pay:** ${link}`);
      lines.push("After paying, the owner will activate your account, or use a redeem code: `,redeem CODE`");
    } else {
      lines.push("**How to buy:** Message the bot owner after paying. Set `PREMIUM_URL` in `.env` to show your Stripe/Ko-fi/Patreon link here.");
      lines.push("Or redeem a code: `,redeem CODE`");
    }

    await ctx.reply({
      embeds: [
        {
          title: status.active ? "⭐ Premium" : "⭐ Premium — upgrade",
          description: lines.join("\n"),
          color: status.active ? 0xf5b942 : 0x6c5ce7,
          footer: { text: `${price} · ,redeem <code>` },
        },
      ],
    });
  },
};

export default command;
