import { config } from "../../config.js";
import type { Command } from "../../types.js";
import { allGroups } from "../../utils/help.js";

const command: Command = {
  name: "about",
  description: "Show what the bot is and what it can do",

  async execute(ctx) {
    const groups = allGroups();
    const total = groups.reduce((n, g) => n + g.subcommands.length, 0);

    const fields = [
      { name: "Prefix", value: `\`${config.prefix}\``, inline: true },
      { name: "Commands", value: String(total), inline: true },
      { name: "Categories", value: String(groups.length), inline: true },
    ];
    if (config.supportServer) {
      fields.push({ name: "Support", value: config.supportServer, inline: false });
    }

    await ctx.reply({
      embeds: [{
        title: config.botName,
        description: config.botBio,
        color: 0x9b1b30,
        fields,
      }],
    });
  },
};

export default command;
