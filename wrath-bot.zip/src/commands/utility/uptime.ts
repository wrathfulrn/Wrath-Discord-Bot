import type { Command } from "../../types.js";

const command: Command = {
  name: "uptime",
  description: "Show how long Wrath has been running",
  async execute(ctx) {
    const total = Math.floor(process.uptime());
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    await ctx.reply({ embeds: [{ title: "⏱️ Wrath uptime", description: `Running for **${days}d ${hours}h ${minutes}m ${seconds}s**.`, color: 0x8b7cff, footer: { text: "Wrath • Status" } }] });
  },
};
export default command;
