import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { redeemPremiumCode } from "../../db/premium.js";

const command: Command = {
  name: "redeem",
  description: "Redeem a premium code",
  options: [
    {
      name: "code",
      description: "The premium code",
      type: OptionType.STRING,
      required: true,
    },
  ],

  async execute(ctx) {
    const code = ctx.str("code") ?? "";
    const result = await redeemPremiumCode(ctx.userId, code);
    if (!result.ok) {
      await ctx.reply(privateError(result.reason));
      return;
    }
    await ctx.reply({
      embeds: [
        {
          title: "⭐ Premium activated",
          description: [
            `Code redeemed for **${result.days}** day(s).`,
            `Active until <t:${Math.floor(result.until / 1000)}:F>.`,
            "Thanks for supporting the bot!",
          ].join("\n"),
          color: 0xf5b942,
        },
      ],
    });
  },
};

export default command;
