import { config } from "../../config.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

/**
 * Permissions the bot asks for when invited:
 * View Channels (1024), Send Messages (2048), Embed Links (16384),
 * Kick Members (2), Ban Members (4), Manage Messages (8192),
 * Moderate Members (1 << 40).
 */
const PERMISSIONS = 1024n + 2048n + 16384n + 2n + 4n + 8192n + (1n << 40n);

const ACTION_ROW = 1;
const BUTTON = 2;
const LINK_STYLE = 5;

const command: Command = {
  name: "invite",
  description: "Get a button to add the bot to a server",

  async execute(ctx) {
    if (!config.clientId) {
      await ctx.reply(privateError("CLIENT_ID is not set, so I can't build an invite link."));
      return;
    }

    const url =
      `https://discord.com/oauth2/authorize?client_id=${config.clientId}` +
      `&scope=bot%20applications.commands&permissions=${PERMISSIONS}`;

    await ctx.reply({
      embeds: [{
        title: `Add ${config.botName} to your server`,
        description: "Use the button below to choose a server and approve the permissions.",
        color: 0x9b1b30,
      }],
      components: [{
        type: ACTION_ROW,
        components: [{
          type: BUTTON,
          style: LINK_STYLE,
          label: "Invite",
          url,
        }],
      }],
    });
  },
};

export default command;
