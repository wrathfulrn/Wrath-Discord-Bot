import { OptionType, type Command } from "../../types.js";
import { avatarUrl } from "../../utils/format.js";

const command: Command = {
  name: "avatar",
  description: "Show a member's avatar",
  options: [{ name: "user", description: "Member", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");

    await ctx.reply({
      embeds: [{
        title: `${target.username}'s avatar`,
        color: 0x5865f2,
        image: { url: avatarUrl(target.id, target.avatar) },
      }],
    });
  },
};

export default command;
