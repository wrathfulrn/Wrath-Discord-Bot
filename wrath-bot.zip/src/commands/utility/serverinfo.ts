import type { Command } from "../../types.js";
import { discordDate, privateError, snowflakeTime } from "../../utils/format.js";

const command: Command = {
  name: "serverinfo",
  description: "Show information about this server",

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("This command only works in a server."));
      return;
    }

    // Only the data derivable from the ID is shown. Add a Discordeno guild
    // fetch in src/discord.ts to show member counts, owner, and so on.
    await ctx.reply({
      embeds: [{
        title: "Server info",
        color: 0x1abc9c,
        fields: [
          { name: "Server ID", value: ctx.guildId },
          { name: "Created", value: discordDate(snowflakeTime(ctx.guildId)) },
        ],
      }],
    });
  },
};

export default command;
