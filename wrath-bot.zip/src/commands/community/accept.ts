import { getPartner, getProposal, marry, setProposal } from "../../db/features.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "accept",
  description: "Accept a pending marriage proposal",

  async execute(ctx) {
    const proposer = await getProposal(ctx.userId);
    if (!proposer) {
      await ctx.reply(privateError("You have no pending proposal."));
      return;
    }
    if ((await getPartner(ctx.userId)) || (await getPartner(proposer))) {
      await setProposal(ctx.userId, null);
      await ctx.reply(privateError("One of you is already married, so this proposal has expired."));
      return;
    }

    const married = await marry(ctx.userId, proposer);
    await setProposal(ctx.userId, null);
    if (!married) {
      await ctx.reply(privateError("Couldn't complete the marriage. Please try again."));
      return;
    }
    await ctx.reply(`💞 <@${proposer}> and <@${ctx.userId}> are now married!`);
  },
};

export default command;
