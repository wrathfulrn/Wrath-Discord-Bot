import { getPartner, setProposal } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "marry",
  description: "Propose to another player",
  options: [{ name: "user", description: "Who to propose to", type: OptionType.USER, required: true }],

  async execute(ctx) {
    const target = ctx.user("user");
    if (!target || target.bot || target.id === ctx.userId) {
      await ctx.reply(privateError("Pick someone else to propose to."));
      return;
    }
    if (await getPartner(ctx.userId)) {
      await ctx.reply(privateError("You're already married. Use `,divorce` first."));
      return;
    }
    if (await getPartner(target.id)) {
      await ctx.reply(privateError(`<@${target.id}> is already married.`));
      return;
    }

    await setProposal(target.id, ctx.userId);
    await ctx.reply(`💍 <@${ctx.userId}> has proposed to <@${target.id}>. <@${target.id}> can answer with \`,accept\`.`);
  },
};

export default command;
