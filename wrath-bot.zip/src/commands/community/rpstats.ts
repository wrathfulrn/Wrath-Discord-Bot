import { getRp } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";

const command: Command = {
  name: "rpstats",
  description: "Show a player's roleplay stats",
  options: [{ name: "user", description: "Player to check", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    const stats = await getRp(target.id);

    await ctx.reply({
      embeds: [{
        title: `${target.username}'s roleplay stats`,
        fields: [
          { name: "Sent", value: String(stats.sent), inline: true },
          { name: "Received", value: String(stats.received), inline: true },
          { name: "Total", value: String(stats.sent + stats.received), inline: true },
        ],
      }],
    });
  },
};

export default command;
