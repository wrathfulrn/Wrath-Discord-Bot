import { rankPlayers, type RankMetric } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";

const METRICS: RankMetric[] = ["wealth", "wins", "xp", "rp"];

const command: Command = {
  name: "ranks",
  description: "Show the top players for a stat",
  options: [{
    name: "metric",
    description: "Which stat to rank by (default: wealth)",
    type: OptionType.STRING,
    choices: METRICS.map((m) => ({ name: m, value: m })),
  }],

  async execute(ctx) {
    const metric = (ctx.str("metric") ?? "wealth") as RankMetric;
    const rows = await rankPlayers(metric, 10);

    const lines = rows.map((r, i) => `\`${i + 1}.\` <@${r.id}>: ${r.score.toLocaleString("en-GB")}`);
    await ctx.reply({
      embeds: [{
        title: `Top players by ${metric}`,
        description: lines.join("\n") || "Nobody has a score yet.",
      }],
    });
  },
};

export default command;
