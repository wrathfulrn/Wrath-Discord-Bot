import { setAfk } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";

const command: Command = {
  name: "afk",
  description: "Mark yourself as away. Mentions of you will show the reason.",
  options: [{ name: "reason", description: "Why you're away", type: OptionType.STRING }],

  async execute(ctx) {
    const reason = ctx.str("reason") ?? "AFK";
    await setAfk(ctx.userId, { reason, since: Date.now() });
    await ctx.reply(`<@${ctx.userId}> is now AFK: ${reason}`);
  },
};

export default command;
