import { divorce, getPartner } from "../../db/features.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "divorce",
  description: "End your marriage",

  async execute(ctx) {
    const partner = await getPartner(ctx.userId);
    if (!partner) {
      await ctx.reply(privateError("You're not married."));
      return;
    }
    await divorce(ctx.userId);
    await ctx.reply(`💔 <@${ctx.userId}> and <@${partner}> are no longer married.`);
  },
};

export default command;
