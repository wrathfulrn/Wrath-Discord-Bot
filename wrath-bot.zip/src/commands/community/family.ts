import { getPartner } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";

const command: Command = {
  name: "family",
  description: "Show a player's family",
  options: [{ name: "user", description: "Player to check", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    const partner = await getPartner(target.id);

    await ctx.reply({
      embeds: [{
        title: `${target.username}'s family`,
        fields: [{ name: "Spouse", value: partner ? `<@${partner}>` : "None", inline: true }],
      }],
    });
  },
};

export default command;
