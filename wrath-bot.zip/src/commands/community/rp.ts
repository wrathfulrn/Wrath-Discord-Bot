import { bumpRp } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const ACTIONS: { id: string; text: string }[] = [
  { id: "duel", text: "{a} challenges {b} to a duel." },
  { id: "heal", text: "{a} heals {b} with a glowing potion." },
  { id: "curse", text: "{a} places a curse on {b}. Beware." },
  { id: "bless", text: "{a} blesses {b} with good fortune." },
  { id: "rescue", text: "{a} rescues {b} from a dragon's lair." },
];

const command: Command = {
  name: "rp",
  description: "Act out a roleplay moment with another player",
  options: [
    {
      name: "action",
      description: "What to do",
      type: OptionType.STRING,
      required: true,
      choices: ACTIONS.map((a) => ({ name: a.id, value: a.id })),
    },
    { name: "user", description: "Player to act on", type: OptionType.USER, required: true },
  ],

  async execute(ctx) {
    const action = ACTIONS.find((a) => a.id === ctx.str("action"));
    const target = ctx.user("user");
    if (!action || !target || target.bot || target.id === ctx.userId) {
      await ctx.reply(privateError("Pick a roleplay action and another player."));
      return;
    }

    await bumpRp(ctx.userId, "sent");
    await bumpRp(target.id, "received");

    const text = action.text
      .replace("{a}", `<@${ctx.userId}>`)
      .replace("{b}", `<@${target.id}>`);
    await ctx.reply(text);
  },
};

export default command;
