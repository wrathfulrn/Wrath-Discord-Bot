import type { Group } from "../../types.js";
import afk from "./afk.js";
import marry from "./marry.js";
import accept from "./accept.js";
import divorce from "./divorce.js";
import family from "./family.js";
import rp from "./rp.js";
import rpstats from "./rpstats.js";
import ranks from "./ranks.js";

const group: Group = {
  name: "community",
  description: "AFK, marriage and family, roleplay, and rankings",
  subcommands: [afk, marry, accept, divorce, family, rp, rpstats, ranks],
};

export default group;
