import { config } from "../../config.js";
import { kv, getUser, updateUser, addWarning, clearWarnings } from "../../db/index.js";
import { setChannelLocked, ban, kick, setNickname } from "../../discord.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const isOwner = (ctx: Parameters<Command["execute"]>[0]) => Boolean(config.ownerId) && ctx.userId === config.ownerId;
const guard = async (ctx: Parameters<Command["execute"]>[0]) => {
  if (isOwner(ctx)) return true;
  await ctx.reply(privateError("Only the bot owner can use this command."));
  return false;
};
const command = (name: string, description: string, options: NonNullable<Command["options"]>, run: Command["execute"]): Command => ({
  name, description, options,
  async execute(ctx) { if (!(await guard(ctx))) return; await run(ctx); },
});
const userOption = { name: "user", description: "Target member", type: OptionType.USER, required: true };
const textOption = (name: string, description: string, required = true) => ({ name, description, type: OptionType.STRING, required });

export const ownerStats = command("owner-stats", "Show bot and database statistics", [], async (ctx) => {
  let users = 0, farms = 0, warnings = 0, pets = 0, jobs = 0;
  for await (const e of kv.list<unknown>({ prefix: ["users"] })) users++;
  for await (const e of kv.list<unknown>({ prefix: ["farm"] })) farms++;
  for await (const e of kv.list<unknown>({ prefix: ["warnings"] })) warnings++;
  for await (const e of kv.list<unknown>({ prefix: ["pets"] })) pets++;
  for await (const e of kv.list<unknown>({ prefix: ["jobs"] })) jobs++;
  await ctx.reply({ embeds: [{ title: "👑 Wrath Owner Diagnostics", color: 0x8b5cf6, fields: [
    { name: "Users", value: String(users), inline: true }, { name: "Farms", value: String(farms), inline: true },
    { name: "Warning records", value: String(warnings), inline: true }, { name: "Pet records", value: String(pets), inline: true },
    { name: "Job records", value: String(jobs), inline: true }, { name: "Prefix", value: `\`${config.prefix}\``, inline: true },
  ], footer: { text: "Wrath • Owner only" }, timestamp: new Date().toISOString() }] });
});

export const ownerConfig = command("owner-config", "Show safe bot configuration (secrets hidden)", [], async (ctx) => {
  await ctx.reply({ embeds: [{ title: "⚙️ Wrath Configuration", color: 0x8b5cf6, fields: [
    { name: "Bot name", value: config.botName, inline: true }, { name: "Prefix", value: `\`${config.prefix}\``, inline: true },
    { name: "Database path", value: `\`${config.dbPath}\``, inline: false }, { name: "Owner configured", value: config.ownerId ? "Yes" : "No — set OWNER_ID", inline: true },
    { name: "Token", value: "Hidden", inline: true },
  ] }] });
});

export const ownerAnnounce = command("owner-announce", "Post a violet-and-gold announcement in this channel", [textOption("title", "Announcement title"), textOption("message", "Announcement message")], async (ctx) => {
  if (!ctx.channelId) { await ctx.reply(privateError("Use this in a server channel.")); return; }
  const title = (ctx.str("title") ?? "Announcement").slice(0, 256);
  const message = (ctx.str("message") ?? "").slice(0, 4000);
  if (!message.trim()) { await ctx.reply(privateError("Message cannot be empty.")); return; }
  try {
    await ctx.bot.helpers.sendMessage(ctx.channelId, { embeds: [{ title, description: message, color: 0x8b5cf6, footer: { text: "Wrath • Owner announcement" }, timestamp: new Date().toISOString() }] } as never);
    await ctx.reply("📣 Announcement posted.");
  } catch { await ctx.reply(privateError("Couldn't post. Check the bot's channel permissions.")); }
});

export const ownerEmbed = command("owner-embed", "Send a custom embed in this channel", [textOption("title", "Embed title"), textOption("description", "Embed description")], async (ctx) => {
  if (!ctx.channelId) { await ctx.reply(privateError("Use this in a server channel.")); return; }
  try {
    await ctx.bot.helpers.sendMessage(ctx.channelId, { embeds: [{ title: (ctx.str("title") ?? "Wrath").slice(0, 256), description: (ctx.str("description") ?? "").slice(0, 4000), color: 0x8b5cf6, footer: { text: "Wrath • Violet & Gold" } }] } as never);
    await ctx.reply("✅ Embed sent.");
  } catch { await ctx.reply(privateError("Couldn't send the embed. Check Embed Links permission.")); }
});

export const ownerLock = command("owner-lockdown", "Lock the current channel", [], async (ctx) => {
  if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Use this in a server channel.")); return; }
  try { await setChannelLocked(ctx.bot, ctx.guildId, ctx.channelId, true); await ctx.reply("🔒 Channel locked."); }
  catch { await ctx.reply(privateError("Couldn't lock this channel. Check Manage Channels permission.")); }
});
export const ownerUnlock = command("owner-unlock", "Unlock the current channel", [], async (ctx) => {
  if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Use this in a server channel.")); return; }
  try { await setChannelLocked(ctx.bot, ctx.guildId, ctx.channelId, false); await ctx.reply("🔓 Channel unlocked."); }
  catch { await ctx.reply(privateError("Couldn't unlock this channel. Check Manage Channels permission.")); }
});
export const ownerBan = command("owner-ban", "Ban a member (owner override)", [userOption, textOption("reason", "Reason", false)], async (ctx) => {
  const target = ctx.user("user"); if (!ctx.guildId || !target) { await ctx.reply(privateError("Use this in a server and specify a member.")); return; }
  try { await ban(ctx.bot, ctx.guildId, target.id, `Owner ${ctx.username}: ${ctx.str("reason") ?? "No reason given"}`); await ctx.reply(`🔨 Banned <@${target.id}>.`); }
  catch { await ctx.reply(privateError("Couldn't ban that member. Check the bot's permissions and role position.")); }
});
export const ownerKick = command("owner-kick", "Kick a member (owner override)", [userOption, textOption("reason", "Reason", false)], async (ctx) => {
  const target = ctx.user("user"); if (!ctx.guildId || !target) { await ctx.reply(privateError("Use this in a server and specify a member.")); return; }
  try { await kick(ctx.bot, ctx.guildId, target.id, `Owner ${ctx.username}: ${ctx.str("reason") ?? "No reason given"}`); await ctx.reply(`👢 Kicked <@${target.id}>.`); }
  catch { await ctx.reply(privateError("Couldn't kick that member. Check the bot's permissions and role position.")); }
});
export const ownerWarn = command("owner-warn", "Add a moderation warning to a member", [userOption, textOption("reason", "Warning reason")], async (ctx) => {
  const target = ctx.user("user"); if (!ctx.guildId || !target) { await ctx.reply(privateError("Use this in a server and specify a member.")); return; }
  const count = await addWarning(ctx.guildId, target.id, ctx.str("reason") ?? "No reason given");
  await ctx.reply(`⚠️ Warned <@${target.id}>. They now have **${count}** warning(s).`);
});
export const ownerClearWarnings = command("owner-clear-warnings", "Clear a member's warnings", [userOption], async (ctx) => {
  const target = ctx.user("user"); if (!ctx.guildId || !target) { await ctx.reply(privateError("Use this in a server and specify a member.")); return; }
  const count = await clearWarnings(ctx.guildId, target.id); await ctx.reply(`✅ Cleared **${count}** warning(s) for <@${target.id}>.`);
});
export const ownerNickname = command("owner-nickname", "Set or reset a member nickname", [userOption, textOption("nickname", "New nickname, or 'reset'")], async (ctx) => {
  const target = ctx.user("user"); if (!ctx.guildId || !target) { await ctx.reply(privateError("Use this in a server and specify a member.")); return; }
  const raw = ctx.str("nickname") ?? "reset"; const nick = raw.toLowerCase() === "reset" ? null : raw.slice(0, 32);
  try { await setNickname(ctx.bot, ctx.guildId, target.id, nick, `Owner ${ctx.username}`); await ctx.reply(nick ? `✅ Set <@${target.id}>'s nickname to **${nick}**.` : `✅ Reset <@${target.id}>'s nickname.`); }
  catch { await ctx.reply(privateError("Couldn't change that nickname. Check Manage Nicknames permission.")); }
});

export const ownerUserInfo = command("owner-user-info", "Inspect a user's economy data", [userOption], async (ctx) => {
  const target = ctx.user("user"); if (!target) { await ctx.reply(privateError("Specify a user.")); return; }
  const u = await getUser(target.id);
  await ctx.reply({ embeds: [{ title: "👑 Owner User Lookup", description: `<@${target.id}>`, color: 0x8b5cf6, fields: [
    { name: "Wallet", value: u.balance.toLocaleString("en-GB"), inline: true }, { name: "Bank", value: u.bank.toLocaleString("en-GB"), inline: true },
    { name: "Points / XP", value: u.xp.toLocaleString("en-GB"), inline: true }, { name: "Wins / losses", value: `${u.wins} / ${u.losses}`, inline: true },
    { name: "Inventory item types", value: String(Object.keys(u.inventory ?? {}).length), inline: true },
  ] }] });
});

export const ownerFarmReset = command("owner-farm-reset", "Reset a member's farm plots", [userOption], async (ctx) => {
  const target = ctx.user("user"); if (!target) { await ctx.reply(privateError("Specify a user.")); return; }
  const key = ["farm", target.id] as const; const current = await kv.get<unknown[]>(key);
  const blank = [null, null, null, null];
  const result = await kv.atomic().check({ key, versionstamp: current.versionstamp }).set(key, blank).commit();
  if (!result.ok) { await ctx.reply(privateError("Farm changed during the update. Please try again.")); return; }
  await ctx.reply(`🌾 Reset the farm plots for <@${target.id}>.`);
});

export const ownerInventoryClear = command("owner-inventory-clear", "Clear a member's inventory", [userOption], async (ctx) => {
  const target = ctx.user("user"); if (!target) { await ctx.reply(privateError("Specify a user.")); return; }
  const ok = await updateUser(target.id, (u) => { u.inventory = {}; return true; });
  await ctx.reply(ok ? `🎒 Cleared the inventory for <@${target.id}>.` : privateError("Couldn't update that account."));
});

export const ownerCustomAdd = command("owner-custom-add", "Create or replace a custom text command for this server", [textOption("name", "Command name (one word)"), textOption("response", "Response text")], async (ctx) => {
  if (!ctx.guildId) { await ctx.reply(privateError("Custom commands require a server.")); return; }
  const name = (ctx.str("name") ?? "").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 32);
  const response = (ctx.str("response") ?? "").slice(0, 1800);
  if (!name || name === "owner" || !response.trim() || name.startsWith("owner-")) { await ctx.reply(privateError("Use a valid one-word name and a non-empty response. Reserved owner names cannot be used.")); return; }
  const key = ["customCommands", ctx.guildId, name] as const; const current = await kv.get<string>(key);
  const result = await kv.atomic().check({ key, versionstamp: current.versionstamp }).set(key, response).commit();
  await ctx.reply(result.ok ? `✅ Custom command \`${config.prefix}${name}\` saved.` : privateError("That command changed at the same time. Try again."));
});

export const ownerCustomRemove = command("owner-custom-remove", "Delete a custom command from this server", [textOption("name", "Command name")], async (ctx) => {
  if (!ctx.guildId) { await ctx.reply(privateError("Custom commands require a server.")); return; }
  const name = (ctx.str("name") ?? "").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 32);
  const key = ["customCommands", ctx.guildId, name] as const; const current = await kv.get<string>(key);
  if (current.value === null) { await ctx.reply(privateError("That custom command doesn't exist.")); return; }
  const result = await kv.atomic().check({ key, versionstamp: current.versionstamp }).set(key, "").commit();
  await ctx.reply(result.ok ? `🗑️ Removed custom command \`${config.prefix}${name}\`.` : privateError("That command changed at the same time. Try again."));
});

function timeoutMs(raw: string): number | null {
  const m = raw.trim().match(/^(\d+)(s|m|h|d)$/i); if (!m) return null;
  const amount = Number(m[1]); const unit = m[2].toLowerCase();
  const ms = amount * ({ s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }[unit] ?? 0);
  return ms > 0 && ms <= 28 * 86_400_000 ? ms : null;
}
export const ownerTimeout = command("owner-timeout", "Timeout a member (owner override; max 28 days)", [userOption, textOption("duration", "Duration like 10m, 2h, or 1d"), textOption("reason", "Reason", false)], async (ctx) => {
  const target = ctx.user("user"); if (!ctx.guildId || !target) { await ctx.reply(privateError("Use this in a server and specify a member.")); return; }
  const duration = timeoutMs(ctx.str("duration") ?? ""); if (!duration) { await ctx.reply(privateError("Use a duration such as 10m, 2h, or 1d (maximum 28 days).")); return; }
  try { await ctx.bot.helpers.editMember(ctx.guildId, target.id, { communicationDisabledUntil: new Date(Date.now() + duration) } as never); await ctx.reply(`⏳ Timed out <@${target.id}> for **${ctx.str("duration")}**. Reason: ${(ctx.str("reason") ?? "No reason provided").slice(0, 300)}`); }
  catch { await ctx.reply(privateError("Couldn't timeout that member. Check the bot's permissions and role position.")); }
});
export const ownerUntimeout = command("owner-untimeout", "Remove a member timeout (owner override)", [userOption], async (ctx) => {
  const target = ctx.user("user"); if (!ctx.guildId || !target) { await ctx.reply(privateError("Use this in a server and specify a member.")); return; }
  try { await ctx.bot.helpers.editMember(ctx.guildId, target.id, { communicationDisabledUntil: null } as never); await ctx.reply(`✅ Removed the timeout for <@${target.id}>.`); }
  catch { await ctx.reply(privateError("Couldn't remove that timeout. Check the bot's permissions and role position.")); }
});
export const ownerUnban = command("owner-unban", "Unban a user by Discord ID (owner override)", [textOption("user_id", "Numeric Discord user ID"), textOption("reason", "Reason", false)], async (ctx) => {
  if (!ctx.guildId) { await ctx.reply(privateError("Use this in a server.")); return; }
  const id = (ctx.str("user_id") ?? "").trim(); if (!/^\d{17,20}$/.test(id)) { await ctx.reply(privateError("Enter a valid numeric Discord user ID.")); return; }
  try { const h = ctx.bot.helpers as unknown as { unbanMember: (guildId: string, userId: string, reason?: string) => Promise<unknown> }; await h.unbanMember(ctx.guildId, id, (ctx.str("reason") ?? `Owner ${ctx.username}`).slice(0, 400)); await ctx.reply(`✅ Unbanned <@${id}>.`); }
  catch { await ctx.reply(privateError("Couldn't unban that user. Confirm they're banned and check bot permissions.")); }
});
