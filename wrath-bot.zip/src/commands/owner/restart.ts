import { config } from "../../config.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "restart",
  description: "Restart the bot (bot owner only)",

  async execute(ctx) {
    if (!config.ownerId || ctx.userId !== config.ownerId) {
      await ctx.reply(privateError("Only the bot owner can do that."));
      return;
    }

    await ctx.reply("🔄 Restarting. I'll be back in a moment.");
    // The host must restart the process when it exits.
    setTimeout(() => process.exit(0), 1500);
  },
};

export default command;
