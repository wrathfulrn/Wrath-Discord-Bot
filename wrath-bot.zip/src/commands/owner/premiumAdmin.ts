import { config } from "../../config.js";
import { createPremiumCode, grantPremium, revokePremium } from "../../db/premium.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

function assertOwner(ctx: { userId: string }): string | null {
  if (!config.ownerId || ctx.userId !== config.ownerId) {
    return "Owner only.";
  }
  return null;
}

export const grantpremium: Command = {
  name: "grantpremium",
  description: "Grant premium to a user (owner)",
  options: [
    { name: "user", description: "User", type: OptionType.USER, required: true },
    {
      name: "days",
      description: "Days of premium (default from PREMIUM_DAYS)",
      type: OptionType.INTEGER,
      required: false,
      min_value: 1,
      max_value: 3650,
    },
  ],
  async execute(ctx) {
    const err = assertOwner(ctx);
    if (err) {
      await ctx.reply(privateError(err));
      return;
    }
    const user = ctx.user("user");
    if (!user) {
      await ctx.reply(privateError("Mention a user."));
      return;
    }
    const days = ctx.int("days") ?? config.premiumDays;
    const until = await grantPremium(user.id, days);
    await ctx.reply(
      `⭐ Granted **${days}** day(s) of premium to **${user.username}** (until <t:${Math.floor(until / 1000)}:F>).`,
    );
  },
};

export const revokepremium: Command = {
  name: "revokepremium",
  description: "Revoke a user's premium (owner)",
  options: [{ name: "user", description: "User", type: OptionType.USER, required: true }],
  async execute(ctx) {
    const err = assertOwner(ctx);
    if (err) {
      await ctx.reply(privateError(err));
      return;
    }
    const user = ctx.user("user");
    if (!user) {
      await ctx.reply(privateError("Mention a user."));
      return;
    }
    await revokePremium(user.id);
    await ctx.reply(`Revoked premium for **${user.username}**.`);
  },
};

export const gencode: Command = {
  name: "gencode",
  description: "Create a premium redeem code (owner)",
  options: [
    {
      name: "days",
      description: "Days the code grants",
      type: OptionType.INTEGER,
      required: true,
      min_value: 1,
      max_value: 3650,
    },
    {
      name: "uses",
      description: "How many times it can be redeemed (default 1)",
      type: OptionType.INTEGER,
      required: false,
      min_value: 1,
      max_value: 1000,
    },
  ],
  async execute(ctx) {
    const err = assertOwner(ctx);
    if (err) {
      await ctx.reply(privateError(err));
      return;
    }
    const days = ctx.int("days") ?? 30;
    const uses = ctx.int("uses") ?? 1;
    const code = await createPremiumCode(days, uses);
    await ctx.reply({
      embeds: [
        {
          title: "Premium code created",
          description: [
            `**Code:** \`${code}\``,
            `**Days:** ${days}`,
            `**Max uses:** ${uses}`,
            "",
            `User redeems with: \`,redeem ${code}\``,
          ].join("\n"),
          color: 0xf5b942,
        },
      ],
    });
  },
};
