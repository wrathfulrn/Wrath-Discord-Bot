import type { Group } from "../../types.js";
import restart from "./restart.js";
import update from "./update.js";
import { giveMoney, removeMoney, setMoney, givePoints, removePoints, setPoints } from "./economy.js";
import { ownerStats, ownerConfig, ownerAnnounce, ownerEmbed, ownerLock, ownerUnlock, ownerUserInfo } from "./admin.js";
import { grantpremium, revokepremium, gencode } from "./premiumAdmin.js";

const group: Group = {
  name: "owner",
  description: "Owner-only economy, configuration, announcements, and diagnostics",
  subcommands: [
    giveMoney, removeMoney, setMoney, givePoints, removePoints, setPoints,
    ownerStats, ownerConfig, ownerAnnounce, ownerEmbed, ownerLock, ownerUnlock,
    ownerUserInfo, grantpremium, revokepremium, gencode, restart, update,
  ],
};

export default group;
