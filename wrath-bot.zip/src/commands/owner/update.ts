import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { config } from "../../config.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const run = promisify(execFile);

const command: Command = {
  name: "update",
  description: "Pull the latest code, rebuild, and restart (bot owner only)",

  async execute(ctx) {
    if (!config.ownerId || ctx.userId !== config.ownerId) {
      await ctx.reply(privateError("Only the bot owner can do that."));
      return;
    }

    await ctx.reply("⬆️ Pulling the latest code and rebuilding…");
    try {
      const pull = (await run("git", ["pull"], { cwd: process.cwd() })) as unknown as { stdout: string };
      await run("npm", ["run", "build"], { cwd: process.cwd() });
      await ctx.reply(`✅ Updated. ${pull.stdout.trim().slice(0, 300)}\nRestarting now.`);
    } catch (error) {
      await ctx.reply(privateError(`Update failed: ${String(error).slice(0, 300)}`));
      return;
    }

    setTimeout(() => process.exit(0), 1500);
  },
};

export default command;
