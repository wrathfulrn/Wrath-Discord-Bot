import { config } from "../../config.js";
import { getUser, updateUser } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

function ownerOnly(ctx: Parameters<Command["execute"]>[0]): boolean {
  return Boolean(config.ownerId) && ctx.userId === config.ownerId;
}
function amountOf(raw: string | undefined): number | null {
  if (!raw || !/^\d+$/.test(raw)) return null;
  const value = Number(raw);
  // Current economy fields are JavaScript numbers; refuse values that would silently lose integer precision.
  if (!Number.isSafeInteger(value) || value < 0) return null;
  return value;
}
function command(name: string, description: string, field: "balance" | "xp", mode: "add" | "remove" | "set"): Command {
  return {
    name,
    description,
    options: [
      { name: "user", description: "Member to change", type: OptionType.USER, required: true },
      { name: "amount", description: "Whole-number amount", type: OptionType.STRING, required: true },
    ],
    async execute(ctx) {
      if (!ownerOnly(ctx)) { await ctx.reply(privateError("Only the bot owner can use this command.")); return; }
      const target = ctx.user("user");
      const amount = amountOf(ctx.str("amount"));
      if (!target || amount === null) {
        await ctx.reply(privateError("Use a non-negative whole number within JavaScript's safe-integer range (up to 9,007,199,254,740,991)."));
        return;
      }
      const ok = await updateUser(target.id, (u) => {
        if (mode === "set") u[field] = amount;
        else if (mode === "add") u[field] += amount;
        else u[field] = Math.max(0, u[field] - amount);
        return true;
      });
      if (!ok) { await ctx.reply(privateError("Could not update that account. Please try again.")); return; }
      const updated = await getUser(target.id);
      await ctx.reply({ embeds: [{
        title: "👑 Wrath Owner Economy",
        description: `${mode === "add" ? "Added" : mode === "remove" ? "Removed" : "Set"} **${amount.toLocaleString("en-GB")}** ${field === "balance" ? "coins" : "points (XP)"} ${mode === "set" ? "for" : mode === "remove" ? "from" : "to"} <@${target.id}>.`,
        color: 0x8b5cf6,
        fields: [{ name: field === "balance" ? "New wallet balance" : "New points (XP)", value: updated[field].toLocaleString("en-GB"), inline: true }],
      }] });
    },
  };
}

export const giveMoney = command("give-money", "Give coins to a member (owner only)", "balance", "add");
export const removeMoney = command("remove-money", "Remove coins from a member (owner only)", "balance", "remove");
export const setMoney = command("set-money", "Set a member's wallet coins (owner only)", "balance", "set");
export const givePoints = command("give-points", "Give points/XP to a member (owner only)", "xp", "add");
export const removePoints = command("remove-points", "Remove points/XP from a member (owner only)", "xp", "remove");
export const setPoints = command("set-points", "Set a member's points/XP (owner only)", "xp", "set");
