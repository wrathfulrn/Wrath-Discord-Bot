import { setChannelLocked } from "../../discord.js";
import { PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "lock",
  description: "Prevent @everyone from sending messages in this channel",
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Use this command in a server channel.")); return; }
    if (!ctx.hasPermission(PERM.MANAGE_CHANNELS)) { await ctx.reply(privateError("You need Manage Channels permission.")); return; }
    try {
      await setChannelLocked(ctx.bot, ctx.guildId, ctx.channelId, true);
      await ctx.reply({ embeds: [{ title: "🔒 Channel locked", description: `@everyone can no longer send messages in <#${ctx.channelId}>.`, color: 0xf5b942 }] });
    } catch {
      await ctx.reply(privateError("I couldn't lock this channel. Check my Manage Channels permission."));
    }
  },
};
export default command;
