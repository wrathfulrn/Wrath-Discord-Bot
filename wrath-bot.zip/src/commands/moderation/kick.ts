import { kick } from "../../discord.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "kick",
  description: "Kick a member from the server",
  options: [
    { name: "user", description: "Member to kick", type: OptionType.USER, required: true },
    { name: "reason", description: "Reason", type: OptionType.STRING },
  ],

  async execute(ctx) {
    if (!ctx.hasPermission(PERM.KICK_MEMBERS)) {
      await ctx.reply(privateError("You need the Kick Members permission for that."));
      return;
    }
    const target = ctx.user("user");
    if (!ctx.guildId || !target) {
      await ctx.reply(privateError("This command only works in a server."));
      return;
    }
    const reason = ctx.str("reason") ?? "No reason given";

    try {
      await kick(ctx.bot, ctx.guildId, target.id, `${ctx.username}: ${reason}`);
    } catch {
      await ctx.reply(privateError("I couldn't kick that member. Check my role and permissions."));
      return;
    }
    await ctx.reply(`👢 Kicked <@${target.id}>. Reason: ${reason}`);
  },
};

export default command;
