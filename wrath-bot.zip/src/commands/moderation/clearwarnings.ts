import { clearWarnings } from "../../db/index.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
const command: Command = {
  name: "clearwarnings", description: "Clear the stored warnings for a member",
  options: [{ name: "user", description: "Member whose warnings should be cleared", type: OptionType.USER, required: true }],
  async execute(ctx) {
    if (!ctx.hasPermission(PERM.MODERATE_MEMBERS)) { await ctx.reply(privateError("You need the Timeout Members permission.")); return; }
    if (!ctx.guildId) { await ctx.reply(privateError("Use this command in a server.")); return; }
    const target = ctx.user("user");
    if (!target) { await ctx.reply(privateError("Choose a member.")); return; }
    const count = await clearWarnings(ctx.guildId, target.id);
    await ctx.reply(`🧹 Cleared **${count}** warning(s) for <@${target.id}>.`);
  },
};
export default command;
