import type { Group } from "../../types.js";
import kick from "./kick.js";
import ban from "./ban.js";
import warn from "./warn.js";
import warnings from "./warnings.js";
import purge from "./purge.js";
import timeout from "./timeout.js";
import untimeout from "./untimeout.js";
import clearwarnings from "./clearwarnings.js";
import slowmode from "./slowmode.js";
import lock from "./lock.js";
import unlock from "./unlock.js";
import unban from "./unban.js";

const group: Group = {
  name: "moderation",
  description: "Server moderation (needs the matching permission)",
  guildOnly: true,
  subcommands: [kick, ban, unban, warn, warnings, purge, timeout, untimeout, clearwarnings, slowmode, lock, unlock],
};

export default group;
