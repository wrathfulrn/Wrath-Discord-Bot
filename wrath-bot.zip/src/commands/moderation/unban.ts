import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "unban",
  description: "Remove a user's ban by their Discord user ID",
  options: [
    { name: "user_id", description: "The banned user's numeric Discord ID", type: OptionType.STRING, required: true },
    { name: "reason", description: "Reason for unbanning", type: OptionType.STRING },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Use this command in a server.")); return; }
    if (!ctx.hasPermission(PERM.BAN_MEMBERS)) { await ctx.reply(privateError("You need Ban Members permission.")); return; }
    const userId = ctx.str("user_id")?.trim();
    if (!userId || !/^\d{17,20}$/.test(userId)) { await ctx.reply(privateError("Enter a valid Discord user ID.")); return; }
    const reason = (ctx.str("reason") ?? `Unbanned by ${ctx.username}`).slice(0, 400);
    try {
      const helpers = ctx.bot.helpers as unknown as { unbanMember: (guildId: string, userId: string, reason?: string) => Promise<unknown> };
      await helpers.unbanMember(ctx.guildId, userId, reason);
      await ctx.reply({ embeds: [{ title: "✅ User unbanned", description: `Removed the ban for <@${userId}>.
**Reason:** ${reason}`, color: 0x8b7cff }] });
    } catch {
      await ctx.reply(privateError("I couldn't unban that user. Confirm they are banned and that I have Ban Members permission."));
    }
  },
};
export default command;
