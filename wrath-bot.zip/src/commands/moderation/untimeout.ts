import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
const command: Command = {
  name: "untimeout", description: "Remove a member's timeout",
  options: [{ name: "user", description: "Member to untimeout", type: OptionType.USER, required: true }],
  async execute(ctx) {
    if (!ctx.hasPermission(PERM.MODERATE_MEMBERS)) { await ctx.reply(privateError("You need the Timeout Members permission.")); return; }
    if (!ctx.guildId) { await ctx.reply(privateError("Use this command in a server.")); return; }
    const target = ctx.user("user");
    if (!target) { await ctx.reply(privateError("Choose a member.")); return; }
    try {
      await ctx.bot.helpers.editMember(ctx.guildId, target.id, { communicationDisabledUntil: null } as never);
      await ctx.reply(`✅ Removed the timeout for <@${target.id}>.`);
    } catch {
      await ctx.reply(privateError("I couldn't remove that timeout. Check my Moderate Members permission and role position."));
    }
  },
};
export default command;
