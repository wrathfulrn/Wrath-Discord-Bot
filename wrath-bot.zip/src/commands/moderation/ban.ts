import { ban } from "../../discord.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "ban",
  description: "Ban a member from the server",
  options: [
    { name: "user", description: "Member to ban", type: OptionType.USER, required: true },
    { name: "reason", description: "Reason", type: OptionType.STRING },
  ],

  async execute(ctx) {
    if (!ctx.hasPermission(PERM.BAN_MEMBERS)) {
      await ctx.reply(privateError("You need the Ban Members permission for that."));
      return;
    }
    const target = ctx.user("user");
    if (!ctx.guildId || !target) {
      await ctx.reply(privateError("This command only works in a server."));
      return;
    }
    const reason = ctx.str("reason") ?? "No reason given";

    try {
      await ban(ctx.bot, ctx.guildId, target.id, `${ctx.username}: ${reason}`);
    } catch {
      await ctx.reply(privateError("I couldn't ban that member. Check my role and permissions."));
      return;
    }
    await ctx.reply(`🔨 Banned <@${target.id}>. Reason: ${reason}`);
  },
};

export default command;
