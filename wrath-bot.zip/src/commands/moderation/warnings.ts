import { getWarnings } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "warnings",
  description: "List a member's warnings",
  options: [{ name: "user", description: "Member to check", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    if (!ctx.guildId) {
      await ctx.reply(privateError("This command only works in a server."));
      return;
    }

    const reasons = await getWarnings(ctx.guildId, target.id);
    if (reasons.length === 0) {
      await ctx.reply(privateError(`${target.username} has no warnings.`));
      return;
    }

    const list = reasons.map((r, i) => `${i + 1}. ${r}`).join("\n").slice(0, 1800);
    await ctx.reply(`⚠️ Warnings for <@${target.id}>:\n${list}`);
  },
};

export default command;
