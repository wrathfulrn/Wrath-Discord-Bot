import { addWarning } from "../../db/index.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "warn",
  description: "Record a warning for a member",
  options: [
    { name: "user", description: "Member to warn", type: OptionType.USER, required: true },
    { name: "reason", description: "Reason", type: OptionType.STRING, required: true },
  ],

  async execute(ctx) {
    if (!ctx.hasPermission(PERM.MODERATE_MEMBERS)) {
      await ctx.reply(privateError("You need the Timeout Members permission for that."));
      return;
    }
    const target = ctx.user("user");
    const reason = ctx.str("reason") ?? "";
    if (!ctx.guildId || !target) {
      await ctx.reply(privateError("This command only works in a server."));
      return;
    }

    const count = await addWarning(ctx.guildId, target.id, reason);
    await ctx.reply(`⚠️ Warned <@${target.id}> (${count} total). Reason: ${reason}`);
  },
};

export default command;
