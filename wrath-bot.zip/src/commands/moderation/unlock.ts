import { setChannelLocked } from "../../discord.js";
import { PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "unlock",
  description: "Allow @everyone to send messages in this channel again",
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Use this command in a server channel.")); return; }
    if (!ctx.hasPermission(PERM.MANAGE_CHANNELS)) { await ctx.reply(privateError("You need Manage Channels permission.")); return; }
    try {
      await setChannelLocked(ctx.bot, ctx.guildId, ctx.channelId, false);
      await ctx.reply({ embeds: [{ title: "🔓 Channel unlocked", description: `The explicit send-message lock was removed from <#${ctx.channelId}>.`, color: 0x8b7cff }] });
    } catch {
      await ctx.reply(privateError("I couldn't unlock this channel. Check my Manage Channels permission."));
    }
  },
};
export default command;
