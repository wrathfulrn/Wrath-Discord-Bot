import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
const command: Command = {
  name: "slowmode", description: "Set channel slowmode in seconds (0 to disable)",
  options: [{ name: "seconds", description: "0 to 21600 seconds", type: OptionType.INTEGER, required: true, min_value: 0, max_value: 21600 }],
  async execute(ctx) {
    if (!ctx.hasPermission(PERM.MANAGE_CHANNELS)) { await ctx.reply(privateError("You need the Manage Channels permission.")); return; }
    if (!ctx.channelId) { await ctx.reply(privateError("Use this in a server channel.")); return; }
    const seconds = ctx.int("seconds") ?? 0;
    try {
      await ctx.bot.helpers.editChannel(ctx.channelId, { rateLimitPerUser: seconds } as never);
      await ctx.reply(seconds === 0 ? "🟢 Slowmode disabled for this channel." : `🐢 Slowmode set to **${seconds} seconds**.`);
    } catch {
      await ctx.reply(privateError("I couldn't change slowmode. Check my Manage Channels permission."));
    }
  },
};
export default command;
