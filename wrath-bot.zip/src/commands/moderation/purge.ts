import { purge } from "../../discord.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "purge",
  description: "Delete recent messages in this channel (1–100)",
  options: [{
    name: "amount",
    description: "How many messages (1 to 100)",
    type: OptionType.INTEGER,
    required: true,
    min_value: 1,
    max_value: 100,
  }],

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Purge only works in a server channel."));
      return;
    }
    if (!ctx.hasPermission(PERM.MANAGE_MESSAGES)) {
      await ctx.reply(
        privateError(
          "You need **Manage Messages** (or Administrator) in this server. " +
            "If you just got the role, try again in a few seconds.",
        ),
      );
      return;
    }
    if (!ctx.channelId) {
      await ctx.reply(privateError("I can only purge inside a channel."));
      return;
    }

    const amount = Math.max(1, Math.min(100, ctx.int("amount") ?? 1));
    try {
      const deleted = await purge(ctx.bot, ctx.channelId, amount);
      if (deleted === 0) {
        await ctx.reply(
          privateError(
            "No messages were deleted. I need **Manage Messages** on my role, " +
              "and the channel must allow me to view/read message history.",
          ),
        );
        return;
      }
      await ctx.reply(`🧹 Deleted **${deleted}** message(s).`);
    } catch (error) {
      console.error("purge failed:", error);
      await ctx.reply(
        privateError(
          "I couldn't delete messages. Give the bot **Manage Messages** " +
            "(and put its role above others if you use role hierarchy), " +
            "and make sure the channel isn't blocking me.",
        ),
      );
    }
  },
};

export default command;
