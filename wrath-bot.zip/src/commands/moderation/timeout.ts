import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

function durationMs(raw: string): number | null {
  const match = raw.trim().match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return null;
  const amount = Number(match[1]);
  const unit = match[2].toLowerCase();
  const ms = amount * ({ s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }[unit] ?? 0);
  return ms > 0 && ms <= 28 * 86_400_000 ? ms : null;
}

const command: Command = {
  name: "timeout",
  description: "Temporarily prevent a member from chatting (e.g. 10m, 2h, 1d)",
  options: [
    { name: "user", description: "Member to timeout", type: OptionType.USER, required: true },
    { name: "duration", description: "Duration: 10m, 2h, or 1d (maximum 28d)", type: OptionType.STRING, required: true },
    { name: "reason", description: "Reason for the timeout", type: OptionType.STRING },
  ],
  async execute(ctx) {
    if (!ctx.hasPermission(PERM.MODERATE_MEMBERS)) {
      await ctx.reply(privateError("You need the Timeout Members permission.")); return;
    }
    if (!ctx.guildId) { await ctx.reply(privateError("Use this command in a server.")); return; }
    const target = ctx.user("user");
    if (!target) { await ctx.reply(privateError("Choose a member to timeout.")); return; }
    if (target.id === ctx.userId) { await ctx.reply(privateError("You cannot timeout yourself.")); return; }
    const duration = durationMs(ctx.str("duration") ?? "");
    if (!duration) { await ctx.reply(privateError("Invalid duration. Use 30s, 10m, 2h, or 1d (maximum 28 days).")); return; }
    const reason = (ctx.str("reason") ?? "No reason provided").slice(0, 400);
    try {
      await ctx.bot.helpers.editMember(ctx.guildId, target.id, {
        communicationDisabledUntil: new Date(Date.now() + duration),
      } as never);
      await ctx.reply(`⏳ Timed out <@${target.id}> for **${ctx.str("duration")}**. Reason: ${reason}`);
    } catch {
      await ctx.reply(privateError("I couldn't timeout that member. Check my Moderate Members permission and role position."));
    }
  },
};
export default command;
