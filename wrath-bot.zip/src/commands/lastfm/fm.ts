import { OptionType, type Command } from "../../types.js";
import { kv } from "../../db/index.js";
import { privateError } from "../../utils/format.js";
import type { KvKey } from "../../db/store.js";

const command: Command = {
  name: "fm",
  description: "Last.fm now playing (set username first)",
  options: [
    { name: "user", description: "Last.fm username to save or look up", type: OptionType.STRING },
  ],
  async execute(ctx) {
    const key: KvKey = ["lastfm", ctx.userId];
    const given = (ctx.str("user") ?? "").trim();
    if (given && !given.includes(" ")) {
      await kv.atomic().set(key, given).commit();
      await ctx.reply(`Last.fm username set to **${given}**. Use \`,fm\` to fetch recent tracks.`);
      return;
    }
    const saved = (await kv.get<string>(key)).value;
    const name = given || saved;
    if (!name) {
      await ctx.reply(privateError("Set your Last.fm name: `,fm yourname`"));
      return;
    }
    const apiKey = process.env.LASTFM_API_KEY;
    if (!apiKey) {
      await ctx.reply(
        `Saved Last.fm user: **${name}**.\n` +
        `_Set LASTFM_API_KEY in .env to fetch live now-playing from the Last.fm API._`,
      );
      return;
    }
    try {
      const url =
        `https://ws.audioscrobbler.com/2.0/?method=user.getrecenttracks&user=${encodeURIComponent(name)}` +
        `&api_key=${encodeURIComponent(apiKey)}&format=json&limit=1`;
      const res = await fetch(url);
      const data = (await res.json()) as {
        recenttracks?: { track?: Array<{ name?: string; artist?: { "#text"?: string }; "@attr"?: { nowplaying?: string } }> };
      };
      const track = data.recenttracks?.track?.[0];
      if (!track) {
        await ctx.reply(`No recent tracks for **${name}**.`);
        return;
      }
      const np = track["@attr"]?.nowplaying === "true";
      await ctx.reply(
        `${np ? "🎧 Now playing" : "🎵 Last played"} for **${name}**:\n**${track.name}** — ${track.artist?.["#text"] ?? "Unknown"}`,
      );
    } catch (e) {
      await ctx.reply(privateError(`Last.fm error: ${e instanceof Error ? e.message : "failed"}`));
    }
  },
};
export default command;
