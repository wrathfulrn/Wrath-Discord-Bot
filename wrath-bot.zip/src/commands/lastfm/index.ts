import type { Group } from "../../types.js";
import fm from "./fm.js";
const group: Group = { name: "lastfm", description: "Last.fm integration", subcommands: [fm] };
export default group;
