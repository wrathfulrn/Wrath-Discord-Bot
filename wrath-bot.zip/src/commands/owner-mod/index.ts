import type { Group } from "../../types.js";
import { ownerBan, ownerKick, ownerWarn, ownerClearWarnings, ownerNickname, ownerTimeout, ownerUntimeout, ownerUnban } from "../owner/admin.js";

const group: Group = {
  name: "owner-mod",
  description: "Owner-only moderation controls",
  subcommands: [ownerBan, ownerKick, ownerWarn, ownerClearWarnings, ownerNickname, ownerTimeout, ownerUntimeout, ownerUnban],
};
export default group;
