import { buyTickets, LOTTERY_TICKET_PRICE } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "ticket",
  description: "Buy lottery tickets",
  options: [{
    name: "count",
    description: "How many tickets (1 to 10)",
    type: OptionType.INTEGER,
    min_value: 1,
    max_value: 10,
  }],

  async execute(ctx) {
    const count = ctx.int("count") ?? 1;
    const cost = count * LOTTERY_TICKET_PRICE;

    if (!(await buyTickets(ctx.userId, count))) {
      await ctx.reply(privateError(`${count} ticket(s) cost ${coins(cost)}.`));
      return;
    }
    await ctx.reply(`🎟️ Bought ${count} ticket(s) for ${coins(cost)}.`);
  },
};

export default command;
