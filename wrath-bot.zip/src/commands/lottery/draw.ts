import { drawLottery } from "../../db/features.js";
import type { Command } from "../../types.js";
import { coins, fmtDuration, privateError } from "../../utils/format.js";

const command: Command = {
  name: "draw",
  description: "Draw a winner once the interval has passed",

  async execute(ctx) {
    const result = await drawLottery();

    if (result.status === "cooldown") {
      await ctx.reply(privateError(`The next draw is in ${fmtDuration(result.waitMs)}.`));
      return;
    }
    if (result.status === "empty") {
      await ctx.reply(privateError("No tickets have been bought yet."));
      return;
    }
    await ctx.reply(`🎉 <@${result.winner}> won the lottery and takes home ${coins(result.prize)}!`);
  },
};

export default command;
