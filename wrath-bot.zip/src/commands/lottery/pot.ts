import { DRAW_INTERVAL_MS, getLottery } from "../../db/features.js";
import type { Command } from "../../types.js";
import { coins, fmtDuration } from "../../utils/format.js";

const command: Command = {
  name: "pot",
  description: "Show the current lottery pot",

  async execute(ctx) {
    const state = await getLottery();
    const wait = state.lastDraw + DRAW_INTERVAL_MS - Date.now();
    const next = wait > 0 ? `in ${fmtDuration(wait)}` : "now";

    await ctx.reply({
      embeds: [{
        title: "🎰 Lottery",
        color: 0xf1c40f,
        fields: [
          { name: "Pot", value: coins(state.pot), inline: true },
          { name: "Tickets", value: String(state.tickets.length), inline: true },
          { name: "Next draw", value: next, inline: true },
        ],
      }],
    });
  },
};

export default command;
