import type { Group } from "../../types.js";
import buy from "./buy.js";
import pot from "./pot.js";
import draw from "./draw.js";

const group: Group = {
  name: "lottery",
  description: "Buy tickets and draw a winner",
  subcommands: [buy, pot, draw],
};

export default group;
