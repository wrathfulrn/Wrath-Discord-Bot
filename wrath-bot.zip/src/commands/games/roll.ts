import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "roll",
  description: "Roll dice, e.g. 2d20",
  options: [{ name: "dice", description: "NdM format, default 1d6", type: OptionType.STRING }],

  async execute(ctx) {
    const spec = (ctx.str("dice") ?? "1d6").toLowerCase().trim();
    const match = /^(\d*)d(\d+)$/.exec(spec);

    if (!match) {
      await ctx.reply(privateError("Use NdM format, for example `2d20`."));
      return;
    }

    const count = Number(match[1] || 1);
    const sides = Number(match[2]);
    if (count < 1 || count > 20 || sides < 2 || sides > 1000) {
      await ctx.reply(privateError("Limits: 1 to 20 dice, 2 to 1000 sides."));
      return;
    }

    const rolls = Array.from({ length: count }, () => 1 + Math.floor(Math.random() * sides));
    const total = rolls.reduce((a, b) => a + b, 0);
    await ctx.reply(`🎲 ${spec}: [${rolls.join(", ")}] = **${total}**`);
  },
};

export default command;
