import { OptionType, type Command } from "../../types.js";

const ANSWERS = [
  "It is certain.", "Without a doubt.", "Yes, definitely.", "Most likely.",
  "Signs point to yes.", "Reply hazy, try again.", "Ask again later.",
  "Don't count on it.", "My sources say no.", "Very doubtful.",
];

const command: Command = {
  name: "8ball",
  description: "Ask the magic 8-ball",
  options: [{ name: "question", description: "Your question", type: OptionType.STRING, required: true }],

  async execute(ctx) {
    const question = ctx.str("question") ?? "";
    const answer = ANSWERS[Math.floor(Math.random() * ANSWERS.length)];
    await ctx.reply(`🎱 **${question}**\n${answer}`);
  },
};

export default command;
