import { OptionType, type Command } from "../../types.js";

type Move = "rock" | "paper" | "scissors";
const BEATS: Record<Move, Move> = { rock: "scissors", paper: "rock", scissors: "paper" };
const MOVES = Object.keys(BEATS) as Move[];

const command: Command = {
  name: "rps",
  description: "Play rock, paper, scissors against the bot",
  options: [{
    name: "move",
    description: "Your move",
    type: OptionType.STRING,
    required: true,
    choices: [
      { name: "Rock", value: "rock" },
      { name: "Paper", value: "paper" },
      { name: "Scissors", value: "scissors" },
    ],
  }],

  async execute(ctx) {
    const mine = (ctx.str("move") ?? "rock") as Move;
    const theirs = MOVES[Math.floor(Math.random() * MOVES.length)];

    let verdict: string;
    if (mine === theirs) verdict = "It's a tie!";
    else if (BEATS[mine] === theirs) verdict = "You win!";
    else verdict = "I win!";

    await ctx.reply(`✊✋✌️ You: **${mine}** | Me: **${theirs}**\n${verdict}`);
  },
};

export default command;
