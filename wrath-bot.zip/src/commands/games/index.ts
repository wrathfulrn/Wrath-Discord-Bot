import type { Group } from "../../types.js";
import eightBall from "./8ball.js";
import roll from "./roll.js";
import choose from "./choose.js";
import rps from "./rps.js";

const group: Group = {
  name: "games",
  description: "Quick games, dice, and decisions",
  subcommands: [eightBall, roll, choose, rps],
};

export default group;
