import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "choose",
  description: "Let the bot pick one of several options",
  options: [{
    name: "options",
    description: "Comma-separated, e.g. pizza, tacos, sushi",
    type: OptionType.STRING,
    required: true,
  }],

  async execute(ctx) {
    const options = (ctx.str("options") ?? "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    if (options.length < 2) {
      await ctx.reply(privateError("Give me at least two options, separated by commas."));
      return;
    }

    const pick = options[Math.floor(Math.random() * options.length)];
    await ctx.reply(`🤔 I choose **${pick}**.`);
  },
};

export default command;
