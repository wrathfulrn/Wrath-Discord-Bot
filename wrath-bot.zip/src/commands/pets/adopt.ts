import { SPECIES, SPECIES_CHOICES, findSpecies, listSpeciesLine } from "../../data/pets.js";
import { addBalance, trySpend } from "../../db/index.js";
import { addPet, getPets } from "../../db/features.js";
import { isPremium, maxPetsFor } from "../../db/premium.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "adopt",
  description: "Adopt a pet from the species catalog",
  options: [
    {
      name: "species",
      description: "Species id or name (see ,species)",
      type: OptionType.STRING,
      required: true,
      // Slash shows 25 popular picks; prefix accepts any catalog id/name.
      choices: SPECIES_CHOICES,
    },
    { name: "name", description: "Name for your pet (1 to 20 characters)", type: OptionType.STRING, required: true },
  ],

  async execute(ctx) {
    const rawSpecies = ctx.str("species");
    const species = findSpecies(rawSpecies);
    const name = (ctx.str("name") ?? "").trim();

    if (!species) {
      const hint = SPECIES.slice(0, 12).map((s) => `\`${s.id}\``).join(", ");
      await ctx.reply(
        privateError(
          `Unknown species \`${rawSpecies ?? ""}\`. Try one of: ${hint}…\nUse \`${(await import("../../config.js")).config.prefix}species\` for the full list.`,
        ),
      );
      return;
    }
    if (name.length < 1 || name.length > 20) {
      await ctx.reply(privateError("Pet names must be 1 to 20 characters."));
      return;
    }
    const premium = await isPremium(ctx.userId);
    const maxPets = maxPetsFor(premium);
    if ((await getPets(ctx.userId)).length >= maxPets) {
      await ctx.reply(privateError(
        premium
          ? `You can have at most ${maxPets} pets. Release one first.`
          : "Free plan allows " + maxPets + " pets. Upgrade with ,premium for more slots.",
      ));
      return;
    }
    if (!(await trySpend(ctx.userId, species.price))) {
      await ctx.reply(privateError(`A ${species.name} costs ${coins(species.price)}.`));
      return;
    }

    const now = Date.now();
    const added = await addPet(ctx.userId, {
      id: crypto.randomUUID(),
      name,
      species: species.id,
      adoptedAt: now,
      fedAt: now,
      playedAt: now,
    });

    if (!added) {
      await addBalance(ctx.userId, species.price);
      await ctx.reply(privateError(`You can have at most ${maxPets} pets.`));
      return;
    }

    const blurb = species.blurb ? `\n_${species.blurb}_` : "";
    await ctx.reply(`${species.emoji} You adopted **${name}** the ${species.name} for ${coins(species.price)}!${blurb}`);
  },
};

export default command;
