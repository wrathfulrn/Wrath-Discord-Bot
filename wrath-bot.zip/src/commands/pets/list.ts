import { findSpecies, petStats } from "../../data/pets.js";
import { getPets } from "../../db/features.js";
import type { Command } from "../../types.js";

const command: Command = {
  name: "pets",
  description: "Show your pets and how they're doing",

  async execute(ctx) {
    const pets = await getPets(ctx.userId);
    if (pets.length === 0) {
      await ctx.reply("You have no pets yet. Use `,adopt`.");
      return;
    }

    const fields = pets.map((p) => {
      const species = findSpecies(p.species);
      const s = petStats(p);
      return {
        name: `${species?.emoji ?? "🐾"} ${p.name}`,
        value: `${species?.name ?? p.species}\nHunger: ${s.hunger}%\nHappiness: ${s.happiness}%`,
        inline: true,
      };
    });

    await ctx.reply({ embeds: [{ title: "🐾 Your pets", color: 0xe67e22, fields }] });
  },
};

export default command;
