import { findPet, getPets, removePet } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "release",
  description: "Release one of your pets (no refund)",
  options: [{ name: "pet", description: "Pet name", type: OptionType.STRING, required: true }],

  async execute(ctx) {
    const pet = findPet(await getPets(ctx.userId), ctx.str("pet") ?? "");
    if (!pet) {
      await ctx.reply(privateError("You don't have a pet with that name."));
      return;
    }

    await removePet(ctx.userId, pet.id);
    await ctx.reply(`🕊️ You released **${pet.name}** back into the wild.`);
  },
};

export default command;
