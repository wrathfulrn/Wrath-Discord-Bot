import type { Group } from "../../types.js";
import adopt from "./adopt.js";
import list from "./list.js";
import feed from "./feed.js";
import play from "./play.js";
import release from "./release.js";
import species from "./species.js";

const group: Group = {
  name: "pets",
  description: "Adopt, feed, and play with pets",
  subcommands: [adopt, list, feed, play, release, species],
};

export default group;
