import { FEED_COST } from "../../data/pets.js";
import { trySpend } from "../../db/index.js";
import { findPet, getPets, updatePet } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "feed",
  description: "Feed one of your pets",
  options: [{ name: "pet", description: "Pet name", type: OptionType.STRING, required: true }],

  async execute(ctx) {
    const pet = findPet(await getPets(ctx.userId), ctx.str("pet") ?? "");
    if (!pet) {
      await ctx.reply(privateError("You don't have a pet with that name."));
      return;
    }
    if (!(await trySpend(ctx.userId, FEED_COST))) {
      await ctx.reply(privateError(`Feeding costs ${coins(FEED_COST)}.`));
      return;
    }

    await updatePet(ctx.userId, pet.id, (p) => {
      p.fedAt = Date.now();
    });
    await ctx.reply(`🍖 You fed **${pet.name}** for ${coins(FEED_COST)}.`);
  },
};

export default command;
