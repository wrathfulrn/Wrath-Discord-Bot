import { findPet, getPets, updatePet } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "play",
  description: "Play with one of your pets",
  options: [{ name: "pet", description: "Pet name", type: OptionType.STRING, required: true }],

  async execute(ctx) {
    const pet = findPet(await getPets(ctx.userId), ctx.str("pet") ?? "");
    if (!pet) {
      await ctx.reply(privateError("You don't have a pet with that name."));
      return;
    }

    await updatePet(ctx.userId, pet.id, (p) => {
      p.playedAt = Date.now();
    });
    await ctx.reply(`🎾 You played with **${pet.name}**. They're happy again!`);
  },
};

export default command;
