import { SPECIES, findSpecies } from "../../data/pets.js";
import { OptionType, type Command } from "../../types.js";
import { coins } from "../../utils/format.js";

const command: Command = {
  name: "species",
  description: "Browse the world pet catalog (or look up one species)",
  options: [
    {
      name: "query",
      description: "Optional: species id or name to look up",
      type: OptionType.STRING,
      required: false,
    },
  ],

  async execute(ctx) {
    const query = (ctx.str("query") ?? "").trim();

    if (query) {
      const hit = findSpecies(query);
      if (!hit) {
        const suggestions = SPECIES.filter(
          (s) =>
            s.id.includes(query.toLowerCase()) ||
            s.name.toLowerCase().includes(query.toLowerCase()),
        ).slice(0, 15);
        if (suggestions.length === 0) {
          await ctx.reply(`No species matched \`${query}\`. Try \`,species\` for the full catalog.`);
          return;
        }
        const list = suggestions
          .map((s) => `${s.emoji} **${s.name}** (\`${s.id}\`) — ${coins(s.price)}`)
          .join("\n");
        await ctx.reply({
          embeds: [
            {
              title: `🔍 Species matching "${query}"`,
              description: list,
              color: 0xe67e22,
              footer: { text: `Adopt with ,adopt <id> <name> · ${SPECIES.length} species total` },
            },
          ],
        });
        return;
      }

      await ctx.reply({
        embeds: [
          {
            title: `${hit.emoji} ${hit.name}`,
            description: [
              `**Id:** \`${hit.id}\``,
              `**Price:** ${coins(hit.price)}`,
              hit.blurb ? `**About:** ${hit.blurb}` : "",
              "",
              `Adopt: \`,adopt ${hit.id} YourPetName\``,
            ]
              .filter(Boolean)
              .join("\n"),
            color: 0xe67e22,
          },
        ],
      });
      return;
    }

    // Full catalog — group into embed pages of ~40 lines
    const lines = SPECIES.map(
      (s) => `${s.emoji} \`${s.id}\` **${s.name}** — ${coins(s.price)}`,
    );
    const perPage = 35;
    const embeds: Record<string, unknown>[] = [];
    for (let i = 0; i < lines.length; i += perPage) {
      const slice = lines.slice(i, i + perPage);
      const page = Math.floor(i / perPage) + 1;
      const pages = Math.ceil(lines.length / perPage);
      embeds.push({
        title:
          i === 0
            ? `🐾 World pet catalog (${SPECIES.length} species)`
            : `🐾 Catalog (${page}/${pages})`,
        description: slice.join("\n"),
        color: 0xe67e22,
        footer:
          i + perPage >= lines.length
            ? { text: "Adopt: ,adopt <species> <name> · Search: ,species fox" }
            : { text: `Page ${page}/${pages}` },
      });
    }

    // Discord allows up to 10 embeds per message
    await ctx.reply({ embeds: embeds.slice(0, 10) });
    if (embeds.length > 10) {
      await ctx.reply({
        content: `…and more. Use \`,species <name>\` to search (e.g. \`,species dragon\`). **${SPECIES.length}** species total.`,
      });
    }
  },
};

export default command;
