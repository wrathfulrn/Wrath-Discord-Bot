import { OptionType, type Command, type Group } from "../../types.js";

/**
 * Each entry becomes a subcommand, e.g. `,hug`.
 * {a} is the sender, {b} is the target.
 */
const SOCIAL: Record<string, string> = {
  hug: "{a} hugs {b} 🤗",
  slap: "{a} slaps {b} 👋",
  pat: "{a} pats {b} on the head 🫳",
  kiss: "{a} kisses {b} 💋",
  wave: "{a} waves at {b} 👋",
  bonk: "{a} bonks {b} 🔨",
  highfive: "{a} high-fives {b} ✋",
  cuddle: "{a} cuddles {b} 🧸",
  poke: "{a} pokes {b} 👉",
  boop: "{a} boops {b}'s nose 👃",
  wink: "{a} winks at {b} 😉",
};

const subcommands: Command[] = Object.entries(SOCIAL).map(([name, template]) => ({
  name,
  description: `${name} someone`,
  options: [{ name: "user", description: "Who to target", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    const line = template
      .replace("{a}", `<@${ctx.userId}>`)
      .replace("{b}", `<@${target.id}>`);
    await ctx.reply(line);
  },
}));

const group: Group = {
  name: "social",
  description: "Hugs, slaps, and other actions",
  subcommands,
};

export default group;
