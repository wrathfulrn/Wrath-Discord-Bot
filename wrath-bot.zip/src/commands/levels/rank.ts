import { OptionType, type Command } from "../../types.js";
import { getUserLevel } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "rank",
  description: "Show your level in this server",
  options: [{ name: "user", description: "Member", type: OptionType.USER }],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    const u = ctx.userOrSelf("user");
    const lvl = await getUserLevel(ctx.guildId, u.id);
    const need = (lvl.level + 1) * 100;
    await ctx.reply({
      embeds: [{
        title: `${u.username}'s rank`,
        description: `**Level ${lvl.level}** · ${lvl.xp}/${need} XP to next`,
        color: 0xf1c40f,
      }],
    });
  },
};
export default command;
