import type { Group } from "../../types.js";
import rank from "./rank.js";
import levelconfig from "./levelconfig.js";

const group: Group = {
  name: "levels",
  description: "XP and levels",
  guildOnly: true,
  subcommands: [rank, levelconfig],
};
export default group;
