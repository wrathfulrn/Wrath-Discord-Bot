import { OptionType, type Command } from "../../types.js";
import { extraConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "reactionrole",
  description: "Bind an emoji on a message to a role id",
  options: [
    { name: "message", description: "Message id", type: OptionType.STRING, required: true },
    { name: "emoji", description: "Emoji (unicode or custom name)", type: OptionType.STRING, required: true },
    { name: "role", description: "Role id", type: OptionType.STRING, required: true },
  ],
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 28n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Roles.")); return;
    }
    const messageId = (ctx.str("message") ?? "").trim();
    const emoji = (ctx.str("emoji") ?? "").trim();
    const roleId = (ctx.str("role") ?? "").trim();
    const list = await extraConfig.getReactionRoles(ctx.guildId);
    if (list.length >= 50) { await ctx.reply(privateError("Max 50 reaction roles.")); return; }
    list.push({ messageId, channelId: ctx.channelId, emoji, roleId });
    await extraConfig.setReactionRoles(ctx.guildId, list);
    try {
      await ctx.bot.helpers.addReaction(ctx.channelId, messageId, emoji);
    } catch { /* user can react manually */ }
    await ctx.reply(`Reaction role set: ${emoji} → <@&${roleId}> on message \`${messageId}\`.`);
  },
};
export default command;
