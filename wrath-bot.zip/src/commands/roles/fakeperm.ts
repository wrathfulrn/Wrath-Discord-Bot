import { OptionType, type Command } from "../../types.js";
import { extraConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "fakeperm",
  description: "Allow a role to use a mod command without Discord perms",
  options: [
    { name: "role", description: "Role id", type: OptionType.STRING, required: true },
    { name: "command", description: "Command name e.g. ban, kick, purge", type: OptionType.STRING, required: true },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 3n)) { await ctx.reply(privateError("Need Administrator.")); return; }
    const roleId = (ctx.str("role") ?? "").trim();
    const cmd = (ctx.str("command") ?? "").trim().toLowerCase();
    const list = await extraConfig.getFakePerms(ctx.guildId);
    let row = list.find((r) => r.roleId === roleId);
    if (!row) { row = { roleId, commands: [] }; list.push(row); }
    if (!row.commands.includes(cmd)) row.commands.push(cmd);
    await extraConfig.setFakePerms(ctx.guildId, list);
    await ctx.reply(`Role <@&${roleId}> may use \`,${cmd}\` via fake permissions.`);
  },
};
export default command;
