import { OptionType, type Command } from "../../types.js";
import { extraConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "boosterrole",
  description: "Set the role given context for boosters (config)",
  options: [
    { name: "role", description: "Role id", type: OptionType.STRING, required: true },
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 28n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Roles.")); return;
    }
    const cfg = await extraConfig.getBooster(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    cfg.roleId = (ctx.str("role") ?? "").trim();
    await extraConfig.setBooster(ctx.guildId, cfg);
    await ctx.reply(`Booster role **${cfg.enabled ? "on" : "off"}** → <@&${cfg.roleId}>.`);
  },
};
export default command;
