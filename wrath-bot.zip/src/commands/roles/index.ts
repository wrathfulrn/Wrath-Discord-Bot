import type { Group } from "../../types.js";
import reactionrole from "./reactionrole.js";
import fakeperm from "./fakeperm.js";
import booster from "./booster.js";
const group: Group = {
  name: "roles",
  description: "Reaction roles, fake permissions, booster role",
  guildOnly: true,
  subcommands: [reactionrole, fakeperm, booster],
};
export default group;
