import type { Group } from "../../types.js";
import {
  reverse,
  choose,
  coin,
  dice,
  textcount,
  lowercase,
  uppercase,
  titlecase,
  binary,
  unbinary,
  hex,
  unhex,
  snowflake,
  servericon,
  botinfo,
  usercount,
} from "../utility/extras.js";

/** Text/transform tools split out so utility stays ≤25 subcommands. */
const group: Group = {
  name: "tools",
  description: "Text, dice, and conversion tools",
  subcommands: [
    reverse,
    choose,
    coin,
    dice,
    textcount,
    lowercase,
    uppercase,
    titlecase,
    binary,
    unbinary,
    hex,
    unhex,
    snowflake,
    servericon,
    botinfo,
    usercount,
  ],
};

export default group;
