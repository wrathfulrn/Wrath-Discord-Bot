import type { Group } from "../../types.js";
import script from "./script.js";
const group: Group = { name: "scripts", description: "Named embed scripts", guildOnly: true, subcommands: [script] };
export default group;
