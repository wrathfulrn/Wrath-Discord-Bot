import { OptionType, type Command } from "../../types.js";
import { extraConfig } from "../../db/guildConfig.js";
import { parseScript } from "../../utils/script.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "script",
  description: "Save or run a named embed script",
  options: [
    { name: "action", description: "add, show, or list", type: OptionType.STRING, required: true, choices: [
      { name: "add", value: "add" }, { name: "show", value: "show" }, { name: "list", value: "list" },
    ]},
    { name: "name", description: "Script name", type: OptionType.STRING },
    { name: "body", description: "Script body for add", type: OptionType.STRING },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    const action = ctx.str("action");
    const scripts = await extraConfig.getScripts(ctx.guildId);
    if (action === "list") {
      const names = Object.keys(scripts);
      await ctx.reply(names.length ? names.map((n) => `\`${n}\``).join(", ") : "No scripts yet.");
      return;
    }
    const name = (ctx.str("name") ?? "").trim().toLowerCase();
    if (!name) { await ctx.reply(privateError("Need a name.")); return; }
    if (action === "add") {
      if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
        await ctx.reply(privateError("Need Manage Server.")); return;
      }
      const body = (ctx.str("body") ?? "").trim();
      if (!body) { await ctx.reply(privateError("Need body. Example: {title: Hi} {description: Hello {user.name}}")); return; }
      if (Object.keys(scripts).length >= 25 && !scripts[name]) {
        await ctx.reply(privateError("Max 25 scripts.")); return;
      }
      scripts[name] = body;
      await extraConfig.setScripts(ctx.guildId, scripts);
      await ctx.reply(`Saved script \`${name}\`. Run with \`,script show ${name}\`.`);
      return;
    }
    const body = scripts[name];
    if (!body) { await ctx.reply(privateError("Unknown script.")); return; }
    const parsed = parseScript(body, {
      user: { id: ctx.userId, username: ctx.username, mention: `<@${ctx.userId}>` },
      guild: { id: ctx.guildId, name: "server", count: 0 },
      channel: { id: ctx.channelId },
    });
    await ctx.reply({ content: parsed.content, embeds: parsed.embeds });
  },
};
export default command;
