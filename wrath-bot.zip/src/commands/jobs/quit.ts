import { setJob, getJobRecord } from "../../db/features.js";
import { findJob } from "../../data/jobs.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "quit",
  description: "Quit your current job",

  async execute(ctx) {
    const job = findJob((await getJobRecord(ctx.userId)).jobId);
    if (!job) {
      await ctx.reply(privateError("You don't have a job to quit."));
      return;
    }
    await setJob(ctx.userId, null);
    await ctx.reply(`👋 You quit your job as a **${job.name}**.`);
  },
};

export default command;
