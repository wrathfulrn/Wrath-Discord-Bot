import { JOBS } from "../../data/jobs.js";
import type { Command } from "../../types.js";
import { fmtDuration } from "../../utils/format.js";

const command: Command = {
  name: "jobs",
  description: "Show available jobs",

  async execute(ctx) {
    const lines = JOBS.map((j) => {
      const need = j.requiredXp > 0 ? `, needs ${j.requiredXp} XP` : "";
      return `${j.emoji} **${j.name}**: ${j.minPay}–${j.maxPay} coins per shift, ${fmtDuration(j.cooldownMs)} cooldown${need}`;
    });

    await ctx.reply({
      embeds: [{ title: "💼 Jobs", color: 0x95a5a6, description: lines.join("\n") }],
    });
  },
};

export default command;
