import type { Group } from "../../types.js";
import list from "./list.js";
import apply from "./apply.js";
import shift from "./shift.js";
import quit from "./quit.js";

const group: Group = {
  name: "jobs",
  description: "Take a job and work shifts",
  subcommands: [list, apply, shift, quit],
};

export default group;
