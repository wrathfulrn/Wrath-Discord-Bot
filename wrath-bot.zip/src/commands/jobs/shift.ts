import { config } from "../../config.js";
import { findJob } from "../../data/jobs.js";
import { addBalance } from "../../db/index.js";
import { claimShift, getJobRecord } from "../../db/features.js";
import type { Command } from "../../types.js";
import { coins, cooldownLeft, cooldownNotice, privateError } from "../../utils/format.js";

const command: Command = {
  name: "shift",
  description: "Work a shift at your job",

  async execute(ctx) {
    const record = await getJobRecord(ctx.userId);
    const job = findJob(record.jobId);
    if (!job) {
      await ctx.reply(privateError(`You don't have a job. Use \`${config.prefix}apply\`.`));
      return;
    }

    // Claim first so two quick shifts can't both pay out.
    if (!(await claimShift(ctx.userId, job.cooldownMs))) {
      const wait = cooldownLeft(record.lastShift, job.cooldownMs);
      await ctx.reply({ content: cooldownNotice(wait), ephemeral: true });
      return;
    }

    const pay = job.minPay + Math.floor(Math.random() * (job.maxPay - job.minPay + 1));
    await addBalance(ctx.userId, pay);
    await ctx.reply(`${job.emoji} Shift done as a **${job.name}**. You earned ${coins(pay)}.`);
  },
};

export default command;
