import { JOB_CHOICES, findJob } from "../../data/jobs.js";
import { getUser } from "../../db/index.js";
import { setJob } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "apply",
  description: "Take a job",
  options: [{
    name: "job",
    description: "Job to take",
    type: OptionType.STRING,
    required: true,
    choices: JOB_CHOICES,
  }],

  async execute(ctx) {
    const job = findJob(ctx.str("job"));
    if (!job) {
      await ctx.reply(privateError("That job doesn't exist."));
      return;
    }

    const u = await getUser(ctx.userId);
    if (u.xp < job.requiredXp) {
      await ctx.reply(privateError(`${job.name} needs ${job.requiredXp} XP. You have ${u.xp}.`));
      return;
    }

    await setJob(ctx.userId, job.id);
    await ctx.reply(`${job.emoji} You're now a **${job.name}**. Use \`,shift\` to work.`);
  },
};

export default command;
