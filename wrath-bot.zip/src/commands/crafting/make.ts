import { RECIPE_CHOICES, findRecipe } from "../../data/recipes.js";
import { findItem } from "../../data/shop.js";
import { craft } from "../../db/features.js";
import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "make",
  description: "Craft an item from a recipe",
  options: [{
    name: "recipe",
    description: "Recipe to craft",
    type: OptionType.STRING,
    required: true,
    choices: RECIPE_CHOICES,
  }],

  async execute(ctx) {
    const recipe = findRecipe(ctx.str("recipe"));
    if (!recipe) {
      await ctx.reply(privateError("That recipe doesn't exist."));
      return;
    }

    if (!(await craft(ctx.userId, recipe.ingredients, recipe.output))) {
      await ctx.reply(privateError("You don't have the ingredients. Check `,recipes`."));
      return;
    }

    const output = findItem(recipe.output);
    await ctx.reply(`${output?.emoji ?? "✨"} You crafted a **${output?.name ?? recipe.output}**!`);
  },
};

export default command;
