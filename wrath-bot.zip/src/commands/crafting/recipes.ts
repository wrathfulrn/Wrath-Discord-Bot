import { RECIPES } from "../../data/recipes.js";
import { findItem } from "../../data/shop.js";
import type { Command } from "../../types.js";

const command: Command = {
  name: "recipes",
  description: "Show what you can craft",

  async execute(ctx) {
    const lines = RECIPES.map((r) => {
      const needs = Object.entries(r.ingredients)
        .map(([id, n]) => `${n} × ${findItem(id)?.name ?? id}`)
        .join(", ");
      const output = findItem(r.output);
      return `${r.emoji} **${r.name}**: ${needs} → ${output?.emoji ?? ""} ${output?.name ?? r.output}`;
    });

    await ctx.reply({
      embeds: [{ title: "⚒️ Recipes", color: 0xe67e22, description: lines.join("\n") }],
    });
  },
};

export default command;
