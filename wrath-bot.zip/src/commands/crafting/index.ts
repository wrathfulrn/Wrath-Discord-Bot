import type { Group } from "../../types.js";
import recipes from "./recipes.js";
import make from "./make.js";

const group: Group = {
  name: "crafting",
  description: "Combine items into better ones",
  subcommands: [recipes, make],
};

export default group;
