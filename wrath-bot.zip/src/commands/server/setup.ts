import { getGreeting } from "../../db/features.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "setup",
  description: "Show this server's settings and how to change them",

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Use this in a server."));
      return;
    }

    const welcome = await getGreeting(ctx.guildId, "welcome");
    const goodbye = await getGreeting(ctx.guildId, "goodbye");
    const describe = (g: { channelId: string } | null) => (g ? `<#${g.channelId}>` : "Off");

    await ctx.reply({
      embeds: [{
        title: "Server setup",
        description: "Change these with `,welcome on|off|test` and `,goodbye on|off|test`, run in the channel you want to use.",
        fields: [
          { name: "Welcome messages", value: describe(welcome), inline: true },
          { name: "Goodbye messages", value: describe(goodbye), inline: true },
        ],
      }],
    });
  },
};

export default command;
