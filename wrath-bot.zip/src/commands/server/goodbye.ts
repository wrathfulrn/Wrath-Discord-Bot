import { greetingCommand } from "./greeting.js";

export default greetingCommand("goodbye", "goodbye", "{user} has left {server}. We are now {count} members.");
