import { greetingCommand } from "./greeting.js";

export default greetingCommand("welcome", "welcome", "Welcome {user} to {server}! You are member #{count}.");
