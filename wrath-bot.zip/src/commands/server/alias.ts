import { OptionType, type Command } from "../../types.js";
import { extraConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "alias",
  description: "Map a custom alias to a command name",
  options: [
    { name: "alias", description: "Short name", type: OptionType.STRING, required: true },
    { name: "command", description: "Real command name", type: OptionType.STRING, required: true },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const a = (ctx.str("alias") ?? "").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "");
    const c = (ctx.str("command") ?? "").trim().toLowerCase();
    if (!a || !c) { await ctx.reply(privateError("Need alias and command.")); return; }
    const map = await extraConfig.getAliases(ctx.guildId);
    map[a] = c;
    await extraConfig.setAliases(ctx.guildId, map);
    await ctx.reply(`Alias \`,${a}\` → \`,${c}\`.`);
  },
};
export default command;
