import { OptionType, type Command } from "../../types.js";
import { extraConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "bumpreminder",
  description: "Enable DISBOARD-style bump reminders in this channel",
  options: [
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
    { name: "hours", description: "Hours between bumps", type: OptionType.INTEGER, min_value: 1, max_value: 24 },
  ],
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const cfg = await extraConfig.getBump(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    cfg.channelId = ctx.channelId;
    const h = ctx.int("hours");
    if (h !== undefined) cfg.reminderHours = h;
    cfg.lastBumpAt = Date.now();
    await extraConfig.setBump(ctx.guildId, cfg);
    await ctx.reply(`Bump reminder **${cfg.enabled ? "on" : "off"}** every **${cfg.reminderHours}h** in this channel.`);
  },
};
export default command;
