import type { Group } from "../../types.js";
import welcome from "./welcome.js";
import goodbye from "./goodbye.js";
import setup from "./setup.js";
import nick from "./nick.js";
import guard from "./guard.js";
import announce from "./announce.js";
import bumpreminder from "./bump.js";
import alias from "./alias.js";

const group: Group = {
  name: "server",
  description: "Welcome/goodbye messages, server setup, nicknames, and join-spike alerts",
  subcommands: [welcome, goodbye, setup, nick, guard, announce, bumpreminder, alias],
};

export default group;
