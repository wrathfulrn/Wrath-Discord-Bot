import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "announce",
  description: "Post a styled announcement in the current channel",
  options: [
    { name: "title", description: "Announcement title", type: OptionType.STRING, required: true },
    { name: "message", description: "Announcement text", type: OptionType.STRING, required: true },
  ],
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Use this command in a server channel.")); return; }
    if (!ctx.hasPermission(PERM.MANAGE_GUILD)) { await ctx.reply(privateError("You need Manage Server permission to post announcements.")); return; }
    const title = (ctx.str("title") ?? "Announcement").trim().slice(0, 256);
    const message = (ctx.str("message") ?? "").trim().slice(0, 4000);
    if (!message) { await ctx.reply(privateError("Announcement text cannot be empty.")); return; }
    try {
      await ctx.bot.helpers.sendMessage(ctx.channelId, { embeds: [{ title, description: message, color: 0xf5b942, footer: { text: "Wrath • Server announcement" }, timestamp: new Date().toISOString() }] } as never);
      await ctx.reply({ content: "📣 Announcement posted.", ephemeral: true });
    } catch {
      await ctx.reply(privateError("I couldn't post the announcement. Check my Send Messages and Embed Links permissions."));
    }
  },
};
export default command;
