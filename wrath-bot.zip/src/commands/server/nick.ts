import { setNickname } from "../../discord.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "nick",
  description: "Change or reset a member's nickname",
  options: [
    { name: "user", description: "Member", type: OptionType.USER, required: true },
    { name: "name", description: "New nickname. Leave empty to reset it.", type: OptionType.STRING },
  ],

  async execute(ctx) {
    if (!ctx.hasPermission(PERM.MANAGE_NICKNAMES)) {
      await ctx.reply(privateError("You need the Manage Nicknames permission for that."));
      return;
    }

    const target = ctx.user("user");
    if (!ctx.guildId || !target) {
      await ctx.reply(privateError("This command only works in a server."));
      return;
    }

    const name = ctx.str("name")?.trim() || null;
    if (name && name.length > 32) {
      await ctx.reply(privateError("Nicknames can be at most 32 characters."));
      return;
    }

    try {
      await setNickname(ctx.bot, ctx.guildId, target.id, name, `${ctx.username}: nickname change`);
    } catch {
      await ctx.reply(privateError("I couldn't change that nickname. Check my role position."));
      return;
    }

    await ctx.reply(
      name
        ? `Nickname for <@${target.id}> is now **${name}**.`
        : `Reset the nickname for <@${target.id}>.`,
    );
  },
};

export default command;
