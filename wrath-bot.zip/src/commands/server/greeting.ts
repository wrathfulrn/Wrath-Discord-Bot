import { getGreeting, setGreeting } from "../../db/features.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { renderGreeting } from "../../utils/greeting.js";

/** Builds the welcome or goodbye command. They share the same options and behaviour. */
export function greetingCommand(name: string, kind: "welcome" | "goodbye", defaultText: string): Command {
  return {
    name,
    description: `Turn ${kind} messages on, off, or preview them`,
    options: [
      {
        name: "action",
        description: "on, off, or test",
        type: OptionType.STRING,
        required: true,
        choices: [
          { name: "on", value: "on" },
          { name: "off", value: "off" },
          { name: "test", value: "test" },
        ],
      },
      {
        name: "message",
        description: "Text to send. Use {user}, {server}, and {count}",
        type: OptionType.STRING,
      },
    ],

    async execute(ctx) {
      if (!ctx.guildId || !ctx.channelId) {
        await ctx.reply(privateError("Use this in a server channel."));
        return;
      }

      const action = ctx.str("action");
      if (action !== "test" && !ctx.hasPermission(PERM.MANAGE_GUILD) && !ctx.hasPermission(PERM.ADMINISTRATOR)) {
        await ctx.reply(privateError("You need Manage Server permission to change greeting settings."));
        return;
      }

      if (action === "on") {
        await setGreeting(ctx.guildId, kind, {
          channelId: ctx.channelId,
          message: ctx.str("message") ?? defaultText,
        });
        await ctx.reply(`${kind} messages will be posted in <#${ctx.channelId}>.`);
        return;
      }

      if (action === "off") {
        await setGreeting(ctx.guildId, kind, null);
        await ctx.reply(`${kind} messages are off.`);
        return;
      }

      const greeting = await getGreeting(ctx.guildId, kind);
      if (!greeting) {
        await ctx.reply(privateError(`${kind} messages are off. Turn them on with \`${name} on\`.`));
        return;
      }
      const guild = await ctx.guildInfo();
      await ctx.reply(renderGreeting(greeting.message, {
        userId: ctx.userId,
        serverName: guild?.name ?? "this server",
        memberCount: guild?.memberCount ?? 0,
      }));
    },
  };
}
