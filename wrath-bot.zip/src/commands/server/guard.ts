import { getGuardSettings, setGuardSettings } from "../../db/features.js";
import { OptionType, PERM, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
const command: Command = {
  name: "guard", description: "Configure join-spike alerts for this server",
  options: [{ name: "action", description: "Enable, disable, or view protection", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }, { name: "status", value: "status" }] }],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Use this in a server.")); return; }
    if (!ctx.hasPermission(PERM.ADMINISTRATOR)) { await ctx.reply(privateError("You need Administrator permission to change server protection.")); return; }
    const action = ctx.str("action");
    const old = await getGuardSettings(ctx.guildId);
    if (action === "status") {
      await ctx.reply({ embeds: [{ title: "Wrath Guard", description: `Join-spike alerts: **${old.enabled ? "Enabled" : "Disabled"}**\nAlert channel: ${old.alertChannelId ? `<#${old.alertChannelId}>` : "Not configured"}\n\nWhen enabled, Wrath alerts here if 5 or more members join within 10 seconds. It does not automatically punish members.`, color: 0x8b7cff }] });
      return;
    }
    if (action === "on" && !ctx.channelId) { await ctx.reply(privateError("Run this in the channel where you want guard alerts.")); return; }
    await setGuardSettings(ctx.guildId, { enabled: action === "on", alertChannelId: action === "on" ? ctx.channelId! : old.alertChannelId });
    await ctx.reply(action === "on" ? `🛡️ Wrath Guard enabled. Join-spike alerts will be posted in <#${ctx.channelId}>.` : "🛡️ Wrath Guard alerts disabled.");
  },
};
export default command;
