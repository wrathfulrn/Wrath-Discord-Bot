import type { Group } from "../../types.js";
import { ownerFarmReset, ownerInventoryClear, ownerCustomAdd, ownerCustomRemove } from "../owner/admin.js";

const group: Group = {
  name: "owner-tools",
  description: "Owner-only farm, inventory, and custom command tools",
  subcommands: [ownerFarmReset, ownerInventoryClear, ownerCustomAdd, ownerCustomRemove],
};
export default group;
