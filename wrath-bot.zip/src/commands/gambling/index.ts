import type { Group } from "../../types.js";
import coinflip from "./coinflip.js";
import slots from "./slots.js";
import rob from "./rob.js";

const group: Group = {
  name: "gambling",
  description: "Coinflips, slots, and robbery",
  subcommands: [coinflip, slots, rob],
};

export default group;
