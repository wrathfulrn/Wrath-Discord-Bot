import { config } from "../../config.js";
import { addBalance, getUser, trySpend } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "rob",
  description: "Try to steal coins from someone (50% chance)",
  options: [{ name: "user", description: "Target", type: OptionType.USER, required: true }],

  async execute(ctx) {
    const target = ctx.user("user");

    if (!target || target.bot || target.id === ctx.userId) {
      await ctx.reply(privateError("That is not a valid target."));
      return;
    }

    const victim = await getUser(target.id);
    if (victim.balance < config.robMinVictimBalance) {
      await ctx.reply(privateError(`${target.username} is too broke to rob.`));
      return;
    }

    if (Math.random() < 0.5) {
      const maxSteal = Math.min(Math.floor(victim.balance / 4), config.robMaxSteal);
      const stolen = 1 + Math.floor(Math.random() * maxSteal);
      if (await trySpend(target.id, stolen)) {
        await addBalance(ctx.userId, stolen);
        await ctx.reply(`🦹 You robbed ${coins(stolen)} from <@${target.id}>!`);
        return;
      }
    }

    const fine = config.robFine;
    if (await trySpend(ctx.userId, fine)) {
      await addBalance(target.id, fine);
      await ctx.reply(`🚓 You got caught and paid a ${coins(fine)} fine to <@${target.id}>.`);
    } else {
      await ctx.reply("🚓 You got caught, but you couldn't even pay the fine.");
    }
  },
};

export default command;
