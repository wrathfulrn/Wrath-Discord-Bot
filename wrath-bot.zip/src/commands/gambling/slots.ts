import { addBalance, recordResult, trySpend } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const SYMBOLS = ["🍒", "🍋", "🔔", "⭐", "💎", "7️⃣"];
const WEIGHTS = [30, 25, 20, 12, 8, 5];
const TRIPLE_MULTIPLIER: Record<string, number> = {
  "🍒": 3, "🍋": 4, "🔔": 6, "⭐": 10, "💎": 20, "7️⃣": 50,
};

function spinReel(): string {
  const total = WEIGHTS.reduce((a, b) => a + b, 0);
  let roll = Math.random() * total;
  for (let i = 0; i < SYMBOLS.length; i++) {
    roll -= WEIGHTS[i];
    if (roll < 0) return SYMBOLS[i];
  }
  return SYMBOLS[0];
}

const command: Command = {
  name: "slots",
  description: "Spin the slot machine",
  options: [{ name: "bet", description: "Coins to bet", type: OptionType.INTEGER, required: true, min_value: 1 }],

  async execute(ctx) {
    const bet = ctx.int("bet") ?? 0;

    if (!(await trySpend(ctx.userId, bet))) {
      await ctx.reply(privateError("You don't have enough coins."));
      return;
    }

    const reels = [spinReel(), spinReel(), spinReel()];

    let multiplier = 0;
    if (reels[0] === reels[1] && reels[1] === reels[2]) {
      multiplier = TRIPLE_MULTIPLIER[reels[0]];
    } else if (new Set(reels).size === 2) {
      multiplier = 1; // two of a kind returns the bet
    }

    const payout = bet * multiplier;
    if (payout > 0) await addBalance(ctx.userId, payout);
    await recordResult(ctx.userId, multiplier > 1);

    const outcome = multiplier > 1
      ? `🎉 You won ${coins(payout)}!`
      : multiplier === 1
        ? "Two of a kind. Your bet is returned."
        : "No luck this time.";

    await ctx.reply(`🎰 [ ${reels.join(" | ")} ]\n${outcome}`);
  },
};

export default command;
