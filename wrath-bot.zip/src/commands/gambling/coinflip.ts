import { addBalance, recordResult, trySpend } from "../../db/index.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "coinflip",
  description: "Bet coins on heads or tails",
  options: [
    { name: "bet", description: "Coins to bet", type: OptionType.INTEGER, required: true, min_value: 1 },
    {
      name: "side",
      description: "Heads or tails",
      type: OptionType.STRING,
      required: true,
      choices: [
        { name: "Heads", value: "heads" },
        { name: "Tails", value: "tails" },
      ],
    },
  ],

  async execute(ctx) {
    const bet = ctx.int("bet") ?? 0;
    const side = ctx.str("side");

    if (!(await trySpend(ctx.userId, bet))) {
      await ctx.reply(privateError("You don't have enough coins."));
      return;
    }

    const result = Math.random() < 0.5 ? "heads" : "tails";

    if (result === side) {
      await addBalance(ctx.userId, bet * 2); // stake back plus winnings
      await recordResult(ctx.userId, true);
      await ctx.reply(`🪙 It's **${result}**! You won ${coins(bet)}.`);
    } else {
      await recordResult(ctx.userId, false);
      await ctx.reply(`🪙 It's **${result}**. You lost ${coins(bet)}.`);
    }
  },
};

export default command;
