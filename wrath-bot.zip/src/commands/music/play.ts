import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { estimateFingerprint } from "../../music/planner.js";
import { enqueue, getMusic, planNext } from "../../music/queue.js";
import { lavalinkConfigured, loadTracks } from "../../music/lavalink.js";

const command: Command = {
  name: "play",
  description: "Queue a track (YouTube search or URL via Lavalink)",
  options: [
    { name: "query", description: "Song name or URL", type: OptionType.STRING, required: true },
  ],

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Music only works in a server."));
      return;
    }
    if (!lavalinkConfigured()) {
      await ctx.reply(
        privateError(
          "Lavalink is not configured. Set `LAVALINK_HOST` and `LAVALINK_PASSWORD` in `.env`, run a Lavalink v4 node, then restart the bot.\n" +
            "True dual-deck crossfades need a custom multi-deck audio node; stock Lavalink is single-deck.",
        ),
      );
      return;
    }

    const query = (ctx.str("query") ?? "").trim();
    if (!query) {
      await ctx.reply(privateError("Give a song name or URL."));
      return;
    }

    let tracks;
    try {
      tracks = await loadTracks(query);
    } catch (e) {
      await ctx.reply(privateError(`Lavalink error: ${e instanceof Error ? e.message : "request failed"}`));
      return;
    }
    if (!tracks.length) {
      await ctx.reply(privateError("No results."));
      return;
    }

    const t = tracks[0];
    const fp = estimateFingerprint({
      id: t.info.identifier,
      title: t.info.title,
      author: t.info.author,
      durationMs: t.info.length,
      uri: t.info.uri,
    });
    const pos = enqueue(ctx.guildId, { ...fp, requestedBy: ctx.userId });
    const state = getMusic(ctx.guildId);
    state.textChannelId = ctx.channelId;

    // Voice channel attach is host-specific; we store intent and surface next steps.
    const plan = planNext(ctx.guildId);
    const planLine = plan
      ? `\nAutomix plan → **${plan.strategy}** (${plan.reason})`
      : state.automix
        ? "\nAutomix on — waiting for a second track to plan a transition."
        : "\nAutomix off — use `,automix on` for planned transitions.";

    await ctx.reply(
      `🎵 Queued **${fp.title}** by ${fp.author} (position ${pos})` +
        `\n_Encoded track ready for Lavalink player session._` +
        planLine +
        `\n\n**Note:** Connect the bot to your voice channel with your Lavalink session (player API). ` +
        `This build ships the automix **planner** + queue; wire \`encoded\` to your node to hear audio.`,
    );
  },
};

export default command;
