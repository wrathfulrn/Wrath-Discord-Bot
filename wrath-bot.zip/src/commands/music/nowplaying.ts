import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { getMusic } from "../../music/queue.js";

const command: Command = {
  name: "nowplaying",
  description: "Show the current track and fingerprint hints",
  options: [],

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Music only works in a server."));
      return;
    }
    const s = getMusic(ctx.guildId);
    if (!s.current) {
      await ctx.reply("Nothing is playing.");
      return;
    }
    const t = s.current;
    const lines = [
      `**${t.title}** — ${t.author}`,
      t.bpm ? `BPM ~**${t.bpm}**` : null,
      t.key ? `Key **${t.key}** (Camelot)` : null,
      t.lufs !== undefined ? `Loudness ~**${t.lufs} LUFS**` : null,
      t.energy !== undefined ? `Energy **${(t.energy * 100).toFixed(0)}%**` : null,
      s.lastPlan ? `Last plan: **${s.lastPlan.strategy}**` : null,
    ].filter(Boolean);
    await ctx.reply({ embeds: [{ title: "▶️ Now playing", description: lines.join("\n"), color: 0x1abc9c }] });
  },
};

export default command;
