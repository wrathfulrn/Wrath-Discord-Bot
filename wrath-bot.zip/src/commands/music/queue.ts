import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { getMusic } from "../../music/queue.js";

const command: Command = {
  name: "queue",
  description: "Show the music queue and last automix plan",

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Music only works in a server."));
      return;
    }
    const s = getMusic(ctx.guildId);
    const lines: string[] = [];
    if (s.current) {
      lines.push(`**Now:** ${s.current.title} — ${s.current.author}`);
    }
    if (s.queue.length === 0 && !s.current) {
      await ctx.reply("Queue is empty. `,play <song>`");
      return;
    }
    s.queue.slice(0, 15).forEach((t, i) => {
      lines.push(`**${i + 1}.** ${t.title} — ${t.author}`);
    });
    if (s.queue.length > 15) lines.push(`_…and ${s.queue.length - 15} more_`);
    if (s.lastPlan) {
      lines.push("", `**Automix:** ${s.lastPlan.strategy} · score ${s.lastPlan.score.toFixed(2)} · blend ${(s.lastPlan.blendMs / 1000).toFixed(1)}s`);
    }
    lines.push(`Automix: **${s.automix ? "on" : "off"}** · volume ${s.volume}%`);
    await ctx.reply({
      embeds: [{ title: "🎶 Queue", description: lines.join("\n"), color: 0x9b59b6 }],
    });
  },
};

export default command;
