import { OptionType, type Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { getMusic, planNext } from "../../music/queue.js";

const command: Command = {
  name: "automix",
  description: "Toggle DJ-style transition planning (brain)",
  options: [
    {
      name: "mode",
      description: "on or off",
      type: OptionType.STRING,
      required: true,
      choices: [
        { name: "on", value: "on" },
        { name: "off", value: "off" },
      ],
    },
  ],

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Music only works in a server."));
      return;
    }
    const mode = (ctx.str("mode") ?? "").toLowerCase();
    const s = getMusic(ctx.guildId);
    s.automix = mode === "on";
    const plan = planNext(ctx.guildId);
    if (!s.automix) {
      await ctx.reply("Automix **off** — tracks will hard-cut.");
      return;
    }
    await ctx.reply(
      "Automix **on**. The bot will score the next pair (tempo, key, energy, structure) and pick a strategy: " +
        "`outro-intro`, `phrase-blend`, `bass-swap`, `energy-rise` / `release`, or `crossfade`.\n" +
        (plan
          ? `Next plan: **${plan.strategy}** — ${plan.reason}`
          : "Queue another track with `,play` to plan a transition.") +
        "\n\n_Audio crossfade still needs Lavalink; dual-deck needs a **forked** node );
  },
};

export default command;
