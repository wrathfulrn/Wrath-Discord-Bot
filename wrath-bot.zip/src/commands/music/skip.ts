import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { getMusic, planNext, shiftNext } from "../../music/queue.js";

const command: Command = {
  name: "skip",
  description: "Skip to the next track (runs automix planner)",

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Music only works in a server."));
      return;
    }
    const s = getMusic(ctx.guildId);
    const next = shiftNext(ctx.guildId);
    if (!next) {
      await ctx.reply("Nothing left in the queue.");
      return;
    }
    const plan = planNext(ctx.guildId);
    await ctx.reply(
      `⏭️ **${next.title}**` +
        (plan ? `\nTransition: **${plan.strategy}** — ${plan.reason}` : ""),
    );
  },
};

export default command;
