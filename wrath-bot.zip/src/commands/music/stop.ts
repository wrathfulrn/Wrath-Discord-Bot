import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";
import { clearQueue, getMusic } from "../../music/queue.js";

const command: Command = {
  name: "stop",
  description: "Clear the queue and stop",

  async execute(ctx) {
    if (!ctx.guildId) {
      await ctx.reply(privateError("Music only works in a server."));
      return;
    }
    clearQueue(ctx.guildId);
    getMusic(ctx.guildId).paused = false;
    await ctx.reply("⏹️ Cleared the queue.");
  },
};

export default command;
