import type { Group } from "../../types.js";
import play from "./play.js";
import queue from "./queue.js";
import skip from "./skip.js";
import stop from "./stop.js";
import automix from "./automix.js";
import nowplaying from "./nowplaying.js";

const group: Group = {
  name: "music",
  description: "Music queue and automix planner",
  guildOnly: true,
  subcommands: [play, queue, skip, stop, automix, nowplaying],
};

export default group;
