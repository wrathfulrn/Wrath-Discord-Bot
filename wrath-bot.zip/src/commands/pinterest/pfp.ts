import { config } from "../../config.js";
import { boardPins, PinterestError } from "../../pinterest/api.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "pfp",
  description: "Show a random pin from your Pinterest board",

  async execute(ctx) {
    if (!config.pinterestBoardId) {
      await ctx.reply(privateError("Set PINTEREST_BOARD_ID in .env. Run `,boards` to find it."));
      return;
    }

    try {
      const pins = await boardPins(config.pinterestBoardId);
      if (pins.length === 0) {
        await ctx.reply(privateError("That board has no pins with images yet."));
        return;
      }

      const pin = pins[Math.floor(Math.random() * pins.length)];
      await ctx.reply({
        embeds: [{
          title: pin.title,
          url: `https://www.pinterest.com/pin/${pin.id}/`,
          image: { url: pin.imageUrl },
          color: 0xd4a017,
          footer: { text: "From Pinterest" },
        }],
      });
    } catch (error) {
      if (error instanceof PinterestError) {
        await ctx.reply(privateError(error.message));
      } else {
        console.error("pfp failed:", error);
        await ctx.reply(privateError("Couldn't load pins right now. Try again later."));
      }
    }
  },
};

export default command;
