import { config } from "../../config.js";
import { listBoards, PinterestError } from "../../pinterest/api.js";
import type { Command } from "../../types.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "boards",
  description: "List your Pinterest boards and their IDs (bot owner only)",

  async execute(ctx) {
    // Board names can be private, so only the bot owner can list them.
    if (!config.ownerId || ctx.userId !== config.ownerId) {
      await ctx.reply(privateError("Only the bot owner can list boards."));
      return;
    }

    try {
      const boards = await listBoards();
      const lines = boards.map((b) => `• **${b.name}**: \`${b.id}\``);
      await ctx.reply({
        embeds: [{
          title: "Your Pinterest boards",
          description: lines.join("\n") || "No boards found.",
          color: 0xd4a017,
        }],
      });
    } catch (error) {
      if (error instanceof PinterestError) {
        await ctx.reply(privateError(error.message));
      } else {
        console.error("boards failed:", error);
        await ctx.reply(privateError("Couldn't load your boards right now."));
      }
    }
  },
};

export default command;
