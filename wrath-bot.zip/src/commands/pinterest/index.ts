import type { Group } from "../../types.js";
import pfp from "./pfp.js";
import boards from "./boards.js";

const group: Group = {
  name: "pinterest",
  description: "Random pins from your own Pinterest board",
  subcommands: [pfp, boards],
};

export default group;
