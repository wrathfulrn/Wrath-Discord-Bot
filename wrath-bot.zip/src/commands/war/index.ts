import type { Group } from "../../types.js";
import army from "./army.js";
import recruit from "./recruit.js";
import train from "./train.js";
import battle from "./battle.js";

const group: Group = {
  name: "war",
  description: "Recruit troops, train your army, and battle other players",
  subcommands: [army, recruit, train, battle],
};

export default group;
