import { addTraining } from "../../db/features.js";
import { trySpend } from "../../db/index.js";
import { TRAINING_COST } from "../../data/troops.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "train",
  description: "Train your army to add power",
  options: [{
    name: "points",
    description: "Power to add (1 to 100)",
    type: OptionType.INTEGER,
    required: true,
    min_value: 1,
    max_value: 100,
  }],

  async execute(ctx) {
    const points = ctx.int("points") ?? 0;
    const cost = points * TRAINING_COST;

    if (!(await trySpend(ctx.userId, cost))) {
      await ctx.reply(privateError(`Training ${points} power costs ${coins(cost)}.`));
      return;
    }

    await addTraining(ctx.userId, points);
    await ctx.reply(`🏋️ Your army gained ${points} power for ${coins(cost)}.`);
  },
};

export default command;
