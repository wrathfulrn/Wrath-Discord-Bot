import { addTroops } from "../../db/features.js";
import { trySpend } from "../../db/index.js";
import { findTroop, TROOP_CHOICES } from "../../data/troops.js";
import { OptionType, type Command } from "../../types.js";
import { coins, privateError } from "../../utils/format.js";

const command: Command = {
  name: "recruit",
  description: "Recruit troops for your army",
  options: [
    { name: "troop", description: "Type of troop", type: OptionType.STRING, required: true, choices: TROOP_CHOICES },
    { name: "amount", description: "How many (1 to 50)", type: OptionType.INTEGER, min_value: 1, max_value: 50 },
  ],

  async execute(ctx) {
    const troop = findTroop(ctx.str("troop"));
    const amount = ctx.int("amount") ?? 1;
    if (!troop) {
      await ctx.reply(privateError("That troop doesn't exist."));
      return;
    }

    const cost = troop.cost * amount;
    if (!(await trySpend(ctx.userId, cost))) {
      await ctx.reply(privateError(`${amount} ${troop.name}(s) cost ${coins(cost)}.`));
      return;
    }

    await addTroops(ctx.userId, troop.id, amount);
    await ctx.reply(`${troop.emoji} Recruited ${amount} ${troop.name}(s) for ${coins(cost)}.`);
  },
};

export default command;
