import { config } from "../../config.js";
import { armyPower, claimBattle, getArmy } from "../../db/features.js";
import { getUser, transfer } from "../../db/index.js";
import { BATTLE_COOLDOWN_MS, LOOT_SHARE, MAX_LOOT } from "../../data/troops.js";
import { OptionType, type Command } from "../../types.js";
import { coins, cooldownLeft, cooldownNotice, privateError } from "../../utils/format.js";

const command: Command = {
  name: "battle",
  description: "Send your army against another player to win coins",
  options: [{ name: "user", description: "Player to battle", type: OptionType.USER, required: true }],

  async execute(ctx) {
    const target = ctx.user("user");
    if (!target || target.bot || target.id === ctx.userId) {
      await ctx.reply(privateError("Pick another player to battle."));
      return;
    }

    const mine = await getArmy(ctx.userId);
    const myPower = armyPower(mine);
    if (myPower === 0) {
      await ctx.reply(privateError(`You have no troops. Use \`${config.prefix}recruit\` first.`));
      return;
    }

    const theirPower = armyPower(await getArmy(target.id));
    if (theirPower === 0) {
      await ctx.reply(privateError(`<@${target.id}> has no army to fight.`));
      return;
    }

    if (!(await claimBattle(ctx.userId, BATTLE_COOLDOWN_MS))) {
      const wait = cooldownLeft(mine.lastBattle, BATTLE_COOLDOWN_MS);
      await ctx.reply({ content: cooldownNotice(wait), ephemeral: true });
      return;
    }

    // Each side rolls between half and all of its power, so the stronger army usually wins.
    const attackRoll = myPower * (0.5 + Math.random());
    const defendRoll = theirPower * (0.5 + Math.random());

    if (attackRoll > defendRoll) {
      const defender = await getUser(target.id);
      const loot = Math.min(Math.floor(defender.balance * LOOT_SHARE), MAX_LOOT);
      const taken = loot > 0 && (await transfer(target.id, ctx.userId, loot)) ? loot : 0;
      await ctx.reply(
        `⚔️ Victory! Your army (${myPower} power) beat <@${target.id}> (${theirPower} power). ` +
          `You took ${coins(taken)}.`,
      );
    } else {
      const attacker = await getUser(ctx.userId);
      const lost = Math.min(Math.floor(attacker.balance * LOOT_SHARE), MAX_LOOT);
      const paid = lost > 0 && (await transfer(ctx.userId, target.id, lost)) ? lost : 0;
      await ctx.reply(
        `🛡️ Defeat. <@${target.id}>'s army (${theirPower} power) held against your ${myPower} power. ` +
          `You lost ${coins(paid)}.`,
      );
    }
  },
};

export default command;
