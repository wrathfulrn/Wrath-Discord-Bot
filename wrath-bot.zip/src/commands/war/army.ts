import { armyPower, getArmy } from "../../db/features.js";
import { BATTLE_COOLDOWN_MS, TROOPS } from "../../data/troops.js";
import { OptionType, type Command } from "../../types.js";
import { cooldownLeft, fmtDuration } from "../../utils/format.js";

const command: Command = {
  name: "army",
  description: "Show an army's troops and power",
  options: [{ name: "user", description: "Player to check", type: OptionType.USER }],

  async execute(ctx) {
    const target = ctx.userOrSelf("user");
    const army = await getArmy(target.id);

    const fields = TROOPS.map((t) => ({
      name: `${t.emoji} ${t.name}`,
      value: `${army.troops[t.id] ?? 0} (${t.power} power each)`,
      inline: true,
    }));
    fields.push({ name: "🏋️ Training", value: `${army.training} power`, inline: true });

    const resting = cooldownLeft(army.lastBattle, BATTLE_COOLDOWN_MS);
    const status = resting > 0 ? `Resting, next battle in ${fmtDuration(resting)}` : "Ready to battle";

    await ctx.reply({
      embeds: [{
        title: `${target.username}'s army`,
        description: `Total power: **${armyPower(army)}**\n${status}`,
        fields,
      }],
    });
  },
};

export default command;
