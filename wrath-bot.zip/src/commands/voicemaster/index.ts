import type { Group } from "../../types.js";
import vmsetup from "./setup.js";
const group: Group = { name: "voicemaster", description: "Join-to-create voice channels", guildOnly: true, subcommands: [vmsetup] };
export default group;
