import { OptionType, type Command } from "../../types.js";
import { extraConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "vmsetup",
  description: "Enable VoiceMaster using this channel as the join-to-create hub",
  options: [
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
  ],
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 4n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Channels.")); return;
    }
    const cfg = await extraConfig.getVoiceMaster(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    cfg.hubChannelId = ctx.channelId;
    await extraConfig.setVoiceMaster(ctx.guildId, cfg);
    await ctx.reply(
      cfg.enabled
        ? `VoiceMaster **on**. Join <#${ctx.channelId}> to get a personal voice channel. Name template: \`${cfg.nameTemplate}\`.`
        : "VoiceMaster **off**.",
    );
  },
};
export default command;
