import { OptionType, type Command } from "../../types.js";
import { guildConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "counting",
  description: "Enable counting in this channel",
  options: [
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
  ],
  async execute(ctx) {
    if (!ctx.guildId || !ctx.channelId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const cfg = await guildConfig.getCounting(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    cfg.channelId = ctx.channelId;
    cfg.next = 1;
    cfg.lastUserId = undefined;
    await guildConfig.setCounting(ctx.guildId, cfg);
    await ctx.reply(cfg.enabled ? `Counting **on** here. Next number: **1**.` : `Counting **off**.`);
  },
};
export default command;
