import { OptionType, type Command } from "../../types.js";
import { guildConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "antinuke",
  description: "Toggle antinuke whitelist protection",
  options: [
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
    { name: "whitelist", description: "User id to whitelist (optional)", type: OptionType.STRING },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Administrator.")); return;
    }
    const cfg = await guildConfig.getAntinuke(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    const wl = ctx.str("whitelist");
    if (wl && !cfg.whitelist.includes(wl)) cfg.whitelist.push(wl);
    if (!cfg.whitelist.includes(ctx.userId)) cfg.whitelist.push(ctx.userId);
    cfg.logChannelId = ctx.channelId;
    await guildConfig.setAntinuke(ctx.guildId, cfg);
    await ctx.reply(
      `Antinuke **${cfg.enabled ? "on" : "off"}**. Whitelist: ${cfg.whitelist.map((id) => `\`${id}\``).join(", ") || "none"}.\n` +
      `_Full audit-log antinuke needs Gateway audit intents; this stores config and whitelist for staff tools._`,
    );
  },
};
export default command;
