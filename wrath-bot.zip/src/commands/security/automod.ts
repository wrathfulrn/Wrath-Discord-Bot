import { OptionType, type Command } from "../../types.js";
import { guildConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "automod",
  description: "Configure automod (invites, mentions, spam lines)",
  options: [
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const cfg = await guildConfig.getAutomod(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    await guildConfig.setAutomod(ctx.guildId, cfg);
    await ctx.reply(`Automod **${cfg.enabled ? "enabled" : "disabled"}**. Invites blocked: ${cfg.blockInvites}, max mentions: ${cfg.maxMentions}.`);
  },
};
export default command;
