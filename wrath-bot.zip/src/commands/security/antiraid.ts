import { OptionType, type Command } from "../../types.js";
import { guildConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "antiraid",
  description: "Configure join-spike protection",
  options: [
    { name: "enabled", description: "on or off", type: OptionType.STRING, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }] },
    { name: "threshold", description: "Joins in window to trigger", type: OptionType.INTEGER, min_value: 3, max_value: 50 },
    { name: "window", description: "Window seconds", type: OptionType.INTEGER, min_value: 5, max_value: 120 },
    { name: "action", description: "alert, kick, ban, timeout", type: OptionType.STRING, choices: [
      { name: "alert", value: "alert" }, { name: "kick", value: "kick" }, { name: "ban", value: "ban" }, { name: "timeout", value: "timeout" },
    ]},
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const cfg = await guildConfig.getAntiraid(ctx.guildId);
    cfg.enabled = ctx.str("enabled") === "on";
    const th = ctx.int("threshold"); if (th !== undefined) cfg.joinThreshold = th;
    const w = ctx.int("window"); if (w !== undefined) cfg.windowSeconds = w;
    const act = ctx.str("action") as typeof cfg.action | undefined;
    if (act) cfg.action = act;
    cfg.alertChannelId = ctx.channelId;
    await guildConfig.setAntiraid(ctx.guildId, cfg);
    await ctx.reply(`Antiraid **${cfg.enabled ? "on" : "off"}** · ${cfg.joinThreshold} joins / ${cfg.windowSeconds}s · action **${cfg.action}** (alerts → this channel).`);
  },
};
export default command;
