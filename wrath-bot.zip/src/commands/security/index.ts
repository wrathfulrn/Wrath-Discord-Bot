import type { Group } from "../../types.js";
import automod from "./automod.js";
import antiraid from "./antiraid.js";
import antinuke from "./antinuke.js";
import logging from "./logging.js";
import autorespond from "./autorespond.js";
import counting from "./counting.js";

const group: Group = {
  name: "security",
  description: "Automod, antiraid, antinuke, logging, autorespond, counting",
  guildOnly: true,
  subcommands: [automod, antiraid, antinuke, logging, autorespond, counting],
};
export default group;
