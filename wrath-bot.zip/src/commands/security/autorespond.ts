import { OptionType, type Command } from "../../types.js";
import { guildConfig } from "../../db/guildConfig.js";
import { privateError } from "../../utils/format.js";

const command: Command = {
  name: "autorespond",
  description: "Add an autoresponder (trigger → reply)",
  options: [
    { name: "trigger", description: "Text to match", type: OptionType.STRING, required: true },
    { name: "response", description: "Reply text", type: OptionType.STRING, required: true },
  ],
  async execute(ctx) {
    if (!ctx.guildId) { await ctx.reply(privateError("Server only.")); return; }
    if (!ctx.hasPermission(1n << 5n) && !ctx.hasPermission(1n << 3n)) {
      await ctx.reply(privateError("Need Manage Server.")); return;
    }
    const trigger = (ctx.str("trigger") ?? "").trim().slice(0, 100);
    const response = (ctx.str("response") ?? "").trim().slice(0, 1500);
    if (!trigger || !response) { await ctx.reply(privateError("Need trigger and response.")); return; }
    const list = await guildConfig.getAutoresponses(ctx.guildId);
    if (list.length >= 25) { await ctx.reply(privateError("Max 25 autoresponses.")); return; }
    list.push({ trigger, response, exact: false });
    await guildConfig.setAutoresponses(ctx.guildId, list);
    await ctx.reply(`Autoresponse added for \`${trigger}\` (${list.length}/25).`);
  },
};
export default command;
