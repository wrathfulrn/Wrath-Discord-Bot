import type { Command, Group } from "../../types.js";

const violet = 0x8b5cf6;
const stringOption = (name: string, description: string) => ({ name, description, type: 3, required: true });
function textTool(name: string, description: string, transform: (text: string) => string): Command {
  return {
    name, description, options: [stringOption("text", "Text to process")],
    async execute(ctx) {
      const result = transform(ctx.str("text") ?? "");
      await ctx.reply(result.length > 1900 ? `${result.slice(0, 1890)}…` : result || "Nothing to show.");
    },
  };
}

const charinfo = textTool("charinfo", "Show code points for each character", (text) => {
  if (!text) return "Provide some text.";
  return Array.from(text).slice(0, 30).map((ch) => `\`${ch === " " ? "space" : ch}\` — U+${ch.codePointAt(0)!.toString(16).toUpperCase().padStart(4, "0")}`).join("\n");
});
const emojify = textTool("emojify", "Turn letters into emoji-style regional indicators", (text) => {
  const out = text.toUpperCase().split("").map((ch) => /[A-Z]/.test(ch) ? `:regional_indicator_${ch.toLowerCase()}:` : ch === " " ? "   " : ch).join(" ");
  return out.slice(0, 1900);
});
const mock = textTool("mock", "Make text alternating upper and lower case", (text) => Array.from(text).map((ch, i) => i % 2 ? ch.toLowerCase() : ch.toUpperCase()).join(""));
const spoiler = textTool("spoiler", "Wrap text in Discord spoiler formatting", (text) => `||${text}||`);
const codeblock = textTool("codeblock", "Format text as a code block", (text) => `\`\`\`\n${text.replace(/```/g, "'''")}\n\`\`\``);
const quote = textTool("quote", "Format a message as a block quote", (text) => text.split("\n").map((line) => `> ${line}`).join("\n"));
const urlencode = textTool("urlencode", "URL-encode text", (text) => encodeURIComponent(text));
const urldecode = textTool("urldecode", "Decode URL-encoded text", (text) => { try { return decodeURIComponent(text); } catch { return "That isn't valid URL-encoded text."; } });
const base64 = textTool("base64", "Encode text as Base64", (text) => Buffer.from(text, "utf8").toString("base64"));
const unbase64 = textTool("unbase64", "Decode Base64 text", (text) => { try { return Buffer.from(text, "base64").toString("utf8"); } catch { return "Could not decode that Base64 value."; } });

const color: Command = {
  name: "color", description: "Preview a hexadecimal color code", options: [stringOption("hex", "Hex color, e.g. #8b5cf6")],
  async execute(ctx) {
    const raw = (ctx.str("hex") ?? "").trim().replace(/^#/, "");
    if (!/^(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(raw)) { await ctx.reply("Use a 3- or 6-digit hex color, such as `#8b5cf6`."); return; }
    const normalized = raw.length === 3 ? raw.split("").map((x) => x + x).join("") : raw;
    const n = Number.parseInt(normalized, 16);
    await ctx.reply({ embeds: [{ title: `#${normalized.toUpperCase()}`, description: `RGB: ${Number((n >> 16) & 255)}, ${Number((n >> 8) & 255)}, ${Number(n & 255)}`, color: n, footer: { text: "Wrath Color Preview" } }] });
  },
};
const timestamp: Command = {
  name: "timestamp", description: "Create a Discord timestamp from a Unix time", options: [{ name: "unix", description: "Unix time in seconds", type: 4, required: true }],
  async execute(ctx) {
    const unix = ctx.int("unix");
    if (unix === undefined || !Number.isSafeInteger(unix) || unix < 0 || unix > 253402300799) { await ctx.reply("Enter a valid Unix timestamp in seconds."); return; }
    await ctx.reply(`Discord timestamp: <t:${unix}:F>\nRelative: <t:${unix}:R>\nCopy: \`<t:${unix}:F>\``);
  },
};
const roll: Command = {
  name: "random", description: "Pick a random integer between two numbers", options: [{ name: "min", description: "Minimum value", type: 4, required: true }, { name: "max", description: "Maximum value", type: 4, required: true }],
  async execute(ctx) {
    const min = ctx.int("min"), max = ctx.int("max");
    if (min === undefined || max === undefined || min > max || !Number.isSafeInteger(min) || !Number.isSafeInteger(max) || max - min > 1_000_000) { await ctx.reply("Use whole numbers with min ≤ max and a range no larger than 1,000,000."); return; }
    await ctx.reply(`🎲 Random number: **${Math.floor(Math.random() * (max - min + 1)) + min}**`);
  },
};
const poll: Command = {
  name: "poll", description: "Create a simple text poll", options: [stringOption("question", "Question and optional choices separated by |")],
  async execute(ctx) {
    const parts = (ctx.str("question") ?? "").split("|").map((x) => x.trim()).filter(Boolean);
    if (!parts.length) { await ctx.reply("Provide a question, optionally followed by choices separated with `|`."); return; }
    const choices = parts.slice(1, 9);
    const numbered = choices.length ? choices.map((x, i) => `${i + 1}. ${x}`).join("\n") : "React in chat or reply with your answer.";
    await ctx.reply({ embeds: [{ title: "📊 Poll", description: `**${parts[0]}**\n\n${numbered}`, color: violet, footer: { text: `Poll by ${ctx.username}` }, timestamp: new Date(ctx.createdAt).toISOString() }] });
  },
};
const rate: Command = {
  name: "rate", description: "Give a playful random rating to something", options: [stringOption("thing", "What should be rated?")],
  async execute(ctx) { await ctx.reply(`✨ I'd rate **${(ctx.str("thing") ?? "that").slice(0, 150)}** a **${Math.floor(Math.random() * 101)}/100**!`); },
};
const eightball: Command = {
  name: "8ball", description: "Ask the magic 8-ball a question", options: [stringOption("question", "Ask a question")],
  async execute(ctx) {
    const answers = ["Absolutely!", "Looks promising.", "I'd say yes.", "Try again later.", "Hard to tell right now.", "Probably not.", "The signs say no.", "Definitely not!"];
    await ctx.reply(`🎱 **${(ctx.str("question") ?? "Your question").slice(0, 300)}**\n${answers[Math.floor(Math.random() * answers.length)]}`);
  },
};
const choose: Command = {
  name: "choose", description: "Choose randomly from options separated by |", options: [stringOption("options", "At least two options separated by |")],
  async execute(ctx) { const opts = (ctx.str("options") ?? "").split("|").map((x) => x.trim()).filter(Boolean); await ctx.reply(opts.length < 2 ? "Provide at least two options separated by `|`." : `🎯 I choose: **${opts[Math.floor(Math.random() * opts.length)]}**`); },
};
const ship: Command = {
  name: "ship", description: "Generate a playful compatibility score for two names", options: [stringOption("pair", "Two names separated by |")],
  async execute(ctx) { const names = (ctx.str("pair") ?? "").split("|").map((x) => x.trim()).filter(Boolean); if (names.length !== 2) { await ctx.reply("Provide two names separated by `|`, e.g. `,ship Alex | Sam`."); return; } const score = Math.floor(Math.random() * 101); await ctx.reply(`💫 **${names[0].slice(0, 60)} + ${names[1].slice(0, 60)}**\nCompatibility meter: **${score}%**\n*Just for fun — not a real measure of compatibility.*`); },
};
function interaction(name: string, emoji: string, description: string, phrase: string): Command {
  return { name, description, options: [stringOption("user", "Who is this for?")], async execute(ctx) { const target = (ctx.str("user") ?? "someone").slice(0, 80); await ctx.reply(`${emoji} **${ctx.username}** ${phrase} **${target}**!`); } };
}
const hug = interaction("hug", "🫂", "Send a friendly virtual hug", "sends a friendly virtual hug to");
const pat = interaction("pat", "🐾", "Send a friendly pat", "gives a friendly pat to");
const highfive = interaction("highfive", "🙌", "Give someone a virtual high-five", "gives a high-five to");
const wave = interaction("wave", "👋", "Wave hello to someone", "waves to");
const cheer = interaction("cheer", "🎉", "Send someone some encouragement", "cheers on");
const compliment = interaction("compliment", "✨", "Send a friendly compliment", "sends good vibes to");

const group: Group = {
  name: "fun",
  description: "Text tools, social interactions, polls, and lighthearted commands",
  subcommands: [charinfo, emojify, mock, spoiler, codeblock, quote, urlencode, urldecode, base64, unbase64, color, timestamp, roll, poll, rate, eightball, choose, ship, hug, pat, highfive, wave, cheer, compliment],
};
export default group;
