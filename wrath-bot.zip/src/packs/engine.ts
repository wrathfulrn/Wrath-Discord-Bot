export type OptionKind = "none" | "text" | "int" | "user" | "pair";
export interface Spec { name: string; category: string; description: string; op: string; arg: string; kind: OptionKind; }
export interface RunInput { text?: string; int?: number; targetId?: string; targetName?: string; authorId?: string; authorName?: string; }

function hash32(s: string): number { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function pick<T>(arr: T[], seed: string): T { return arr[hash32(seed) % arr.length]; }

const EIGHT = ["It is certain.","Yes.","Most likely.","Ask again later.","Don't count on it.","My reply is no.","Very doubtful."];
const TIPS = ["Prefer clear names.","Small reversible steps.","Document decisions.","Defaults matter."];

function textOp(arg: string, t: string): string {
  if (arg === "mock") return Array.from(t).map((c, i) => (i % 2 ? c.toLowerCase() : c.toUpperCase())).join("");
  if (arg === "emojify") return t.toUpperCase().split("").map((c) => (/[A-Z]/.test(c) ? `:regional_indicator_${c.toLowerCase()}:` : c)).join(" ").slice(0, 1900);
  if (arg === "spoiler") return `||${t}||`;
  if (arg === "quote") return t.split("\n").map((l) => `> ${l}`).join("\n");
  if (arg === "codeblock") return "```\n" + t.replace(/```/g, "'''") + "\n```";
  if (arg === "clap") return t.split(/\s+/).filter(Boolean).join(" 👏 ");
  if (arg === "space") return Array.from(t).join(" ");
  if (arg === "rot13") return t.replace(/[a-zA-Z]/g, (c) => { const b = c <= "Z" ? 65 : 97; return String.fromCharCode(((c.charCodeAt(0) - b + 13) % 26) + b); });
  if (arg === "revwords") return t.split(/\s+/).reverse().join(" ");
  if (arg === "sortwords") return t.split(/\s+/).filter(Boolean).sort().join(" ");
  if (arg === "count") return `Characters: ${t.length} · Words: ${t.trim() ? t.trim().split(/\s+/).length : 0}`;
  if (arg === "leet") return t.replace(/a/gi, "4").replace(/e/gi, "3").replace(/i/gi, "1").replace(/o/gi, "0").replace(/s/gi, "5").replace(/t/gi, "7");
  if (arg === "title") return t.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
  if (arg === "camel") { const p = t.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean); return p.map((x, i) => (i ? x[0].toUpperCase() + x.slice(1) : x)).join(""); }
  if (arg === "snake") return t.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  if (arg === "kebab") return t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  if (arg === "len") return String(t.length);
  if (arg === "slug") return t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  if (arg === "uwu") return t.replace(/r|l/gi, (c) => (c === c.toUpperCase() ? "W" : "w")) + " uwu";
  if (arg === "noblank") return t.replace(/\s+/g, "");
  if (arg === "alpha") return t.replace(/[^a-zA-Z]/g, "");
  if (arg === "num") return t.replace(/[^0-9]/g, "");
  if (arg === "first") return t.trim().split(/\s+/)[0] ?? "";
  if (arg === "last") { const p = t.trim().split(/\s+/); return p[p.length - 1] ?? ""; }
  if (arg === "palin") { const c = t.toLowerCase().replace(/[^a-z0-9]/g, ""); return c && c === [...c].reverse().join("") ? "Yes — palindrome." : "No."; }
  if (arg === "hashmd5") return "hash:" + hash32(t).toString(16);
  if (arg === "b64url") { try { return Buffer.from(t, "utf8").toString("base64url"); } catch { return "encode failed"; } }
  const m = arg.match(/caesar(m?)(\d+)/);
  if (m) { let s = parseInt(m[2], 10); if (m[1] === "m") s = -s; return t.replace(/[a-zA-Z]/g, (c) => { const b = c <= "Z" ? 65 : 97; return String.fromCharCode(((c.charCodeAt(0) - b + s + 26) % 26) + b); }); }
  return t || "Provide text.";
}

function rollDice(expr: string): string {
  const m = expr.match(/^(\d+)d(\d+)$/i);
  if (!m) return "Use NdM e.g. 2d6";
  const n = Math.min(+m[1], 100), sides = Math.min(+m[2], 1000);
  const rolls: number[] = []; let total = 0;
  for (let i = 0; i < n; i++) { const r = 1 + Math.floor(Math.random() * sides); rolls.push(r); total += r; }
  return `Dice ${expr}: [${rolls.join(", ")}] = **${total}**`;
}

function nums(text: string): number[] { return (text.match(/-?\d+(\.\d+)?/g) ?? []).map(Number); }

function mathOp(arg: string, text: string): string {
  const n = nums(text); const a = n[0] ?? 0, b = n[1] ?? 0, c = n[2] ?? 0;
  if (arg === "compound") return `Compound: **${(a * Math.pow(1 + b / 100, c || 1)).toFixed(2)}**`;
  if (arg === "tip") return `Tip ${b || 15}% on ${a}: **${(a * ((b || 15) / 100)).toFixed(2)}**`;
  if (arg === "split") return b ? `Split ${a}/${b} = **${(a / b).toFixed(2)}**` : "Need amount people";
  if (arg === "discount") return `After ${b}% off ${a}: **${(a * (1 - b / 100)).toFixed(2)}**`;
  if (arg === "roi") return b ? `ROI **${(((b - a) / a) * 100).toFixed(2)}%**` : "Need cost return";
  if (arg === "pctof") return b ? `${a} is **${((a / b) * 100).toFixed(2)}%** of ${b}` : "Need two nums";
  if (arg === "pctchg") return a ? `Change **${(((b - a) / a) * 100).toFixed(2)}%**` : "Need from to";
  if (arg === "budget") return `Budget ${a}: 50% **${(a * 0.5).toFixed(0)}** 30% **${(a * 0.3).toFixed(0)}** 20% **${(a * 0.2).toFixed(0)}**`;
  if (arg === "networth") return `Sum **${n.reduce((s, x) => s + x, 0).toFixed(2)}**`;
  if (arg === "hourly") return `Hourly ~ **${(a / (b || 2080)).toFixed(2)}**`;
  if (arg === "salary") return `Salary ~ **${(a * (b || 2080)).toFixed(2)}**`;
  return `Numbers: ${n.join(", ") || "none"}`;
}

function convertOp(arg: string, text: string): string {
  const n = parseFloat(text) || 0;
  const map: Record<string, string> = {
    c2f: `${n}C = **${((n * 9) / 5 + 32).toFixed(2)}F**`, f2c: `${n}F = **${(((n - 32) * 5) / 9).toFixed(2)}C**`,
    km2mi: `${n}km = **${(n * 0.621371).toFixed(3)}mi**`, mi2km: `${n}mi = **${(n * 1.60934).toFixed(3)}km**`,
    kg2lb: `${n}kg = **${(n * 2.20462).toFixed(3)}lb**`, lb2kg: `${n}lb = **${(n * 0.453592).toFixed(3)}kg**`,
  };
  return map[arg] ?? "Unknown conversion";
}

function colorOp(arg: string, text: string): string {
  const t = (text || "").trim();
  if (arg === "hex2rgb") { const h = t.replace("#", ""); if (!/^[0-9a-fA-F]{6}$/.test(h)) return "Need #RRGGBB"; return `#${h} -> RGB(${parseInt(h.slice(0,2),16)}, ${parseInt(h.slice(2,4),16)}, ${parseInt(h.slice(4,6),16)})`; }
  if (arg === "rgb2hex") { const m = t.match(/(\d+)\D+(\d+)\D+(\d+)/); if (!m) return "Need R G B"; return "RGB -> **#" + [m[1],m[2],m[3]].map((x) => Math.min(255,+x).toString(16).padStart(2,"0")).join("") + "**"; }
  if (arg === "rand") return "#" + (hash32(t || String(Date.now())) >>> 0).toString(16).slice(0, 6).padStart(6, "0");
  return t || "Provide color";
}

function timeOp(arg: string, text: string): string {
  if (arg === "now") return `Unix **${Date.now()}**`;
  if (arg === "parse") { const n = +text; if (!n) return "Need timestamp"; return new Date(n > 1e12 ? n : n * 1000).toISOString(); }
  if (arg === "countdown") { const s = +text || 0; return `${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m ${s%60}s`; }
  if (arg === "age") { const y = +text; if (!y) return "Need year"; return `Age ~ **${new Date().getFullYear() - y}**`; }
  return "Time ready";
}

function rngOp(arg: string, text: string, seed: string): string {
  const s = seed + (text || "");
  if (arg === "8ball") return "8ball: " + pick(EIGHT, s);
  if (arg === "yesno") return pick(["Yes.", "No.", "Maybe."], s);
  if (arg === "rate") return `Rate **${text || "that"}**: **${hash32(s) % 11}/10**`;
  if (arg === "ship") { const p = (text || "a x b").split(/\s*(?:x|and|,)\s*/i); return `Ship ${p[0]||"A"} x ${p[1]||"B"}: **${hash32(s)%101}%**`; }
  if (arg === "pick") { const items = (text || "a,b,c").split(",").map((x) => x.trim()).filter(Boolean); return items.length ? "Picked: " + pick(items, s) : "Need options"; }
  if (arg === "shuffle") { const items = (text || "a,b,c").split(",").map((x) => x.trim()).filter(Boolean); const a = [...items]; for (let i = a.length - 1; i > 0; i--) { const j = hash32(s + i) % (i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a.join(", "); }
  if (arg === "coin") return pick(["Heads", "Tails"], s);
  if (arg === "pct") return `**${hash32(s) % 101}%**`;
  if (arg === "lucky") return `Lucky **${(hash32(s) % 99) + 1}**`;
  if (arg === "compliment") return pick(TIPS, s);
  if (arg === "insult") return pick(["Evolution took a coffee break.", "Stronger signal in spam."], s);
  if (arg === "uuid") return "id-" + hash32(s).toString(16);
  if (arg === "password") { const ch = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"; let o = ""; for (let i = 0; i < 14; i++) o += ch[hash32(s + i) % ch.length]; return "`" + o + "`"; }
  if (arg === "lorem") return "Lorem ipsum dolor sit amet.";
  return pick(TIPS, s);
}

function socialOp(verb: string, input: RunInput): string {
  const a = input.authorName ? `**${input.authorName}**` : `<@${input.authorId ?? "you"}>`;
  const b = input.targetName ? `**${input.targetName}**` : input.targetId ? `<@${input.targetId}>` : "someone";
  return pick([`${a} ${verb}s ${b}!`, `${a} gives ${b} a heartfelt ${verb}.`, `${a} used **${verb}** on ${b}.`], verb + (input.targetId || "") + (input.authorId || ""));
}

function gambleOp(arg: string): string {
  if (arg === "roulette") { const n = Math.floor(Math.random() * 37); return `Roulette **${n}** (${n === 0 ? "green" : n % 2 ? "red" : "black"})`; }
  if (arg === "bj") return `Hand **${pick(["A","K","Q","J","10"],"a")} ${pick(["A","K","Q","J","10"],"b")}**`;
  if (arg === "poker") return "Poker " + Array.from({ length: 5 }, (_, i) => pick(["A","K","Q","J","10"], "r" + i)).join(" ");
  if (arg === "crash") return `Crash **${(1 + Math.random() * 10).toFixed(2)}x**`;
  if (arg === "lotto") return "Lucky " + Array.from({ length: 6 }, () => 1 + Math.floor(Math.random() * 49)).sort((a, b) => a - b).join(", ");
  if (arg === "wheel") return "Wheel **" + pick(["10 coins", "50 coins", "Jackpot?", "Try again"], String(Math.random())) + "**";
  return `Gamble rolled **${1 + Math.floor(Math.random() * 6)}**`;
}

function templateOp(arg: string, text: string): string {
  const who = text || "@user";
  if (arg === "warn") return `Warning issued to ${who}. Reason: [reason].`;
  if (arg === "kick") return `${who} was removed. Reason: [reason].`;
  if (arg === "ban") return `${who} was banned. Reason: [reason].`;
  if (arg === "timeout") return `${who} is timed out for [duration].`;
  if (arg === "rules") return "1. Be respectful\n2. No spam\n3. Follow Discord ToS\n4. Listen to staff";
  if (arg === "welcometpl") return `Welcome, ${who}! Read the rules.`;
  if (arg === "goodbyetpl") return `Goodbye ${who}.`;
  if (arg === "announcetpl") return `Announcement\n${text || "Details."}`;
  return `Template (${arg}): ${text || "..."}`;
}

function lookupOp(arg: string): string {
  const FACTS = [
    "Octopuses have three hearts and blue blood.",
    "Honey never spoils — edible pots were found in ancient tombs.",
    "A day on Venus is longer than a year on Venus.",
    "Bananas are berries; strawberries are not.",
    "Sharks are older than trees.",
    "A group of flamingos is called a flamboyance.",
    "Wombat poop is cube-shaped.",
    "Otters hold hands while sleeping so they don't drift apart.",
    "A snail can sleep for three years.",
    "Cows have best friends and get stressed when separated.",
    "An adult human is about 60% water.",
    "The Eiffel Tower can be 15 cm taller in summer.",
    "There are more stars in the universe than grains of sand on Earth.",
    "A lightning bolt is five times hotter than the surface of the sun.",
    "Octopuses taste with their arms.",
    "Cats can't taste sweetness.",
    "Dogs can learn over 100 words and gestures.",
    "A blue whale's heart is the size of a small car.",
    "Penguins propose with a pebble.",
    "Elephants are one of the few animals that can't jump.",
    "Sloths can hold their breath longer than dolphins.",
    "A shrimp's heart is in its head.",
    "Butterflies taste with their feet.",
    "Koalas have fingerprints almost identical to humans.",
    "Ravens can plan ahead and use tools.",
    "The heart of a shrimp is located in its head.",
    "Sea otters have the densest fur of any animal.",
    "A group of crows is called a murder.",
    "Hummingbirds are the only birds that can fly backwards.",
    "Polar bear fur is actually clear, not white.",
    "Goldfish can see infrared and ultraviolet light.",
    "A crocodile cannot stick its tongue out.",
    "Snakes smell with their tongues.",
    "The fingerprints of a koala are so similar to humans they can confuse crime scenes.",
    "Goats have rectangular pupils.",
    "A flamingo's pink color comes from its diet.",
    "Starfish can regenerate lost arms.",
    "Some frogs can freeze solid in winter and thaw in spring.",
    "The axolotl can regrow limbs, spinal cord, and parts of its brain.",
    "Bees can recognize human faces.",
    "An ant can lift 50 times its body weight.",
    "Dolphins call each other by unique signature whistles.",
    "Pigeons can do math at a basic level.",
    "Rats laugh when tickled.",
    "A housefly hums in the key of F.",
    "The average cloud weighs about a million pounds.",
    "There is a species of jellyfish that can biologically reverse aging.",
    "Your stomach gets a new lining every few days.",
    "Bones are about 5 times stronger than steel of the same density.",
    "The human nose can detect over a trillion scents.",
    "Cleopatra lived closer in time to the moon landing than to the building of the Great Pyramid.",
    "Oxford University is older than the Aztec Empire.",
    "The shortest war in history lasted 38 to 45 minutes.",
    "A jiffy is an actual unit of time: 1/100th of a second.",
    "The inventor of the frisbee was turned into a frisbee after death (his ashes).",
    "Scotland's national animal is the unicorn.",
    "The hashtag symbol is called an octothorpe.",
    "Nintendo was founded in 1889 as a playing-card company.",
    "The first computer bug was an actual moth stuck in a relay.",
    "Bubble wrap was originally invented as wallpaper.",
    "A bolt of lightning contains enough energy to toast 100,000 slices of bread.",
    "Hot water freezes faster than cold water in some conditions (Mpemba effect).",
    "There are more possible games of chess than atoms in the observable universe.",
    "The word 'queue' is just a Q followed by four silent letters.",
    "Hawaiian pizza was invented in Canada.",
    "The longest English word without a vowel is 'rhythms'.",
    "A 'jiffy' in electronics is the time between alternating current cycles.",
    "The plastic tips on shoelaces are called aglets.",
    "The dot over the letter i is called a tittle.",
    "Armadillos almost always give birth to identical quadruplets.",
    "A group of porcupines is called a prickle.",
    "Male seahorses carry the pregnancy.",
    "Cuttlefish can change color in a fraction of a second.",
    "The pistol shrimp snaps its claw so hard it creates a bubble hotter than the sun's surface for an instant.",
    "Tardigrades can survive the vacuum of space.",
    "The average person walks the equivalent of five times around the world in a lifetime.",
    "Your body produces enough saliva in a lifetime to fill two swimming pools.",
    "The human eye can distinguish about 10 million colors.",
    "Fingernails grow faster than toenails.",
    "You are taller in the morning than in the evening.",
    "The tongue is the strongest muscle relative to its size in the human body.",
    "A sneeze travels about 100 mph.",
    "Humans share about 60% of their DNA with bananas.",
    "There is a species of ant that farms fungus.",
    "Leafcutter ants create the second-most complex societies after humans.",
    "The loudest animal relative to size is the pistol shrimp.",
    "A blue whale can eat up to 4 tons of krill a day.",
    "Cheetahs can accelerate from 0 to 60 mph in about 3 seconds.",
    "The basilisk lizard can run on water.",
    "Archerfish shoot water to knock insects into the water.",
    "Mantis shrimp punch with the acceleration of a bullet.",
    "Some species of bamboo grow up to 91 cm in a single day.",
    "The Amazon rainforest produces about 20% of the world's oxygen.",
    "One teaspoon of honey is the lifetime work of about 12 bees.",
    "A single strand of spider silk is stronger than steel of the same thickness.",
    "The coldest place in the universe that we know of is on Earth, in a lab.",
    "Neutron stars are so dense a teaspoon would weigh billions of tons.",
    "Light from the Sun takes about 8 minutes to reach Earth.",
    "There are more bacteria cells in your body than human cells.",
    "The total weight of all ants on Earth is roughly equal to the total weight of all humans.",
    "A cockroach can live for weeks without its head.",
    "The water in a jellyfish is about 95% of its body.",
    "Coral reefs support about 25% of all marine species.",
  ];
  const PET_FACTS = [
    "Dogs can learn words and hand signals with patient training.",
    "Cats purr at frequencies that may help heal bones and tissue.",
    "Rabbits can see nearly 360 degrees around them.",
    "Hamsters stuff food in cheek pouches to save for later.",
    "A happy dog often has a soft, open mouth and relaxed ears.",
    "Cats knead soft surfaces when they feel safe — a kitten habit.",
    "Guinea pigs communicate with a huge range of squeaks and purrs.",
    "Parrots can live for decades with good care.",
    "Fish recognize their owner's face and routine.",
    "Turtles need UV light to stay healthy indoors.",
    "Regular play prevents boredom-related pet behavior problems.",
    "Fresh water every day matters more than fancy toys.",
    "Pets sleep a lot because growth and recovery happen during rest.",
    "Never feed pets chocolate, grapes, or xylitol — toxic to many animals.",
    "A tired pet is usually a well-exercised pet.",
    "Microchipping is one of the best ways to reunite lost pets.",
    "Slow blinks from a cat are a sign of trust.",
    "Dogs cool down mainly by panting, not sweating.",
    "Some pets prefer routine; sudden changes can stress them.",
    "Grooming is bonding time as well as hygiene.",
    "Young pets need more frequent meals than adults.",
    "Shelter pets often already know basic manners — give them a chance.",
    "Enrichment (puzzles, smells, climbs) keeps indoor pets sharp.",
    "A pet's nose print is as unique as a human fingerprint.",
    "Rabbits should eat mostly hay for healthy teeth and digestion.",
    "Birds hide illness — small changes in appetite are a warning sign.",
    "Positive reinforcement trains faster than punishment.",
    "Senior pets may need softer food and more joint support.",
    "Never leave pets in a hot car — temperatures rise dangerously fast.",
    "Social species (dogs, rats, guinea pigs) need company or lots of attention.",
    "Scratching posts save your furniture and your cat's claws.",
    "A collar with ID is still useful even if the pet is microchipped.",
    "Aquarium water chemistry (ammonia, nitrite) matters more than decorations.",
    "Horses can sleep standing up thanks to a stay apparatus in their legs.",
    "Goats and sheep form ranked social groups.",
    "Ferrets sleep 18+ hours a day and still have energy storms.",
    "Hedgehogs curl into a ball when scared — wait for them to uncurl.",
    "Bearded dragons wave to signal submission.",
    "Snakes shed in one piece when healthy; patchy sheds need humidity help.",
    "Axolotls prefer cool water and soft food.",
    "Octopuses in aquariums are escape artists — lids must be secure.",
    "Dogs dream — watch for twitching paws during REM sleep.",
    "Cats have a specialized collarbone that lets them fit through tiny gaps.",
    "A wagging tail is not always happy — read the whole body.",
    "Pet insurance can save you from impossible choices later.",
    "Vaccines and parasite prevention are part of responsible ownership.",
    "Adoption fees often include first shots and spay/neuter.",
    "Name training: say the name, reward attention — keep sessions short.",
    "Puzzle feeders turn mealtime into a brain game.",
    "Some 'aggressive' pets are actually scared — give space and slow trust.",
    "Rotate toys weekly so they feel new again.",
    "A calm resting place is as important as play space.",
    "Check plants — many common houseplants are toxic to pets.",
    "Carriers should feel safe long before a vet visit.",
    "Weight management prevents joint pain and diabetes in pets.",
    "Brushing teeth (or dental chews) fights painful dental disease.",
    "Listen to your vet more than internet myths.",
    "Rescue groups specialize in rabbits, reptiles, birds — not only dogs/cats.",
    "Bonded pairs of rabbits or guinea pigs should stay together when possible.",
    "Night-time pets (hamsters, some rodents) will be active when you sleep.",
    "Dragons in this bot are fictional — please do not attempt real adoption.",
  ];
  const TIPS = [
    "Prefer clear names over clever ones.",
    "Small reversible steps beat big risky leaps.",
    "Document decisions so future-you understands why.",
    "Defaults matter more than edge-case brilliance.",
    "Measure twice, cut once — then automate the measuring.",
  ];

  if (arg.startsWith("el-")) return `Element **${arg.slice(3)}** — see the periodic table for full data.`;
  if (arg.startsWith("cap-")) return `Capital reference: **${arg.slice(4)}**`;

  const factMatch = arg.match(/^(?:fact|riddle)?(\d+)$/) || arg.match(/^fact(\d+)$/);
  if (arg.startsWith("fact") || /^fact\d+$/.test(arg)) {
    const n = parseInt(arg.replace(/\D/g, ""), 10) || 1;
    return `Fact: ${FACTS[(n - 1) % FACTS.length]}`;
  }
  if (arg.startsWith("pet") || arg.startsWith("petfact")) {
    const n = parseInt(arg.replace(/\D/g, ""), 10) || 1;
    return `Pet fact: ${PET_FACTS[(n - 1) % PET_FACTS.length]}`;
  }
  if (arg.startsWith("riddle")) {
    const riddles = [
      "I speak without a mouth and hear without ears. What am I? (An echo)",
      "The more you take, the more you leave behind. What are they? (Footsteps)",
      "What has cities but no houses, forests but no trees, and water but no fish? (A map)",
      "What gets wetter the more it dries? (A towel)",
      "I have keys but no locks. I have space but no room. What am I? (A keyboard)",
    ];
    const n = parseInt(arg.replace(/\D/g, ""), 10) || 1;
    return riddles[(n - 1) % riddles.length];
  }
  if (arg === "perms") return "Bits: Administrator, Manage Guild, Manage Channels, Kick, Ban, Moderate Members, Manage Messages.";
  if (arg === "modguide") return "Mod tip: warn → timeout → kick → ban. Document reasons. Be consistent.";
  if (arg === "fonts") return "Pairing idea: Fraunces (display) + Outfit (body).";
  if (arg === "bitrate") return "Music: 320 kbps MP3 / 256 AAC is transparent for most ears.";
  if (arg === "codec") return "Video: H.264 for compatibility; AV1/VP9 for efficiency.";
  if (arg === "exif") return "Useful EXIF: DateTimeOriginal, GPS, Model, ExposureTime, FNumber, ISO.";

  // generic codex / tip / econ / util / server / war / crop / media / odds / rule / perm / owner cards
  const n = parseInt(arg.replace(/\D/g, ""), 10) || hash32(arg);
  if (arg.startsWith("econ")) return `Economy tip: ${TIPS[n % TIPS.length]} Track income before lifestyle upgrades.`;
  if (arg.startsWith("util")) return `Utility tip: ${TIPS[n % TIPS.length]}`;
  if (arg.startsWith("server")) return `Server tip: Clear channel topics beat long rule walls.`;
  if (arg.startsWith("war")) return `War tip: Never attack without a retreat plan.`;
  if (arg.startsWith("crop")) return `Farm tip: Water schedule beats random planting.`;
  if (arg.startsWith("media")) return `Media tip: Export masters before heavy compression.`;
  if (arg.startsWith("odds")) return `Odds card: house edge exists — play for fun stakes only.`;
  if (arg.startsWith("rule")) return `Rule template #${n % 50 + 1}: Be respectful; no hate or harassment.`;
  if (arg.startsWith("perm")) return `Permission note: least privilege — only grant what staff need.`;
  if (arg.startsWith("owner")) return `Owner note: keep backups of data/ before risky updates.`;
  if (arg.startsWith("codex")) return `Codex: ${TIPS[n % TIPS.length]} (${arg})`;

  return `📜 ${TIPS[n % TIPS.length]} (${arg})`;
}

function ownerOp(arg: string, text: string): string {
  if (arg === "ping") return "Owner ping: engine alive.";
  if (arg === "mem") { try { return `RSS ${(process.memoryUsage().rss / 1e6).toFixed(1)} MB`; } catch { return "n/a"; } }
  if (arg === "uptime") { try { const s = process.uptime(); return `Uptime **${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m**`; } catch { return "n/a"; } }
  if (arg === "cmds") return "Pack: 1600 commands.";
  if (arg === "echo") return text || "(empty)";
  if (arg === "hash") return "hash:" + hash32(text || "").toString(16);
  if (arg === "env") return `Node ${process.version} · ${process.platform}`;
  return "Owner/" + arg;
}

export function runSpec(spec: Spec, input: RunInput): string {
  const text = input.text ?? "";
  const seed = spec.name + (input.authorId || "") + text;
  try {
    switch (spec.op) {
      case "text": return textOp(spec.arg, text);
      case "dice": return rollDice(spec.arg || text || "1d6");
      case "math": return mathOp(spec.arg, text);
      case "convert": return convertOp(spec.arg, text);
      case "color": return colorOp(spec.arg, text);
      case "time": return timeOp(spec.arg, text);
      case "rng": return rngOp(spec.arg, text, seed);
      case "social": return socialOp(spec.arg || spec.name, input);
      case "gamble": return gambleOp(spec.arg);
      case "template": return templateOp(spec.arg, text);
      case "lookup": return lookupOp(spec.arg);
      case "swatch": { const n = +spec.arg || 1; const hex = ((n * 2654435761) >>> 0).toString(16).slice(0, 6).padStart(6, "0"); return `Swatch #${n}: **#${hex}**`; }
      case "quiz": return lookupOp(spec.arg);
      case "pet": return `Pet **${spec.arg}**: ${text || "name"} — care, train, bond.`;
      case "farm": return `Farm **${spec.arg}**: ${text || "crop"} — plant, water, harvest.`;
      case "war": return `War **${spec.arg}**: ${text || "troop"} — train, form up, report.`;
      case "owner": return ownerOp(spec.arg, text);
      default: return `Command **${spec.name}** (${spec.op}).`;
    }
  } catch (e) {
    return `Error in ${spec.name}: ${e instanceof Error ? e.message : "error"}`;
  }
}
