import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import type { Command, Group, OptionDef } from "../types.js";
import { OptionType } from "../types.js";
import { runSpec, type Spec, type OptionKind } from "./engine.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function loadSpecs(): Spec[] {
  const candidates = [
    path.join(__dirname, "specs.json"),
    path.join(__dirname, "..", "..", "src", "packs", "specs.json"),
    path.join(process.cwd(), "src", "packs", "specs.json"),
    path.join(process.cwd(), "dist", "src", "packs", "specs.json"),
  ];
  for (const p of candidates) {
    if (existsSync(p)) {
      const raw = JSON.parse(readFileSync(p, "utf8")) as Spec[];
      if (raw.length !== 1600) {
        throw new Error(`Expected 1600 pack specs in ${p}, got ${raw.length}`);
      }
      return raw;
    }
  }
  throw new Error(
    `Could not find packs/specs.json. Tried:\n${candidates.map((c) => `  - ${c}`).join("\n")}\n` +
      `Run: npm run build  (copies specs.json into dist)`,
  );
}

const RAW = loadSpecs();

/** 15 user-facing modules. */
export const PACK_CATEGORIES = [
  "economy",
  "gambling",
  "games",
  "fun",
  "social",
  "moderation",
  "utility",
  "server",
  "pets",
  "farm",
  "war",
  "media",
  "community",
  "shop",
  "owner",
] as const;

const CAT_DESC: Record<string, string> = {
  economy: "Balances, work, interest tools, and money math",
  gambling: "Casino sims, odds, and lucky draws",
  games: "Dice, trivia, riddles, and quick plays",
  fun: "Text toys, ciphers, and silly generators",
  social: "Hugs, reactions, and interaction verbs",
  moderation: "Warn/kick templates, rules, and perm cards",
  utility: "Converters, color, time, and everyday tools",
  server: "Welcome, announce, and server setup tips",
  pets: "Pet care facts and companion tools",
  farm: "Crops, soil, and harvest helpers",
  war: "Army, battle, and strategy cards",
  media: "Color swatches, codecs, and creative tips",
  community: "Social ranks, family, and community cards",
  shop: "Shop tips, inventory lore, and trade cards",
  owner: "Owner diagnostics and notes",
};

function optionsFor(kind: OptionKind): OptionDef[] | undefined {
  if (kind === "text") return [{ name: "text", description: "Input text or numbers", type: OptionType.STRING, required: true }];
  if (kind === "int") return [{ name: "amount", description: "Whole number", type: OptionType.INTEGER, required: true }];
  if (kind === "user") return [{ name: "user", description: "Target user", type: OptionType.USER, required: false }];
  return undefined;
}

function toCommand(spec: Spec): Command {
  const ownerOnly = spec.category === "owner";
  return {
    name: spec.name,
    description: spec.description.slice(0, 100),
    options: optionsFor(spec.kind),
    async execute(ctx) {
      if (ownerOnly) {
        const { config } = await import("../config.js");
        if (!config.ownerId || ctx.userId !== config.ownerId) {
          await ctx.reply("Owner-only command.");
          return;
        }
      }
      const text = ctx.str("text") ?? (ctx.int("amount") != null ? String(ctx.int("amount")) : undefined);
      const target = ctx.user("user");
      const out = runSpec(spec, {
        text,
        int: ctx.int("amount"),
        authorId: ctx.userId,
        authorName: ctx.username,
        targetId: target?.id,
        targetName: target?.username,
      });
      await ctx.reply(out.length > 1900 ? out.slice(0, 1890) + "…" : out || "Done.");
    },
  };
}

export function packCommands(): Command[] {
  const seen = new Set<string>();
  const list: Command[] = [];
  for (const spec of RAW) {
    if (seen.has(spec.name)) throw new Error(`Duplicate: ${spec.name}`);
    seen.add(spec.name);
    list.push(toCommand(spec));
  }
  return list;
}

export function packGroups(): Group[] {
  const byCat = new Map<string, Command[]>();
  for (const c of PACK_CATEGORIES) byCat.set(c, []);
  for (const spec of RAW) byCat.get(spec.category)?.push(toCommand(spec));
  return PACK_CATEGORIES.map((name) => ({
    name,
    description: CAT_DESC[name] ?? name,
    guildOnly: name === "moderation" || name === "server",
    subcommands: byCat.get(name) ?? [],
  }));
}

export function packSlashChunks(): Group[] {
  const chunks: Group[] = [];
  const byCat = new Map<string, Spec[]>();
  for (const c of PACK_CATEGORIES) byCat.set(c, []);
  for (const s of RAW) byCat.get(s.category)?.push(s);
  for (const cat of PACK_CATEGORIES) {
    const list = byCat.get(cat) ?? [];
    for (let i = 0; i < list.length; i += 25) {
      const slice = list.slice(i, i + 25);
      const idx = Math.floor(i / 25);
      chunks.push({
        name: idx === 0 ? cat : `${cat}-${idx + 1}`,
        description: (CAT_DESC[cat] ?? cat).slice(0, 100),
        guildOnly: cat === "moderation" || cat === "server",
        subcommands: slice.map(toCommand),
      });
    }
  }
  return chunks;
}
