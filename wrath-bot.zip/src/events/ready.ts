import type { Bot } from "@discordeno/bot";
import { botState } from "../botState.js";
import { config } from "../config.js";
import type { UserLike } from "../utils/users.js";

/** Called once the gateway is ready. Records the bot user — no custom activity/RPC. */
export async function onReady(_bot: Bot, payload: { user?: UserLike }): Promise<void> {
  if (payload.user) {
    botState.user = payload.user;
    console.log(`Logged in as ${payload.user.username}`);
  }

  console.log(`Prefix: ${config.prefix}`);
}
