import type { Bot } from "@discordeno/bot";
import { getAfk, setAfk } from "../db/features.js";
import { mentionedIds, sendPrefixReply, type RawMessage } from "../prefix/context.js";
import { asEmbed } from "../utils/embed.js";
import { avatarUrl } from "../utils/format.js";

/** Clears the sender's AFK status and tells the sender about any AFK players they mention. */
export async function handleAfk(bot: Bot, message: RawMessage): Promise<void> {
  const authorId = String(message.author.id);

  const mine = await getAfk(authorId);
  if (mine) {
    await setAfk(authorId, null);
    await say(bot, message, `Welcome back <@${authorId}>. Your AFK status has been cleared.`);
  }

  for (const id of new Set(mentionedIds(message.content))) {
    if (id === authorId) continue;
    const afk = await getAfk(id);
    if (afk) {
      await say(bot, message, `<@${id}> is AFK: ${afk.reason} (since <t:${Math.floor(afk.since / 1000)}:R>)`);
    }
  }
}

async function say(bot: Bot, message: RawMessage, content: string): Promise<void> {
  const authorId = String(message.author.id);
  const userAvatar = avatarUrl(authorId, message.author.avatar ?? null);
  await sendPrefixReply(
    bot,
    message,
    asEmbed({ content }, { userId: authorId, label: "", username: message.author.username, userAvatar }),
  );
}
