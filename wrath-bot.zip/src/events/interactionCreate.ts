import type { Bot } from "@discordeno/bot";
import { createCtx, type RawInteraction } from "../context.js";
import { registry } from "../registry.js";
import { botAvatar, groupView, homeView, HOME_VALUE, MENU_ID } from "../utils/help.js";

const COMPONENT_INTERACTION = 3;
const UPDATE_MESSAGE_RESPONSE = 7;
const SUB_COMMAND_OPTION = 1;
const DEFERRED_CHANNEL_MESSAGE = 5;
/** Race handlers against a defer timer */
const DEFER_AFTER_MS = 2_000;

/** Routes slash commands and help-menu selections. */
export async function onInteraction(bot: Bot, interaction: RawInteraction): Promise<void> {
  if (interaction.type === COMPONENT_INTERACTION) {
    await onComponent(bot, interaction);
    return;
  }
  if (interaction.data?.name) {
    await onCommand(bot, interaction);
  }
}

/** Handles the help menu's dropdown by editing the same message. */
async function onComponent(bot: Bot, interaction: RawInteraction): Promise<void> {
  const componentData = interaction.data as (RawInteraction["data"] & { custom_id?: string }) | undefined;
  const customId = componentData?.customId ?? componentData?.custom_id;
  if (customId !== MENU_ID) return;

  const choice = componentData?.values?.[0] ?? HOME_VALUE;
  const group = choice === HOME_VALUE ? undefined : registry.get(choice);
  const invoker = interaction.user ?? interaction.member?.user;
  const userId = invoker ? String(invoker.id) : undefined;
  const guildId = interaction.guildId ? String(interaction.guildId) : undefined;
  const isOwner = Boolean(userId && userId === process.env.OWNER_ID);
  const ownerOnlyGroups = ["owner", "owner-mod", "owner-tools"];
  const safeGroup = group && (isOwner || !ownerOnlyGroups.includes(group.name)) ? group : undefined;
  const view = safeGroup ? groupView(safeGroup, userId, 0, botAvatar()) : await homeView(botAvatar(), userId, guildId);

  await bot.helpers.sendInteractionResponse(interaction.id, interaction.token, {
    type: UPDATE_MESSAGE_RESPONSE,
    data: { embeds: view.embeds, components: view.components },
  } as never);
}

/** Routes `/group subcommand` to its handler. */
async function onCommand(bot: Bot, interaction: RawInteraction): Promise<void> {
  const groupName = interaction.data?.name ?? "";
  const group = registry.get(groupName);
  if (!group) return;

  const subOption = interaction.data?.options?.find((o) => o.type === SUB_COMMAND_OPTION);
  if (!subOption) return;

  const command = group.subcommands.find((c) => c.name === subOption.name);
  if (!command) return;

  const label = `${group.name} ${command.name}`;
  const state = { answered: false };
  const ctx = createCtx(bot, interaction, subOption.options ?? [], label, state);

  const deferTimer = setTimeout(() => {
    if (state.answered) return;
    void bot.helpers
      .sendInteractionResponse(interaction.id, interaction.token, {
        type: DEFERRED_CHANNEL_MESSAGE,
        data: {},
      } as never)
      .then(() => {
        // First real reply becomes a follow-up / edit path.
        state.answered = true;
      })
      .catch(() => undefined);
  }, DEFER_AFTER_MS);

  try {
    await command.execute(ctx);
  } catch (error) {
    console.error(`Error in /${label}:`, error);
    await ctx.reply({ content: "❌ Something went wrong running that command.", ephemeral: true }).catch(() => undefined);
  } finally {
    clearTimeout(deferTimer);
  }
}
