import type { Bot } from "@discordeno/bot";
import { getGreeting, getGuardSettings } from "../db/features.js";
import { COLORS } from "../utils/embed.js";
import { renderGreeting } from "../utils/greeting.js";
import { onJoinAntiraid } from "../modules/antiraid.js";
import { logMember } from "../modules/logging.js";
import { runWorkflows } from "../modules/workflows.js";

/** The guild fields the greeting uses. */
export interface GuildLike {
  id: bigint | string;
  name?: string;
  memberCount?: number;
}

async function sendGreeting(
  bot: Bot,
  guild: GuildLike,
  userId: string,
  kind: "welcome" | "goodbye",
): Promise<void> {
  const guildId = String(guild.id);
  const greeting = await getGreeting(guildId, kind);
  if (!greeting) return;

  const text = renderGreeting(greeting.message, {
    userId,
    serverName: guild.name ?? "this server",
    memberCount: guild.memberCount ?? 0,
  });
  await bot.helpers.sendMessage(greeting.channelId, {
    embeds: [{ description: text, color: COLORS.info }],
  } as never);
}

const recentJoins = new Map<string, number[]>();
const alertedWindows = new Map<string, number>();

async function checkJoinSpike(bot: Bot, guild: GuildLike): Promise<void> {
  const guildId = String(guild.id);
  const settings = await getGuardSettings(guildId);
  if (!settings.enabled || !settings.alertChannelId) return;
  const now = Date.now();
  const recent = (recentJoins.get(guildId) ?? []).filter((stamp) => now - stamp <= 10_000);
  recent.push(now);
  recentJoins.set(guildId, recent);
  if (recent.length < 5) return;
  const windowStart = recent[0];
  if ((alertedWindows.get(guildId) ?? 0) >= windowStart) return;
  alertedWindows.set(guildId, now);
  await bot.helpers.sendMessage(settings.alertChannelId, {
    embeds: [{
      title: "🛡️ Wrath Guard · Join spike detected",
      description: `**${recent.length} members** joined within the last 10 seconds.

This is an alert only; Wrath has not automatically punished anyone. Review the member list and use moderation commands if needed.`,
      color: 0xe0a526,
      timestamp: new Date(now).toISOString(),
    }],
  } as never);
}

export async function onMemberAdd(bot: Bot, guild: GuildLike, userId: string): Promise<void> {
  const gid = String(guild.id);
  await onJoinAntiraid(bot, gid, userId, guild.name).catch(console.error);
  await runWorkflows(bot, gid, "member_join", { userId }).catch(console.error);
  await logMember(bot, gid, "Member joined", `<@${userId}> joined **${guild.name ?? gid}**.`).catch(console.error);

  await Promise.all([
    sendGreeting(bot, guild, userId, "welcome").catch(console.error),
    checkJoinSpike(bot, guild).catch(console.error),
  ]);
}

export async function onMemberRemove(bot: Bot, guild: GuildLike, userId: string): Promise<void> {
  const gid = String(guild.id);
  await runWorkflows(bot, gid, "member_leave", { userId }).catch(console.error);
  await logMember(bot, gid, "Member left", `<@${userId}> left **${guild.name ?? gid}**.`).catch(console.error);

  await sendGreeting(bot, guild, userId, "goodbye").catch(console.error);
}
