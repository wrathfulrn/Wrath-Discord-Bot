import type { Bot } from "@discordeno/bot";
import { config } from "../config.js";
import { memberPermissions } from "../discord.js";
import { createPrefixCtx, sendPrefixReply, type RawMessage } from "../prefix/context.js";
import { parseArgs, usageOf } from "../prefix/parse.js";
import { registry } from "../registry.js";
import type { Command, Group } from "../types.js";
import { asEmbed } from "../utils/embed.js";
import { allGroups } from "../utils/help.js";
import { avatarUrl } from "../utils/format.js";
import { handleAfk } from "./afk.js";
import { kv } from "../db/index.js";
import { runAutomod } from "../modules/automod.js";
import { runLevels } from "../modules/levels.js";
import { runAutorespond } from "../modules/autorespond.js";
import { runCounting } from "../modules/counting.js";
import { runWorkflows } from "../modules/workflows.js";
import { hasFakePerm } from "../modules/fakeperms.js";
import { extraConfig } from "../db/guildConfig.js";

type Target =
  | { kind: "command"; group: Group; command: Command; rest: string[] }
  | { kind: "error"; message: string };

/**
 * Handles prefix messages with flat command names, e.g. `,balance`,
 * `,avatar`, or `,pay @friend 100`. The category is not part of the name.
 */
export async function onMessage(bot: Bot, message: RawMessage): Promise<void> {
  if (message.author.bot) return;

  await handleAfk(bot, message).catch(console.error);

  // server modules (non-command message pipeline)
  if (await runCounting(bot, message).catch(() => false)) return;
  if (await runAutomod(bot, message).catch(() => false)) return;
  await runLevels(bot, message).catch(console.error);
  await runAutorespond(bot, message).catch(console.error);
  if (message.guildId && message.channelId) {
    await runWorkflows(bot, String(message.guildId), "message", {
      userId: String(message.author.id),
      content: message.content,
      channelId: String(message.channelId),
    }).catch(console.error);
  }

  const prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  const tokens = message.content.slice(prefix.length).trim().split(/\s+/).filter(Boolean);
  if (tokens.length === 0) return;

  const target = await resolve(tokens, message.guildId ? String(message.guildId) : undefined);

  if (target.kind === "error") {
    // Server-specific custom text commands are stored by the owner command tools.
    if (target.message.startsWith("Unknown command") && message.guildId && message.channelId) {
      const custom = await kv.get<string>(["customCommands", String(message.guildId), tokens[0].toLowerCase()]).catch(() => ({ value: null }));
      if (custom.value) {
        await bot.helpers.sendMessage(String(message.channelId), { content: custom.value.slice(0, 2000) } as never).catch(console.error);
        return;
      }
    }
    await notify(bot, message, `❌ ${target.message}`, "");
    return;
  }

  const label = `${target.group.name} ${target.command.name}`;

  const parsed = parseArgs(target.command, target.rest);
  if (!parsed.ok) {
    const usage = usageOf(prefix, target.command);
    await notify(bot, message, `❌ ${parsed.error}\nUsage: \`${usage}\``, label);
    return;
  }

  const permissions = message.guildId !== undefined
    ? await memberPermissions(
        bot,
        String(message.guildId),
        message.member?.roles ?? [],
        String(message.author.id),
      ).catch(() => 0n)
    : 0n;

  const ctx = createPrefixCtx(bot, message, parsed.values, permissions, label);
  const roleIds = (message.member?.roles ?? []).map(String);
  if (message.guildId && await hasFakePerm(String(message.guildId), roleIds, target.command.name)) {
    ctx.hasPermission = () => true;
  }
  try {
    await target.command.execute(ctx);
  } catch (error) {
    console.error(`Error in ${prefix}${target.command.name}:`, error);
    await notify(bot, message, "❌ Something went wrong running that command.", label);
  }
}

/** Sends a short embed reply for errors and usage hints. */
async function notify(bot: Bot, message: RawMessage, content: string, label: string): Promise<void> {
  const authorId = String(message.author.id);
  const userAvatar = avatarUrl(authorId, message.author.avatar ?? null);
  await sendPrefixReply(
    bot,
    message,
    asEmbed({ content }, { userId: authorId, label, username: message.author.username, userAvatar }),
  );
}

/** Finds the command by its flat name. Names are unique across all groups. */
async function resolve(tokens: string[], guildId?: string): Promise<Target> {
  let name = tokens[0].toLowerCase();
  if (guildId) {
    const map = await extraConfig.getAliases(guildId).catch(() => ({} as Record<string, string>));
    if (map[name]) name = map[name].toLowerCase();
  }

  const matches = allGroups().flatMap((g) =>
    g.subcommands.filter((c) => c.name === name).map((c) => ({ group: g, command: c })),
  );

  if (matches.length === 1) {
    return { kind: "command", group: matches[0].group, command: matches[0].command, rest: tokens.slice(1) };
  }
  if (matches.length > 1) {
    return { kind: "error", message: `\`${name}\` is defined more than once. Check the command names.` };
  }
  return { kind: "error", message: `Unknown command \`${name}\`. Try \`${config.prefix}help\`.` };
}
