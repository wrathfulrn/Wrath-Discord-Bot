import type { Group } from "./types.js";

/** Filled at startup by src/index.ts. Keyed by group name. */
export const registry = new Map<string, Group>();
