export const config = {
  token: process.env.DISCORD_TOKEN ?? "",
  clientId: process.env.CLIENT_ID ?? "",
  guildId: process.env.GUILD_ID || undefined,
  prefix: process.env.PREFIX || ",",
  botName: process.env.BOT_NAME || "Wrath",
  botBio: process.env.BOT_BIO || "Experience the ultimate Discord bot designed for seamless management and community engagement.",
  supportServer: process.env.SUPPORT_URL || undefined,
  /** Discord user ID allowed to run owner-only commands (restart, update). */
  ownerId: process.env.OWNER_ID || "",
  /** Pinterest board that ,pfp pulls pins from. Find it with ,boards. */
  pinterestBoardId: process.env.PINTEREST_BOARD_ID || "",
  /**
   * AI for ,ask — Gemini (Google AI Studio), OpenAI-compatible endpoint.
   * Key: https://aistudio.google.com/apikey
   */
  openaiApiKey: process.env.GEMINI_API_KEY || "",
  /** Base URL without trailing slash. */
  openaiBaseUrl: (process.env.AI_BASE_URL || "https://generativelanguage.googleapis.com/v1beta/openai").replace(/\/$/, ""),
  /** Free-tier default. Override with AI_MODEL. */
  openaiModel: process.env.AI_MODEL || "gemini-2.0-flash",
  openaiSystemPrompt: process.env.OPENAI_SYSTEM_PROMPT || "",
  dbPath: process.env.DB_PATH || "data/wrath.json",

  /** Lavalink (music). Host like `127.0.0.1:2333` or full URL. */
  lavalinkHost: process.env.LAVALINK_HOST || "",
  lavalinkPassword: process.env.LAVALINK_PASSWORD || "youshallnotpass",
  lavalinkSecure: process.env.LAVALINK_SECURE === "1",

  startBalance: 500,
  dailyAmount: 250,
  dailyCooldownMs: 24 * 60 * 60 * 1000,

  workRange: [50, 150] as const,
  workCooldownMs: 60 * 60 * 1000,
  workXp: 5,

  robMinVictimBalance: 100,
  robMaxSteal: 500,
  robFine: 100,

  /** Premium (£5) — display + limits. Payment is manual/Stripe link; bot tracks status in DB. */
  premiumPriceLabel: process.env.PREMIUM_PRICE || "£5/month",
  /** Public checkout / Patreon / Ko-fi / Stripe Payment Link */
  premiumUrl: process.env.PREMIUM_URL || "",
  /** Optional Discord role id: members with this role count as premium */
  premiumRoleId: process.env.PREMIUM_ROLE_ID || "",
  /** Default grant length when owner runs grantpremium without days */
  premiumDays: Number(process.env.PREMIUM_DAYS) || 30,
  /** ,ask limits */
  askCooldownFreeMs: Number(process.env.ASK_COOLDOWN_FREE_MS) || 12_000,
  askCooldownPremiumMs: Number(process.env.ASK_COOLDOWN_PREMIUM_MS) || 3_000,
  askDailyFree: Number(process.env.ASK_DAILY_FREE) || 15,
  askDailyPremium: Number(process.env.ASK_DAILY_PREMIUM) || 200,
  /** Pet slots */
  maxPetsFree: Number(process.env.MAX_PETS_FREE) || 3,
  maxPetsPremium: Number(process.env.MAX_PETS_PREMIUM) || 10,
};

