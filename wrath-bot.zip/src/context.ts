import type { Bot } from "@discordeno/bot";
import type { Ctx, ReplyOptions, ResolvedUser } from "./types.js";
import { asEmbed } from "./utils/embed.js";
import { avatarUrl, snowflakeTime } from "./utils/format.js";
import { hasBit, toResolved, type UserLike } from "./utils/users.js";
import { guildInfo } from "./discord.js";

const EPHEMERAL_FLAG = 64;
const CHANNEL_MESSAGE_RESPONSE = 4;

export interface RawOption {
  name: string;
  type: number;
  value?: unknown;
  options?: RawOption[];
}

/** The parts of an interaction payload this bot reads. */
export interface RawInteraction {
  id: bigint;
  token: string;
  type?: number;
  guildId?: bigint;
  channelId?: bigint;
  user?: UserLike;
  member?: { user?: UserLike; permissions?: string | bigint };
  data?: {
    name?: string;
    options?: RawOption[];
    resolved?: { users?: Record<string, UserLike> };
    /** Discordeno-normalized component custom ID (some raw payload paths retain snake_case). */
    customId?: string;
    custom_id?: string;
    values?: string[];
  };
}

export type ReplyState = { answered: boolean };

/** Builds the Ctx for a slash command. `label` is shown in the reply's footer or title if used. */
export function createCtx(bot: Bot, i: RawInteraction, options: RawOption[] = [], label = "", state: ReplyState = { answered: false }): Ctx {
  const invoker = i.user ?? i.member?.user;
  const self = toResolved(invoker ?? { id: "", username: "unknown" });
  const embedContext = {
    userId: self.id,
    label,
    username: self.username,
    userAvatar: avatarUrl(self.id, self.avatar),
  };

  const valueOf = (name: string): unknown => options.find((o) => o.name === name)?.value;

  const resolveUser = (name: string): ResolvedUser | undefined => {
    const raw = valueOf(name);
    if (raw === undefined) return undefined;
    const id = String(raw);
    const resolved = i.data?.resolved?.users?.[id];
    return resolved ? toResolved({ ...resolved, id }) : { id, username: id, bot: false, avatar: null };
  };

  // The first reply uses the interaction response; after defer or first reply, use follow-ups.
  return {
    bot,
    userId: self.id,
    username: self.username,
    userAvatar: embedContext.userAvatar,
    guildId: i.guildId !== undefined ? String(i.guildId) : undefined,
    channelId: i.channelId !== undefined ? String(i.channelId) : undefined,
    createdAt: snowflakeTime(i.id),

    async reply(input: string | ReplyOptions): Promise<void> {
      const o = asEmbed(input, embedContext);
      const data = {
        content: o.content,
        embeds: o.embeds,
        components: o.components,
        flags: o.ephemeral ? EPHEMERAL_FLAG : undefined,
      };
      if (state.answered) {
        await bot.helpers.sendFollowupMessage(i.token, data as never);
        return;
      }
      state.answered = true;
      await bot.helpers.sendInteractionResponse(i.id, i.token, {
        type: CHANNEL_MESSAGE_RESPONSE,
        data,
      } as never);
    },

    str: (name) => {
      const v = valueOf(name);
      return v === undefined ? undefined : String(v);
    },

    int: (name) => {
      const v = valueOf(name);
      return v === undefined ? undefined : Number(v);
    },

    user: resolveUser,

    userOrSelf: (name) => resolveUser(name) ?? self,

    hasPermission: (bit) => hasBit(BigInt(String(i.member?.permissions ?? "0")), bit),

    guildInfo: () => (i.guildId !== undefined ? guildInfo(bot, String(i.guildId)) : Promise.resolve(null)),
  };
}
