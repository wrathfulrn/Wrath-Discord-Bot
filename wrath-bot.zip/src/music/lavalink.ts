/**
 * Minimal Lavalink v4 REST helpers.
 * Full dual-deck automix needs a forked node; stock Lavalink is single-deck.
 * Voice updates still require the gateway to forward voice server state (see music commands).
 */

import { config } from "../config.js";

export function lavalinkConfigured(): boolean {
  return Boolean(config.lavalinkHost && config.lavalinkPassword);
}

function baseUrl(): string {
  const host = config.lavalinkHost.replace(/\/$/, "");
  if (host.startsWith("http")) return host;
  const secure = config.lavalinkSecure ? "https" : "http";
  return `${secure}://${host}`;
}

export interface LavalinkTrack {
  encoded: string;
  info: {
    identifier: string;
    title: string;
    author: string;
    length: number;
    uri?: string;
    isStream: boolean;
  };
}

export async function loadTracks(query: string): Promise<LavalinkTrack[]> {
  if (!lavalinkConfigured()) return [];
  const isUrl = /^https?:\/\//i.test(query);
  const identifier = isUrl ? query : `ytsearch:${query}`;
  const url = `${baseUrl()}/v4/loadtracks?identifier=${encodeURIComponent(identifier)}`;
  const res = await fetch(url, {
    headers: { Authorization: config.lavalinkPassword },
  });
  if (!res.ok) {
    throw new Error(`Lavalink loadtracks ${res.status}`);
  }
  const data = (await res.json()) as {
    loadType?: string;
    data?: unknown;
  };
  // v4 shapes vary: track / search / playlist
  const lt = data.loadType;
  if (lt === "track" && data.data && typeof data.data === "object" && "encoded" in (data.data as object)) {
    return [data.data as LavalinkTrack];
  }
  if (lt === "search" || lt === "playlist") {
    const d = data.data as { tracks?: LavalinkTrack[] } | LavalinkTrack[] | undefined;
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.tracks)) return d.tracks;
  }
  // Fallback older shape
  const legacy = data as unknown as { tracks?: LavalinkTrack[] };
  return legacy.tracks ?? [];
}
