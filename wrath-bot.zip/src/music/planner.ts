/**
 * Automix "brain" — TypeScript side only, no audio.
 *  * Real dual-deck DSP still needs a forked Lavalink node; this plans transitions and
 * can drive single-deck volume ramps / skip timing when that is all you have.
 */

import type { CamelotKey, QueuedTrack, TransitionPlan, TransitionStrategy, TrackFingerprint } from "./types.js";

const CAMELOT_RING = [
  "1A", "2A", "3A", "4A", "5A", "6A", "7A", "8A", "9A", "10A", "11A", "12A",
] as const;

function camelotDistance(a?: CamelotKey, b?: CamelotKey): number {
  if (!a || !b) return 3; // unknown → neutral-ish
  const num = (k: string) => parseInt(k, 10);
  const mode = (k: string) => k.slice(-1);
  const dNum = Math.min(
    Math.abs(num(a) - num(b)),
    12 - Math.abs(num(a) - num(b)),
  );
  const modePenalty = mode(a) === mode(b) ? 0 : 1;
  return dNum + modePenalty;
}

function tempoScore(a?: number, b?: number): number {
  if (!a || !b) return 0.5;
  const ratios = [1, 0.5, 2];
  let best = 0;
  for (const r of ratios) {
    const diff = Math.abs(a - b * r) / Math.max(a, b * r);
    best = Math.max(best, Math.max(0, 1 - diff * 4));
  }
  return best;
}

function energyScore(a?: number, b?: number): number {
  if (a === undefined || b === undefined) return 0.5;
  return Math.max(0, 1 - Math.abs(a - b));
}

function harmonyScore(a?: CamelotKey, b?: CamelotKey): number {
  const d = camelotDistance(a, b);
  if (d === 0) return 1;
  if (d === 1) return 0.85;
  if (d === 2) return 0.55;
  return 0.2;
}

function structureScore(outT: TrackFingerprint, inT: TrackFingerprint): number {
  const hasOutro = outT.outroStartMs !== undefined;
  const hasIntro = inT.introEndMs !== undefined;
  if (hasOutro && hasIntro) return 0.9;
  if (hasOutro || hasIntro) return 0.65;
  return 0.4;
}

/** Phrase grid: multiples of 8 bars. Assume 4/4 → bar = 4 beats. */
function phraseMs(bpm: number, phrases: number): number {
  const barMs = (60_000 / bpm) * 4;
  return barMs * 8 * phrases;
}

function snapToPhrase(ms: number, bpm: number): number {
  const phrase = phraseMs(bpm, 1);
  if (phrase <= 0) return ms;
  return Math.round(ms / phrase) * phrase;
}

export function scorePair(outgoing: TrackFingerprint, incoming: TrackFingerprint): number {
  const tempo = tempoScore(outgoing.bpm, incoming.bpm);
  const rhythm = tempo; // without onset grid, rhythm ≈ tempo
  const structure = structureScore(outgoing, incoming);
  const harmony = harmonyScore(outgoing.key, incoming.key);
  const energy = energyScore(outgoing.energy, incoming.energy);
  const vocalPenalty =
    outgoing.hasVocals && incoming.hasVocals ? 0.35 : 0.7;
  // Weights from the post: tempo/rhythm/structure 1/5 each, harmony+energy 15%, rest 10%
  return (
    tempo * 0.2 +
    rhythm * 0.2 +
    structure * 0.2 +
    harmony * 0.15 +
    energy * 0.15 +
    vocalPenalty * 0.1
  );
}

export function gainTrimDb(outLufs?: number, inLufs?: number): number {
  if (outLufs === undefined || inLufs === undefined) return 0;
  // Bring incoming toward outgoing level
  const raw = outLufs - inLufs;
  return Math.max(-6, Math.min(6, raw));
}

function pickStrategy(outT: TrackFingerprint, inT: TrackFingerprint, score: number): TransitionStrategy {
  if (score < 0.35) return "hard-cut";
  const tempoClose = tempoScore(outT.bpm, inT.bpm) > 0.85;
  const hasOutro = outT.outroStartMs !== undefined;
  const hasIntro = inT.introEndMs !== undefined;
  const eOut = outT.energy ?? 0.5;
  const eIn = inT.energy ?? 0.5;
  if (hasOutro && hasIntro) return "outro-intro";
  if (tempoClose && hasOutro) return "phrase-blend";
  if (eIn - eOut > 0.25) return "energy-rise";
  if (eOut - eIn > 0.25) return "energy-release";
  if (tempoClose) return "bass-swap";
  return "crossfade";
}

export function planTransition(
  outgoing: TrackFingerprint,
  incoming: TrackFingerprint,
  minScore = 0.45,
): TransitionPlan {
  const score = scorePair(outgoing, incoming);
  if (score < minScore) {
    return {
      strategy: "hard-cut",
      score,
      blendMs: 0,
      gainDb: 0,
      mixOutMs: outgoing.durationMs,
      mixInMs: 0,
      reason: `Score ${score.toFixed(2)} below threshold ${minScore}; plain cut.`,
    };
  }

  const strategy = pickStrategy(outgoing, incoming, score);
  const bpm = outgoing.bpm && incoming.bpm
    ? (outgoing.bpm + incoming.bpm) / 2
    : outgoing.bpm ?? incoming.bpm ?? 120;

  let mixOutMs = outgoing.outroStartMs ?? Math.max(0, outgoing.durationMs - 16_000);
  let mixInMs = incoming.introEndMs ?? 0;
  mixOutMs = snapToPhrase(mixOutMs, bpm);
  mixInMs = snapToPhrase(mixInMs, bpm);

  let blendMs: number;
  switch (strategy) {
    case "bass-swap":
      blendMs = phraseMs(bpm, 0.5) || 4_000;
      blendMs = Math.max(4_000, Math.min(4_000, blendMs));
      break;
    case "phrase-blend":
      blendMs = Math.min(32_000, phraseMs(bpm, 2));
      break;
    case "outro-intro": {
      const outroLen = Math.max(4_000, outgoing.durationMs - mixOutMs);
      blendMs = Math.min(32_000, snapToPhrase(outroLen, bpm));
      break;
    }
    default:
      blendMs = Math.min(32_000, Math.max(4_000, phraseMs(bpm, 1)));
  }

  // Shorten while vocals would overlap > ~4 bars
  if (outgoing.hasVocals && incoming.hasVocals) {
    const fourBars = (60_000 / bpm) * 16;
    while (blendMs > fourBars + 500 && blendMs > 4_000) {
      blendMs = Math.max(4_000, blendMs - phraseMs(bpm, 1));
    }
  }

  return {
    strategy,
    score,
    blendMs: Math.round(blendMs),
    gainDb: gainTrimDb(outgoing.lufs, incoming.lufs),
    mixOutMs: Math.round(mixOutMs),
    mixInMs: Math.round(mixInMs),
    reason: `${strategy} · score ${score.toFixed(2)} · blend ${(blendMs / 1000).toFixed(1)}s · trim ${gainTrimDb(outgoing.lufs, incoming.lufs).toFixed(1)}dB`,
  };
}

/** Lightweight heuristic fingerprint when no real DSP analysis exists yet. */
export function estimateFingerprint(partial: {
  id: string;
  title: string;
  author: string;
  durationMs: number;
  uri?: string;
}): TrackFingerprint {
  // Deterministic pseudo-analysis from id hash so automix can still score pairs.
  let h = 0;
  for (let i = 0; i < partial.id.length; i++) h = (h * 31 + partial.id.charCodeAt(i)) >>> 0;
  const bpm = 90 + (h % 91); // 90–180
  const keys = [
    "1A","2A","3A","4A","5A","6A","7A","8A","9A","10A","11A","12A",
    "1B","2B","3B","4B","5B","6B","7B","8B","9B","10B","11B","12B",
  ] as CamelotKey[];
  const key = keys[h % keys.length];
  const lufs = -14 - ((h >>> 8) % 12); // -14 to -25-ish then shift
  const energy = ((h >>> 16) % 100) / 100;
  const durationMs = partial.durationMs;
  return {
    ...partial,
    bpm,
    key,
    lufs: -8 - ((h >>> 4) % 10), // around -8 to -17
    energy,
    introEndMs: Math.min(durationMs * 0.15, 20_000),
    outroStartMs: Math.max(durationMs * 0.75, durationMs - 24_000),
    hasVocals: (h & 1) === 1,
  };
}
