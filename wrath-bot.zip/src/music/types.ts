/** Track analysis / queue types */

export type CamelotKey =
  | "1A" | "2A" | "3A" | "4A" | "5A" | "6A" | "7A" | "8A" | "9A" | "10A" | "11A" | "12A"
  | "1B" | "2B" | "3B" | "4B" | "5B" | "6B" | "7B" | "8B" | "9B" | "10B" | "11B" | "12B";

export type TransitionStrategy =
  | "crossfade"
  | "outro-intro"
  | "phrase-blend"
  | "bass-swap"
  | "energy-rise"
  | "energy-release"
  | "hard-cut";

export interface TrackFingerprint {
  id: string;
  title: string;
  author: string;
  durationMs: number;
  uri?: string;
  /** Estimated tempo; half/double treated as compatible. */
  bpm?: number;
  key?: CamelotKey;
  /** Integrated loudness LUFS (more negative = quieter). */
  lufs?: number;
  /** 0–1 rough energy. */
  energy?: number;
  introEndMs?: number;
  outroStartMs?: number;
  hasVocals?: boolean;
}

export interface QueuedTrack extends TrackFingerprint {
  requestedBy: string;
}

export interface TransitionPlan {
  strategy: TransitionStrategy;
  score: number;
  blendMs: number;
  /** Gain applied to incoming deck, clamped ±6 dB. */
  gainDb: number;
  mixOutMs: number;
  mixInMs: number;
  reason: string;
}

export interface GuildMusicState {
  guildId: string;
  voiceChannelId?: string;
  textChannelId?: string;
  queue: QueuedTrack[];
  current?: QueuedTrack;
  paused: boolean;
  volume: number;
  automix: boolean;
  /** Minimum pair score (0–1) before automix tries a smart transition. */
  minScore: number;
  lastPlan?: TransitionPlan;
}
