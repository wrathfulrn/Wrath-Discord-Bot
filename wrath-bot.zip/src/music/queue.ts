import type { GuildMusicState, QueuedTrack, TransitionPlan } from "./types.js";
import { planTransition } from "./planner.js";

const guilds = new Map<string, GuildMusicState>();

export function getMusic(guildId: string): GuildMusicState {
  let s = guilds.get(guildId);
  if (!s) {
    s = {
      guildId,
      queue: [],
      paused: false,
      volume: 80,
      automix: false,
      minScore: 0.45,
    };
    guilds.set(guildId, s);
  }
  return s;
}

export function enqueue(guildId: string, track: QueuedTrack): number {
  const s = getMusic(guildId);
  s.queue.push(track);
  return s.queue.length;
}

export function clearQueue(guildId: string): void {
  const s = getMusic(guildId);
  s.queue = [];
  s.current = undefined;
  s.lastPlan = undefined;
}

export function shiftNext(guildId: string): QueuedTrack | undefined {
  const s = getMusic(guildId);
  const next = s.queue.shift();
  if (next) s.current = next;
  else s.current = undefined;
  return next;
}

export function planNext(guildId: string): TransitionPlan | undefined {
  const s = getMusic(guildId);
  if (!s.automix || !s.current || s.queue.length === 0) {
    s.lastPlan = undefined;
    return undefined;
  }
  const plan = planTransition(s.current, s.queue[0], s.minScore);
  s.lastPlan = plan;
  return plan;
}
