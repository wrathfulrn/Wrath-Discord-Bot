import type { Bot } from "@discordeno/bot";
import { extraConfig } from "../db/guildConfig.js";

function emojiKey(emoji: { id?: string | bigint | null; name?: string | null }): string {
  if (emoji.id) return String(emoji.id);
  return emoji.name ?? "";
}

export async function onReactionAdd(
  bot: Bot,
  payload: {
    guildId?: string | bigint;
    channelId?: string | bigint;
    messageId?: string | bigint;
    userId?: string | bigint;
    emoji?: { id?: string | bigint | null; name?: string | null };
  },
): Promise<void> {
  const guildId = payload.guildId ? String(payload.guildId) : "";
  const userId = payload.userId ? String(payload.userId) : "";
  const messageId = payload.messageId ? String(payload.messageId) : "";
  if (!guildId || !userId || !messageId || !payload.emoji) return;

  const list = await extraConfig.getReactionRoles(guildId);
  const key = emojiKey(payload.emoji);
  const hit = list.find((r) => r.messageId === messageId && (r.emoji === key || r.emoji === payload.emoji?.name));
  if (!hit) return;
  await bot.helpers.addRole(guildId, userId, hit.roleId, "Reaction role").catch(() => undefined);
}

export async function onReactionRemove(
  bot: Bot,
  payload: {
    guildId?: string | bigint;
    messageId?: string | bigint;
    userId?: string | bigint;
    emoji?: { id?: string | bigint | null; name?: string | null };
  },
): Promise<void> {
  const guildId = payload.guildId ? String(payload.guildId) : "";
  const userId = payload.userId ? String(payload.userId) : "";
  const messageId = payload.messageId ? String(payload.messageId) : "";
  if (!guildId || !userId || !messageId || !payload.emoji) return;
  const list = await extraConfig.getReactionRoles(guildId);
  const key = emojiKey(payload.emoji);
  const hit = list.find((r) => r.messageId === messageId && (r.emoji === key || r.emoji === payload.emoji?.name));
  if (!hit) return;
  await bot.helpers.removeRole(guildId, userId, hit.roleId, "Reaction role").catch(() => undefined);
}
