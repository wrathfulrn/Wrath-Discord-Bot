import type { Bot } from "@discordeno/bot";
import { extraConfig } from "../db/guildConfig.js";

/** Call on voice state updates. Creates personal channel when joining hub; deletes empty owned channels. */
export async function handleVoiceState(
  bot: Bot,
  payload: {
    guildId?: string | bigint;
    channelId?: string | bigint | null;
    userId?: string | bigint;
    sessionId?: string;
  },
): Promise<void> {
  const guildId = payload.guildId ? String(payload.guildId) : "";
  const userId = payload.userId ? String(payload.userId) : "";
  if (!guildId || !userId) return;

  const cfg = await extraConfig.getVoiceMaster(guildId);
  if (!cfg.enabled || !cfg.hubChannelId) return;

  const joined = payload.channelId ? String(payload.channelId) : null;
  const owned = await extraConfig.getVmOwned(guildId);

  // Left a temp channel — delete if empty
  for (const [chId, owner] of Object.entries(owned)) {
    if (owner !== userId) continue;
    if (joined === chId) continue;
    try {
      // Best-effort: delete channel when owner leaves (Discord may reject if others remain)
      await bot.helpers.deleteChannel(chId, "VoiceMaster: owner left").catch(() => undefined);
      delete owned[chId];
      await extraConfig.setVmOwned(guildId, owned);
    } catch {
      /* ignore */
    }
  }

  // Joined hub — create temp channel and move user
  if (joined && joined === cfg.hubChannelId) {
    const name = cfg.nameTemplate.replace(/\{user\}/gi, userId).slice(0, 100);
    try {
      const ch = await bot.helpers.createChannel(guildId, {
        name: name || "Voice",
        type: 2, // GuildVoice
        parentId: cfg.categoryId,
        permissionOverwrites: [
          { id: userId, type: 1, allow: String((1n << 4n) | (1n << 20n) | (1n << 21n)), deny: "0" },
        ],
      } as never);
      const chId = String((ch as unknown as { id: string | bigint }).id);
      owned[chId] = userId;
      await extraConfig.setVmOwned(guildId, owned);
      await bot.helpers
        .editMember(guildId, userId, { channelId: chId } as never)
        .catch(() => undefined);
    } catch (e) {
      console.error("VoiceMaster create failed:", e);
    }
  }
}
