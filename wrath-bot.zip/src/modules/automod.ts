import type { Bot } from "@discordeno/bot";
import { guildConfig } from "../db/guildConfig.js";
import type { RawMessage } from "../prefix/context.js";

const INVITE_RE = /(discord\.gg|discord\.com\/invite|discordapp\.com\/invite)\/[a-z0-9-]+/i;

export async function runAutomod(bot: Bot, message: RawMessage): Promise<boolean> {
  if (!message.guildId || !message.channelId || message.author.bot) return false;
  const guildId = String(message.guildId);
  const cfg = await guildConfig.getAutomod(guildId);
  if (!cfg.enabled) return false;
  if (cfg.ignoredChannels.includes(String(message.channelId))) return false;

  const content = message.content ?? "";
  let hit = "";
  if (cfg.blockInvites && INVITE_RE.test(content)) hit = "invite link";
  const mentions = (content.match(/<@!?\d+>/g) ?? []).length;
  if (!hit && cfg.maxMentions > 0 && mentions > cfg.maxMentions) hit = `too many mentions (${mentions})`;
  const lines = content.split("\n").length;
  if (!hit && cfg.maxLines > 0 && lines > cfg.maxLines) hit = `too many lines (${lines})`;
  const emojiApprox = (content.match(/<a?:\w+:\d+>/g) ?? []).length + (content.match(/\p{Extended_Pictographic}/gu) ?? []).length;
  if (!hit && cfg.maxEmoji > 0 && emojiApprox > cfg.maxEmoji) hit = `too many emoji (${emojiApprox})`;

  if (!hit) return false;

  try {
    await bot.helpers.deleteMessage(String(message.channelId), String(message.id)).catch(() => undefined);
    if (cfg.punish === "timeout" && message.guildId) {
      const until = new Date(Date.now() + cfg.timeoutSeconds * 1000).toISOString();
      await bot.helpers
        .editMember(guildId, String(message.author.id), { communicationDisabledUntil: until } as never)
        .catch(() => undefined);
    }
    await bot.helpers
      .sendMessage(String(message.channelId), {
        content: `🛡️ Automod removed a message from <@${message.author.id}> (${hit}).`,
      } as never)
      .catch(() => undefined);
  } catch {
    /* ignore */
  }
  return true;
}
