import type { Bot } from "@discordeno/bot";
import { guildConfig } from "../db/guildConfig.js";

const joins = new Map<string, number[]>();

export async function onJoinAntiraid(
  bot: Bot,
  guildId: string,
  userId: string,
  guildName?: string,
): Promise<void> {
  const cfg = await guildConfig.getAntiraid(guildId);
  if (!cfg.enabled) return;
  const now = Date.now();
  const windowMs = cfg.windowSeconds * 1000;
  const list = (joins.get(guildId) ?? []).filter((t) => now - t < windowMs);
  list.push(now);
  joins.set(guildId, list);

  if (list.length < cfg.joinThreshold) return;

  if (cfg.alertChannelId) {
    await bot.helpers
      .sendMessage(cfg.alertChannelId, {
        content: `🚨 **Antiraid:** ${list.length} joins in ${cfg.windowSeconds}s on **${guildName ?? guildId}**. Latest: <@${userId}>`,
      } as never)
      .catch(() => undefined);
  }

  if (cfg.action === "kick") {
    await bot.helpers.kickMember(guildId, userId, { reason: "Antiraid join spike" } as never).catch(() => undefined);
  } else if (cfg.action === "ban") {
    await bot.helpers.banMember(guildId, userId, { reason: "Antiraid join spike" } as never).catch(() => undefined);
  } else if (cfg.action === "timeout") {
    const until = new Date(Date.now() + cfg.timeoutSeconds * 1000).toISOString();
    await bot.helpers
      .editMember(guildId, userId, { communicationDisabledUntil: until } as never)
      .catch(() => undefined);
  }
  joins.set(guildId, []);
}
