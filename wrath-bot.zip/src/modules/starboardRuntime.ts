import type { Bot } from "@discordeno/bot";
import { guildConfig } from "../db/guildConfig.js";
import { kv } from "../db/index.js";

/** Posts to starboard when reaction count hits threshold (best-effort). */
export async function maybeStarboard(
  bot: Bot,
  guildId: string,
  channelId: string,
  messageId: string,
  emojiName: string,
  count: number,
): Promise<void> {
  const cfg = await guildConfig.getStarboard(guildId);
  if (!cfg.enabled || !cfg.channelId) return;
  if (emojiName !== cfg.emoji && emojiName !== "⭐" && emojiName !== "⭐️") return;
  if (count < cfg.minStars) return;

  const postedKey = ["starboard_posted", guildId, messageId] as const;
  const already = await kv.get<boolean>(postedKey as unknown as import("../db/store.js").KvKey);
  if (already.value) return;

  const msg = await bot.helpers.getMessage(channelId, messageId).catch(() => null);
  if (!msg) return;
  const m = msg as {
    content?: string;
    author?: { id?: string | bigint; username?: string };
    embeds?: unknown[];
  };
  await bot.helpers
    .sendMessage(cfg.channelId, {
      embeds: [
        {
          author: { name: m.author?.username ?? "User" },
          description: (m.content || "_No content_").slice(0, 2000),
          color: 0xf1c40f,
          footer: { text: `${count} stars · ${messageId}` },
        },
      ],
    } as never)
    .catch(() => undefined);
  await kv.atomic().set(postedKey as unknown as import("../db/store.js").KvKey, true).commit();
}
