import type { Bot } from "@discordeno/bot";
import { extraConfig, type Workflow } from "../db/guildConfig.js";

export async function runWorkflows(
  bot: Bot,
  guildId: string,
  trigger: Workflow["trigger"],
  ctx: { userId?: string; content?: string; channelId?: string },
): Promise<void> {
  const list = await extraConfig.getWorkflows(guildId);
  for (const w of list) {
    if (!w.enabled || w.trigger !== trigger) continue;
    if (trigger === "message" && w.match) {
      if (!(ctx.content ?? "").toLowerCase().includes(w.match.toLowerCase())) continue;
    }
    try {
      if (w.action === "reply" && ctx.channelId) {
        await bot.helpers.sendMessage(ctx.channelId, {
          content: w.payload.replace(/\{user\}/g, ctx.userId ? `<@${ctx.userId}>` : "").slice(0, 2000),
        } as never);
      } else if (w.action === "dm" && ctx.userId) {
        const dm = await bot.helpers.getDmChannel(ctx.userId).catch(() => null);
        if (dm) {
          await bot.helpers.sendMessage(String((dm as unknown as { id: string | bigint }).id), {
            content: w.payload.slice(0, 2000),
          } as never);
        }
      } else if (w.action === "add_role" && ctx.userId) {
        await bot.helpers.addRole(guildId, ctx.userId, w.payload, "Workflow").catch(() => undefined);
      } else if (w.action === "log" && ctx.channelId) {
        await bot.helpers.sendMessage(ctx.channelId, { content: w.payload.slice(0, 2000) } as never);
      }
    } catch {
      /* continue */
    }
  }
}
