import type { Bot } from "@discordeno/bot";
import { addMessageXp, guildConfig } from "../db/guildConfig.js";
import type { RawMessage } from "../prefix/context.js";

export async function runLevels(bot: Bot, message: RawMessage): Promise<void> {
  if (!message.guildId || message.author.bot) return;
  if (!message.content || message.content.startsWith(",")) return;
  const guildId = String(message.guildId);
  const cfg = await guildConfig.getLevels(guildId);
  if (!cfg.enabled) return;
  const res = await addMessageXp(guildId, String(message.author.id), cfg.xpPerMessage, cfg.cooldownMs);
  if (res?.leveled && cfg.announceChannelId) {
    await bot.helpers
      .sendMessage(cfg.announceChannelId, {
        content: `🎉 <@${message.author.id}> reached **level ${res.level}**!`,
      } as never)
      .catch(() => undefined);
  }
}
