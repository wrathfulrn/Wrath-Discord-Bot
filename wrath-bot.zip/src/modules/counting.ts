import type { Bot } from "@discordeno/bot";
import { guildConfig } from "../db/guildConfig.js";
import type { RawMessage } from "../prefix/context.js";

export async function runCounting(bot: Bot, message: RawMessage): Promise<boolean> {
  if (!message.guildId || !message.channelId || message.author.bot) return false;
  const cfg = await guildConfig.getCounting(String(message.guildId));
  if (!cfg.enabled || !cfg.channelId || cfg.channelId !== String(message.channelId)) return false;

  const n = Number((message.content ?? "").trim());
  if (!Number.isInteger(n)) {
    await bot.helpers.deleteMessage(String(message.channelId), String(message.id)).catch(() => undefined);
    return true;
  }
  if (n !== cfg.next || cfg.lastUserId === String(message.author.id)) {
    await bot.helpers.deleteMessage(String(message.channelId), String(message.id)).catch(() => undefined);
    await bot.helpers
      .sendMessage(String(message.channelId), {
        content: `❌ Count reset! Next number is **1** (wrong number or same user twice).`,
      } as never)
      .catch(() => undefined);
    cfg.next = 1;
    cfg.lastUserId = undefined;
    await guildConfig.setCounting(String(message.guildId), cfg);
    return true;
  }
  cfg.next = n + 1;
  cfg.lastUserId = String(message.author.id);
  await guildConfig.setCounting(String(message.guildId), cfg);
  return true;
}
