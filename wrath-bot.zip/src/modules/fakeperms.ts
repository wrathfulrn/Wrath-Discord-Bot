import { extraConfig } from "../db/guildConfig.js";

/** Returns true if any of the member's roles grants the command via fake perms. */
export async function hasFakePerm(
  guildId: string | undefined,
  roleIds: string[],
  commandName: string,
): Promise<boolean> {
  if (!guildId) return false;
  const list = await extraConfig.getFakePerms(guildId);
  const set = new Set(roleIds);
  for (const fp of list) {
    if (!set.has(fp.roleId)) continue;
    if (fp.commands.map((c) => c.toLowerCase()).includes(commandName.toLowerCase())) return true;
  }
  return false;
}
