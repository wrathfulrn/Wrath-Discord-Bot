import type { Bot } from "@discordeno/bot";
import { guildConfig } from "../db/guildConfig.js";

export async function logMod(
  bot: Bot,
  guildId: string | undefined,
  title: string,
  description: string,
): Promise<void> {
  if (!guildId) return;
  const cfg = await guildConfig.getLog(guildId);
  if (!cfg.enabled || !cfg.channelId || !cfg.mod) return;
  await bot.helpers
    .sendMessage(cfg.channelId, {
      embeds: [{ title, description, color: 0xe74c3c, timestamp: new Date().toISOString() }],
    } as never)
    .catch(() => undefined);
}

export async function logMember(
  bot: Bot,
  guildId: string,
  title: string,
  description: string,
): Promise<void> {
  const cfg = await guildConfig.getLog(guildId);
  if (!cfg.enabled || !cfg.channelId || !cfg.member) return;
  await bot.helpers
    .sendMessage(cfg.channelId, {
      embeds: [{ title, description, color: 0x3498db, timestamp: new Date().toISOString() }],
    } as never)
    .catch(() => undefined);
}
