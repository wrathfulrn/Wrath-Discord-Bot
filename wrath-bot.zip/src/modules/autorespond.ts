import type { Bot } from "@discordeno/bot";
import { guildConfig } from "../db/guildConfig.js";
import type { RawMessage } from "../prefix/context.js";

export async function runAutorespond(bot: Bot, message: RawMessage): Promise<void> {
  if (!message.guildId || !message.channelId || message.author.bot) return;
  const content = (message.content ?? "").trim();
  if (!content || content.startsWith(",")) return;
  const list = await guildConfig.getAutoresponses(String(message.guildId));
  if (!list.length) return;
  const lower = content.toLowerCase();
  for (const rule of list) {
    const t = rule.trigger.toLowerCase();
    const ok = rule.exact ? lower === t : lower.includes(t);
    if (!ok) continue;
    await bot.helpers
      .sendMessage(String(message.channelId), { content: rule.response.slice(0, 2000) } as never)
      .catch(() => undefined);
    return;
  }
}
