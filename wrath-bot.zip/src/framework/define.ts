/**
 * Lightweight command definition helper * Existing Command objects still work; use define() for new commands.
 */
import type { Command, OptionDef, Ctx } from "../types.js";

export type DefineSpec = {
  name: string;
  description: string;
  aliases?: string[];
  options?: OptionDef[];
  /** When true, router will not treat latency as a failure signal (long jobs). */
  slow?: boolean;
  run: (ctx: Ctx) => Promise<void>;
};

export function define(spec: DefineSpec): Command {
  return {
    name: spec.name,
    description: spec.description,
    options: spec.options,
    execute: spec.run,
  };
}
