import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import type { Group } from "./types.js";

/** Discord allows 100 global commands and 25 subcommands per group. */
export const MAX_GROUPS = 100;
export const MAX_SUBCOMMANDS = 25;

/**
 * Loads each command group. A group is a folder under `dir` whose index file
 * default-exports a Group. The other files in that folder are subcommands,
 * imported by the index file rather than loaded directly.
 */
export async function loadGroups(dir: string): Promise<Group[]> {
  const groups: Group[] = [];

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;

    const indexFile = findIndexFile(path.join(dir, entry.name));
    const mod = (await import(pathToFileURL(indexFile).href)) as { default?: Group };
    if (!mod.default) {
      throw new Error(`${indexFile} must default-export a Group.`);
    }
    groups.push(mod.default);
  }

  return groups;
}

function findIndexFile(folder: string): string {
  for (const ext of [".ts", ".js"]) {
    const candidate = path.join(folder, `index${ext}`);
    if (fs.existsSync(candidate)) return candidate;
  }
  throw new Error(`Missing index file in ${folder}`);
}

/** Throws if the groups would be rejected by Discord. */
export function validateGroups(groups: Group[]): void {
  if (groups.length > MAX_GROUPS) {
    throw new Error(`Found ${groups.length} groups; Discord allows ${MAX_GROUPS}.`);
  }

  const groupNames = new Set<string>();
  for (const group of groups) {
    if (groupNames.has(group.name)) {
      throw new Error(`Duplicate group name: ${group.name}`);
    }
    groupNames.add(group.name);

    const count = group.subcommands.length;
    if (count === 0 || count > MAX_SUBCOMMANDS) {
      throw new Error(`${group.name} has ${count} subcommands; it must have 1 to ${MAX_SUBCOMMANDS}.`);
    }

    const subNames = new Set<string>();
    for (const sub of group.subcommands) {
      if (subNames.has(sub.name)) {
        throw new Error(`Duplicate subcommand ${group.name} ${sub.name}`);
      }
      subNames.add(sub.name);
    }
  }
}
