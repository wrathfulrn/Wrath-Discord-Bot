/** Minimal script renderer: {content}, {embed} blocks + variables. */

export type ScriptVars = {
  user?: { id?: string; username?: string; mention?: string };
  guild?: { name?: string; id?: string; count?: number };
  channel?: { name?: string; id?: string };
};

export function renderVars(text: string, vars: ScriptVars): string {
  return text
    .replace(/\{user\.mention\}/gi, vars.user?.mention ?? vars.user?.id ? `<@${vars.user.id}>` : "")
    .replace(/\{user\.name\}/gi, vars.user?.username ?? "")
    .replace(/\{user\.id\}/gi, vars.user?.id ?? "")
    .replace(/\{user\}/gi, vars.user?.username ?? "")
    .replace(/\{guild\.name\}/gi, vars.guild?.name ?? "")
    .replace(/\{guild\.id\}/gi, vars.guild?.id ?? "")
    .replace(/\{guild\.count\}/gi, String(vars.guild?.count ?? ""))
    .replace(/\{channel\.name\}/gi, vars.channel?.name ?? "")
    .replace(/\{channel\.id\}/gi, vars.channel?.id ?? "");
}

export function parseScript(
  raw: string,
  vars: ScriptVars,
): { content?: string; embeds: Record<string, unknown>[] } {
  const text = renderVars(raw, vars);
  const embeds: Record<string, unknown>[] = [];
  let content: string | undefined;

  const contentMatch = text.match(/\{content:\s*([^}]*)\}/i);
  if (contentMatch) content = contentMatch[1].trim();

  // Simple single embed: {embed} ... {title:} {description:} {color:}
  if (/\{embed\}/i.test(text) || /\{title:/i.test(text)) {
    const title = text.match(/\{title:\s*([^}]*)\}/i)?.[1]?.trim();
    const description = text.match(/\{description:\s*([^}]*)\}/i)?.[1]?.trim();
    const colorRaw = text.match(/\{color:\s*([^}]*)\}/i)?.[1]?.trim();
    let color = 0x5865f2;
    if (colorRaw) {
      const hex = colorRaw.replace("#", "");
      const n = parseInt(hex, 16);
      if (!Number.isNaN(n)) color = n;
    }
    const footer = text.match(/\{footer:\s*([^}]*)\}/i)?.[1]?.trim();
    const embed: Record<string, unknown> = { color };
    if (title) embed.title = title;
    if (description) embed.description = description;
    if (footer) embed.footer = { text: footer };
    embeds.push(embed);
  }

  if (!content && embeds.length === 0) {
    content = text.slice(0, 2000);
  }
  return { content, embeds };
}
