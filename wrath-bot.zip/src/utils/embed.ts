import type { ReplyOptions } from "../types.js";

/** Wrath's reply palette. The side bar colour shows the kind of reply. */
export const COLORS = {
  info: 0x8b5cf6, // Wrath violet
  warning: 0xf5b942, // warm gold
  error: 0xc0392b, // red
} as const;

export const ERROR_ICON = "❌";
export const WARNING_ICON = "⚠️";

export interface EmbedContext {
  /** The invoking user's ID, used for the mention. */
  userId?: string;
  /** Kept for callers that pass it. The compact layout doesn't show a title. */
  label: string;
  username: string;
  userAvatar: string;
}

/**
 * Every text reply is shown as a compact embed: an icon for errors and
 * warnings, the user's mention, then the message. The colour bar shows the
 * kind of reply. Replies that already carry embeds or components keep them.
 */
export function asEmbed(input: string | ReplyOptions, ctx: EmbedContext): ReplyOptions {
  const o: ReplyOptions = typeof input === "string" ? { content: input } : input;
  if ((o.embeds && o.embeds.length) || o.content === undefined) return o;

  let tone: keyof typeof COLORS = "info";
  let icon = "";
  let text = o.content;

  if (text.startsWith(ERROR_ICON)) {
    tone = "error";
    icon = ERROR_ICON;
    text = text.slice(ERROR_ICON.length).trimStart();
  } else if (text.startsWith(WARNING_ICON)) {
    tone = "warning";
    icon = WARNING_ICON;
    text = text.slice(WARNING_ICON.length).trimStart();
  }

  const who = ctx.userId ? `<@${ctx.userId}>: ` : "";
  const lead = icon ? `${icon} ` : "";

  return {
    embeds: [{
      description: `${lead}${who}${text}`,
      color: COLORS[tone],
    }],
    components: o.components,
    ephemeral: o.ephemeral,
  };
}
