import { config } from "../config.js";

export type AskResult =
  | { ok: true; text: string }
  | { ok: false; error: string };

const lastAskAt = new Map<string, number>();
const inFlight = new Set<string>();
let chain: Promise<unknown> = Promise.resolve();
let globalLastCall = 0;

function cooldownMs(): number {
  const n = Number(process.env.OPENAI_COOLDOWN_MS);
  return Number.isFinite(n) && n >= 0 ? n : 12_000;
}

function minGapMs(): number {
  const n = Number(process.env.OPENAI_MIN_GAP_MS);
  return Number.isFinite(n) && n >= 0 ? n : 1_500;
}

function maxRetries(): number {
  const n = Number(process.env.OPENAI_MAX_RETRIES);
  return Number.isFinite(n) && n >= 0 ? Math.min(5, n) : 3;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

export function checkAskGate(userId: string): { ok: false; error: string } | null {
  if (inFlight.has(userId)) {
    return { ok: false, error: "I'm already answering your last question. Wait for it to finish." };
  }
  const last = lastAskAt.get(userId) ?? 0;
  const wait = cooldownMs() - (Date.now() - last);
  if (wait > 0) {
    return { ok: false, error: `Slow down — you can ask again in **${Math.ceil(wait / 1000)}s**.` };
  }
  return null;
}

export function markAskStart(userId: string): void {
  inFlight.add(userId);
  lastAskAt.set(userId, Date.now());
}

export function markAskEnd(userId: string): void {
  inFlight.delete(userId);
}

const RETIRED_MODELS = new Set([
  "schizogpt",
  "gpt-4o",
  "gpt-4o-mini",
  "gpt-5",
  "openrouter/free",
]);

/** Prefer lighter / more available free models; 3.x flash often returns 503 under load. */
const DEFAULT_MODEL = "gemini-2.0-flash";
const FALLBACKS = [
  "gemini-2.0-flash",
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  "gemini-1.5-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.6-flash",
  "gemini-3.8-flash",
];

function resolveModel(raw: string | undefined): string {
  const model = (raw || "").trim();
  if (!model || RETIRED_MODELS.has(model) || model.includes("/")) return DEFAULT_MODEL;
  return model;
}

function modelChain(primary: string): string[] {
  const ordered = [primary, ...FALLBACKS.filter((m) => m !== primary)];
  return [...new Set(ordered)];
}

/**
 * Gemini via OpenAI-compatible endpoint.
 * Retries 429/503 and walks free-tier fallback models when one is overloaded.
 */
export async function askOpenAI(prompt: string, userLabel?: string): Promise<AskResult> {
  const key = config.openaiApiKey?.trim();
  if (!key) {
    return {
      ok: false,
      error:
        "AI is not configured. Set **GEMINI_API_KEY** in `.env` (free key from https://aistudio.google.com/apikey).",
    };
  }

  const base = config.openaiBaseUrl || "https://generativelanguage.googleapis.com/v1beta/openai";
  const models = modelChain(resolveModel(config.openaiModel));
  const system =
    config.openaiSystemPrompt ||
    `You are ${config.botName || "Wrath"}, a helpful Discord bot assistant. Keep answers clear and under 1800 characters unless the user asks for detail.`;
  const endpoint = `${base}/chat/completions`;

  const run = async (): Promise<AskResult> => {
    const gap = minGapMs() - (Date.now() - globalLastCall);
    if (gap > 0) await sleep(gap);
    globalLastCall = Date.now();

    let lastError = "AI request failed.";
    for (const model of models) {
      const retries = maxRetries();
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          const res = await fetch(endpoint, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${key}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model,
              messages: [
                { role: "system", content: system },
                {
                  role: "user",
                  content: userLabel ? `[${userLabel}] ${prompt}` : prompt,
                },
              ],
              max_tokens: 500,
              temperature: 0.7,
              stream: false,
            }),
          });

          // Capacity / rate limits — backoff then try again or next model
          if (res.status === 429 || res.status === 503) {
            const retryAfterHdr = res.headers.get("retry-after");
            const retryAfterMs = retryAfterHdr
              ? Math.min(60_000, Math.max(1_000, Number(retryAfterHdr) * 1000 || 5_000))
              : Math.min(20_000, 800 * 2 ** attempt + Math.floor(Math.random() * 400));
            const body = await res.text().catch(() => "");
            if (attempt < retries) {
              await sleep(retryAfterMs);
              globalLastCall = Date.now();
              continue;
            }
            lastError =
              res.status === 503
                ? `Gemini is overloaded (503) on \`${model}\`. Trying another free model…`
                : `Gemini rate limit (429). Wait ~${Math.ceil(retryAfterMs / 1000)}s. ${body.slice(0, 80)}`;
            break; // next model
          }

          if (!res.ok) {
            const errBody = await res.text().catch(() => "");
            if (res.status === 401 || res.status === 403) {
              return {
                ok: false,
                error: `Gemini rejected the API key (${res.status}). Check GEMINI_API_KEY at https://aistudio.google.com/apikey`,
              };
            }
            // Unknown model → try next fallback
            if (res.status === 400 || res.status === 404) {
              lastError = `Model \`${model}\` unavailable. ${errBody.slice(0, 120)}`;
              break;
            }
            return { ok: false, error: `AI error ${res.status}: ${errBody.slice(0, 180)}` };
          }

          const data = (await res.json()) as {
            choices?: { message?: { content?: string } }[];
          };
          const text = data.choices?.[0]?.message?.content?.trim();
          if (!text) {
            lastError = "AI returned an empty reply.";
            break;
          }
          return { ok: true, text: text.slice(0, 1900) };
        } catch (e) {
          if (attempt < retries) {
            await sleep(1000 * (attempt + 1));
            continue;
          }
          lastError = `Could not reach Gemini: ${e instanceof Error ? e.message : "network error"}`;
        }
      }
    }
    return {
      ok: false,
      error:
        lastError.includes("503") || lastError.includes("overloaded")
          ? "All Gemini free models are overloaded right now. Try again in a minute, or set `AI_MODEL=gemini-2.0-flash` in `.env`."
          : lastError,
    };
  };

  const next = chain.then(run, run);
  chain = next.then(
    () => undefined,
    () => undefined,
  );
  return next;
}
