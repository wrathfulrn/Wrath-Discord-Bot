import type { ResolvedUser } from "../types.js";

/** A user as Discordeno reports it. Only the fields this bot reads are listed. */
export interface UserLike {
  id: bigint | string;
  username: string;
  bot?: boolean;
  avatar?: string | null;
}

export function toResolved(user: UserLike): ResolvedUser {
  return {
    id: String(user.id),
    username: user.username,
    bot: user.bot ?? false,
    avatar: user.avatar ?? null,
  };
}

/** True if `perms` includes `bit`, or includes Administrator. */
export function hasBit(perms: bigint, bit: bigint): boolean {
  const ADMINISTRATOR = 1n << 3n;
  return (perms & ADMINISTRATOR) === ADMINISTRATOR || (perms & bit) === bit;
}
