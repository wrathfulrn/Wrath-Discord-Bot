/**
 * REST retries for transient Discord failures * Retries 429, 500, 502, 504, 524. Does not retry 503 (genuine unavailability).
 */

const RETRY_STATUSES = new Set([429, 500, 502, 504, 524]);

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

function statusOf(err: unknown): number | null {
  if (!err || typeof err !== "object") return null;
  const e = err as { status?: number; statusCode?: number; code?: number; response?: { status?: number } };
  return e.status ?? e.statusCode ?? e.response?.status ?? (typeof e.code === "number" && e.code >= 400 ? e.code : null);
}

export async function withRetries<T>(
  label: string,
  fn: () => Promise<T>,
  attempts = 3,
): Promise<T> {
  let last: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (err) {
      last = err;
      const status = statusOf(err);
      if (status === null || !RETRY_STATUSES.has(status) || i === attempts - 1) throw err;
      const backoff = status === 429
        ? Math.min(15_000, 1000 * 2 ** i)
        : Math.min(8_000, 400 * 2 ** i);
      console.warn(`[rest] ${label} ${status}, retry ${i + 1}/${attempts - 1} in ${backoff}ms`);
      await sleep(backoff);
    }
  }
  throw last;
}
