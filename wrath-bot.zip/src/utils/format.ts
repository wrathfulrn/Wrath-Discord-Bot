import type { ReplyOptions } from "../types.js";
import { WARNING_ICON } from "./embed.js";

const DISCORD_EPOCH = 1420070400000n;

/** Creation time of any Discord snowflake, in ms since epoch. */
export function snowflakeTime(id: bigint | string): number {
  return Number((BigInt(id) >> 22n) + DISCORD_EPOCH);
}

/** Discord's date-only timestamp tag, rendered in each viewer's locale. */
export function discordDate(ms: number): string {
  return `<t:${Math.floor(ms / 1000)}:D>`;
}

export function avatarUrl(userId: string, avatar: unknown): string {
  // Discordeno versions/transforms may expose an avatar as a hash string or
  // as an object. Normalize it before using string methods.
  let hash: string | undefined;

  if (typeof avatar === "string" && avatar.length > 0) {
    if (avatar.startsWith("https://") || avatar.startsWith("http://")) {
      return avatar;
    }
    hash = avatar;
  } else if (avatar && typeof avatar === "object") {
    const value = avatar as { url?: unknown; id?: unknown; hash?: unknown; key?: unknown };
    if (typeof value.url === "string" && value.url.length > 0) return value.url;
    if (typeof value.hash === "string") hash = value.hash;
    else if (typeof value.id === "string") hash = value.id;
    else if (typeof value.key === "string") hash = value.key;
  }

  if (hash) {
    const ext = hash.startsWith("a_") ? "gif" : "png";
    return `https://cdn.discordapp.com/avatars/${userId}/${hash}.${ext}?size=1024`;
  }

  const fallback = Number((BigInt(userId) >> 22n) % 6n);
  return `https://cdn.discordapp.com/embed/avatars/${fallback}.png`;
}

/** Formats milliseconds as e.g. "1h 4m 9s". */
export function fmtDuration(ms: number): string {
  const total = Math.ceil(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h) return `${h}h ${m}m ${s}s`;
  if (m) return `${m}m ${s}s`;
  return `${s}s`;
}

export function coins(amount: number): string {
  return `🪙 ${amount.toLocaleString("en-GB")}`;
}

/** Milliseconds left on a cooldown that started at `last`. */
export function cooldownLeft(last: number, cooldownMs: number): number {
  return Math.max(0, last + cooldownMs - Date.now());
}

/** A reply only the command user can see. */
export function privateError(message: string): ReplyOptions {
  return { content: `❌ ${message}`, ephemeral: true };
}

/** The standard cooldown reply, e.g. "⚠️ This command is on cooldown. Try again in 1m 0s." */
export function cooldownNotice(waitMs: number): string {
  return `${WARNING_ICON} This command is on cooldown. Try again in ${fmtDuration(waitMs)}.`;
}
