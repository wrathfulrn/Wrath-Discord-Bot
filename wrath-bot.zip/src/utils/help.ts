import { botState } from "../botState.js";
import { avatarUrl } from "./format.js";
import { config } from "../config.js";
import { kv } from "../db/index.js";
import { registry } from "../registry.js";
import { OptionType, type Command, type Group, type ReplyOptions } from "../types.js";
import { usageOf } from "../prefix/parse.js";

export const MENU_ID = "help:menu";
export const HOME_VALUE = "home";

const INDEX_COLOR = 0x6c5ce7;
/** How many command chips per category page (dense). */
const PAGE_SIZE = 120;
const MAX_MODULES_IN_MENU = 24;

const CATEGORY_EMOJI: Record<string, string> = {
  economy: "💰",
  gambling: "🎰",
  games: "🎲",
  fun: "🎉",
  social: "🤝",
  moderation: "🛡️",
  shop: "🛒",
  jobs: "💼",
  pets: "🐾",
  farm: "🌾",
  crafting: "⚒️",
  lottery: "🎟️",
  war: "⚔️",
  server: "🏠",
  community: "💞",
  owner: "👑",
  utility: "🧰",
  tools: "🔧",
  pinterest: "📌",
  media: "🎨",
};

function emojiFor(name: string): string {
  return CATEGORY_EMOJI[name] ?? "📁";
}

/** Title-case a category id for display (economy → Economy). */
function prettyName(name: string): string {
  return name
    .split(/[-_\s]+/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}

export function allGroups(): Group[] {
  return [...registry.values()].sort((a, b) => a.name.localeCompare(b.name));
}

export function visibleGroups(userId?: string): Group[] {
  const groups = allGroups();
  if (userId && config.ownerId && userId === config.ownerId) return groups;
  return groups.filter((g) => !["owner", "owner-mod", "owner-tools"].includes(g.name));
}

export async function customCommandNames(guildId?: string): Promise<string[]> {
  if (!guildId) return [];
  const names: string[] = [];
  for await (const entry of kv.list<string>({ prefix: ["customCommands", guildId] })) {
    if (entry.value) names.push(String(entry.key[2]));
  }
  return names.sort((a, b) => a.localeCompare(b));
}

export function botAvatar(): string | null {
  const user = botState.user;
  return user ? avatarUrl(String(user.id), user.avatar ?? null) : null;
}

function botLabel(): string {
  return (config.botName || "Wrath").toLowerCase();
}

function tagline(): string {
  return (
    config.botBio ||
    "Experience the ultimate Discord bot designed for seamless management and community engagement."
  );
}

/**
 * home: title, tagline, Prefix / Commands / Modules, Home select.
 */
export async function homeView(thumb?: string | null, userId?: string, _guildId?: string): Promise<ReplyOptions> {
  const groups = visibleGroups(userId);
  const total = groups.reduce((n, g) => n + g.subcommands.length, 0);
  const modules = groups.length;

  return {
    embeds: [
      {
        title: `${botLabel()} help`,
        description: tagline(),
        color: INDEX_COLOR,
        thumbnail: thumb ? { url: thumb } : undefined,
        fields: [
          {
            name: "\u200b",
            value: [
              `> **Prefix** \`${config.prefix}\``,
              `> **Commands** \`${total.toLocaleString("en-US")}\``,
              `> **Modules** \`${modules}\``,
            ].join("\n"),
            inline: false,
          },
        ],
        footer: {
          text: `Use ${config.prefix}help (command) for details on a specific command`,
        },
      },
    ],
    components: menu(HOME_VALUE, userId),
  };
}

/**
 * category page:
 *  - same "{bot} help" header + tagline + thumbnail
 *  - section: 🏠 **General**
 *  - commands as tight inline-code pills: `bug` `echo` `ping`
 *  - select defaults to this category
 */
export function groupView(group: Group, userId?: string, page = 0, thumb?: string | null): ReplyOptions {
  const names = group.subcommands.map((s) => s.name).sort((a, b) => a.localeCompare(b));
  const pages = Math.max(1, Math.ceil(names.length / PAGE_SIZE));
  const safe = ((page % pages) + pages) % pages;
  const slice = names.slice(safe * PAGE_SIZE, safe * PAGE_SIZE + PAGE_SIZE);

  // Discord renders `name` as gray pills — pack them tightly with single spaces.
  const pills = slice.map((n) => `\`${n}\``).join(" ");

  const heading = `${emojiFor(group.name)} **${prettyName(group.name)}**`;
  const pageNote = pages > 1 ? `\n-# page ${safe + 1}/${pages}` : "";

  const description = [
    tagline(),
    "",
    heading,
    pills,
    pageNote,
  ]
    .filter((line, i, arr) => !(line === "" && arr[i - 1] === ""))
    .join("\n")
    .slice(0, 4090);

  return {
    embeds: [
      {
        title: `${botLabel()} help`,
        description,
        color: INDEX_COLOR,
        thumbnail: thumb ? { url: thumb } : botAvatar() ? { url: botAvatar()! } : undefined,
        footer: {
          text: `Use ${config.prefix}help (command) for details on a specific command`,
        },
      },
    ],
    components: menu(group.name, userId),
  };
}

export function commandView(
  name: string,
  userId?: string,
  invoker?: { username?: string; avatarUrl?: string },
): ReplyOptions | null {
  const match = visibleGroups(userId)
    .flatMap((g) =>
      g.subcommands
        .filter((c) => c.name === name.toLowerCase())
        .map((c) => ({ group: g, command: c })),
    )[0];
  if (!match) return null;

  const { group, command } = match;
  const options = command.options ?? [];

  // Parameters line — option names, compact style (no backticks required on each)
  const parameters =
    options.length === 0
      ? "n/a"
      : options.map((o) => o.name).join(", ");

  // Syntax: ,echo (text) (optional?)
  const syntaxParts = options.map((o) => (o.required ? `(${o.name})` : `[${o.name}]`));
  const syntax = `${config.prefix}${command.name}${syntaxParts.length ? " " + syntaxParts.join(" ") : ""}`;
  const example = exampleOf(command);

  // Author line const authorName = invoker?.username ?? "User";

  const description = [
    // quote-style description
    `> ${command.description}`,
    "",
    "**Aliases**",
    "n/a",
    "**Parameters**",
    parameters,
    "**Information**",
    `${emojiFor(group.name)} ${prettyName(group.name)}`,
    "**Usage**",
    "```",
    `Syntax: ${syntax}`,
    `Example: ${example}`,
    "```",
  ].join("\n");

  return {
    embeds: [
      {
        author: {
          name: authorName,
          icon_url: invoker?.avatarUrl || undefined,
        },
        title: command.name,
        description: description.slice(0, 4090),
        color: INDEX_COLOR,
      },
    ],
  };
}

function exampleOf(cmd: Command): string {
  const parts = (cmd.options ?? []).map((o) => {
    if (o.choices && o.choices.length > 0) return o.choices[0].value;
    if (o.type === OptionType.USER) return "@user";
    if (o.type === OptionType.INTEGER) return String(o.min_value ?? 1);
    return o.name;
  });
  return [`${config.prefix}${cmd.name}`, ...parts].join(" ");
}

/** Dropdown: Home + categories with emoji (labels). */
function menu(selected: string, userId?: string): Record<string, unknown>[] {
  const categories = visibleGroups(userId)
    .slice(0, MAX_MODULES_IN_MENU)
    .map((g) => ({
      label: prettyName(g.name).slice(0, 100),
      value: g.name,
      description: g.description.slice(0, 100),
      emoji: { name: emojiFor(g.name) },
      default: g.name === selected,
    }));

  const options = [
    {
      label: "Home",
      value: HOME_VALUE,
      description: "Help overview",
      emoji: { name: "🏠" },
      default: selected === HOME_VALUE,
    },
    ...categories,
  ];

  return [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: MENU_ID,
          placeholder: selected === HOME_VALUE ? "Home" : prettyName(selected),
          options,
        },
      ],
    },
  ];
}
