export interface GreetingVars {
  userId: string;
  serverName: string;
  memberCount: number;
}

/** Fills in {user}, {server}, and {count} in a welcome or goodbye message. */
export function renderGreeting(template: string, vars: GreetingVars): string {
  return template
    .replaceAll("{user}", `<@${vars.userId}>`)
    .replaceAll("{server}", vars.serverName)
    .replaceAll("{count}", String(vars.memberCount));
}
