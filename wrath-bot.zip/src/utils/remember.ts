/**
 * Single-flight memory cache * Concurrent misses for the same key share one producer call.
 * Clears the inflight entry on failure so a bad result cannot poison the key.
 */

const inflight = new Map<string, Promise<unknown>>();
const store = new Map<string, { expires: number; value: unknown }>();

export async function remember<T>(
  key: string,
  ttlSeconds: number,
  producer: () => Promise<T>,
): Promise<T> {
  const now = Date.now();
  const hit = store.get(key);
  if (hit && hit.expires > now) return hit.value as T;

  const pending = inflight.get(key);
  if (pending) return pending as Promise<T>;

  const run = (async () => {
    const value = await producer();
    store.set(key, { expires: Date.now() + ttlSeconds * 1000, value });
    return value;
  })().finally(() => {
    inflight.delete(key);
  });

  inflight.set(key, run);
  return run;
}

export function rememberInvalidate(prefix: string): void {
  for (const key of store.keys()) {
    if (key === prefix || key.startsWith(prefix + ":")) store.delete(key);
  }
}
