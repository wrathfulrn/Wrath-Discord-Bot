import type { Bot } from "@discordeno/bot";
import { remember } from "./utils/remember.js";
import { withRetries } from "./utils/rest.js";

/*
 * Every Discord API call the bot makes lives here. Discordeno has no cache,
 * so anything the bot needs is fetched through these helpers.
 *
 * The helper names and parameters below follow Discordeno's documented
 * bot.helpers API. Check them against your installed version if the TypeScript
 * build reports an error on one of these lines.
 */

export async function kick(bot: Bot, guildId: string, userId: string, reason: string): Promise<void> {
  await withRetries(`kick:${guildId}`, () => bot.helpers.kickMember(guildId, userId, { reason } as never));
}

export async function ban(bot: Bot, guildId: string, userId: string, reason: string): Promise<void> {
  await withRetries(`ban:${guildId}`, () => bot.helpers.banMember(guildId, userId, { reason } as never));
}

/**
 * Deletes up to `count` recent messages in a channel.
 * - 1 message → single delete
 * - 2–100 → bulk delete (Discord only allows messages younger than 14 days in bulk)
 * Returns how many messages were actually deleted.
 */
export async function purge(bot: Bot, channelId: string, count: number): Promise<number> {
  const limit = Math.max(1, Math.min(100, Math.floor(count)));
  const raw = await bot.helpers.getMessages(channelId, { limit } as never);

  // Discordeno may return an array, Collection, or Map depending on version.
  // Cast through unknown to satisfy TS2352 with Discordeno's desired-props types.
  type MsgLike = { id: string | bigint; timestamp?: number };
  const list: MsgLike[] = (() => {
    if (!raw) return [];
    const anyRaw = raw as unknown;
    if (Array.isArray(anyRaw)) return anyRaw as MsgLike[];
    if (anyRaw && typeof anyRaw === "object" && typeof (anyRaw as { values?: unknown }).values === "function") {
      return [...(anyRaw as { values: () => Iterable<MsgLike> }).values()];
    }
    if (anyRaw && typeof anyRaw === "object") {
      return Object.values(anyRaw as Record<string, MsgLike>);
    }
    return [];
  })();

  if (list.length === 0) return 0;

  const TWO_WEEKS_MS = 14 * 24 * 60 * 60 * 1000;
  const cutoff = Date.now() - TWO_WEEKS_MS;

  // Prefer bulk-eligible messages; fall back to single deletes for older ones.
  const youngIds: string[] = [];
  const oldIds: string[] = [];
  for (const m of list) {
    const id = String(m.id);
    // Snowflake timestamp: (id >> 22) + 1420070400000
    const created = Number((BigInt(id) >> 22n) + 1420070400000n);
    if (created >= cutoff) youngIds.push(id);
    else oldIds.push(id);
  }

  let deleted = 0;

  // Bulk delete in chunks of 100 (API max); requires at least 2 ids.
  for (let i = 0; i < youngIds.length; ) {
    const chunk = youngIds.slice(i, i + 100);
    i += chunk.length;
    if (chunk.length >= 2) {
      await bot.helpers.deleteMessages(channelId, chunk as never);
      deleted += chunk.length;
    } else if (chunk.length === 1) {
      await bot.helpers.deleteMessage(channelId, chunk[0] as never).catch(() => undefined);
      deleted += 1;
    }
  }

  // Older messages must be deleted one-by-one (slower; cap to avoid rate limits).
  for (const id of oldIds.slice(0, 20)) {
    try {
      await bot.helpers.deleteMessage(channelId, id as never);
      deleted += 1;
    } catch {
      // missing perms or already gone
    }
  }

  return deleted;
}

/** Sets a member's nickname. Pass null to reset it. */
export async function setNickname(
  bot: Bot,
  guildId: string,
  userId: string,
  nickname: string | null,
  _reason: string,
): Promise<void> {
  await bot.helpers.editMember(guildId, userId, { nick: nickname } as never);
}

/** The guild's name and member count. */
export async function guildInfo(bot: Bot, guildId: string): Promise<{ name: string; memberCount: number } | null> {
  const guild = await remember(`guild:${guildId}`, 60, () =>
    withRetries(`getGuild:${guildId}`, () => bot.helpers.getGuild(guildId)),
  ).catch(() => null);
  if (!guild) return null;
  const g = guild as { name?: string; memberCount?: number; approximateMemberCount?: number };
  return {
    name: g.name ?? "this server",
    memberCount: g.memberCount ?? g.approximateMemberCount ?? 0,
  };
}

/**
 * Computes a member's guild-wide permissions from their roles.
 * The @everyone role id equals the guild id.
 * Guild owners are treated as having Administrator.
 */
export async function memberPermissions(
  bot: Bot,
  guildId: string,
  roleIds: (string | bigint)[],
  userId?: string,
): Promise<bigint> {
  // Guild owner always has full power in Discord's model.
  if (userId) {
    try {
      const guild = await bot.helpers.getGuild(guildId).catch(() => null) as { ownerId?: string | bigint } | null;
      if (guild && String(guild.ownerId) === String(userId)) {
        return ~0n; // all bits
      }
    } catch {
      // continue with role calc
    }
  }

  let rolesList = roleIds.map(String).filter(Boolean);

  // If the gateway message omitted roles, fetch the member.
  if (userId && rolesList.length === 0) {
    try {
      const member = await bot.helpers.getMember(guildId, userId).catch(() => null) as { roles?: (string | bigint)[] } | null;
      if (member?.roles?.length) rolesList = member.roles.map(String);
    } catch {
      // ignore
    }
  }

  const roles = await bot.helpers.getRoles(guildId);
  const wanted = new Set([guildId, ...rolesList]);

  let perms = 0n;
  for (const role of roles as unknown as { id: bigint | string; permissions: bigint | string }[]) {
    if (wanted.has(String(role.id))) {
      perms |= BigInt(String(role.permissions));
    }
  }
  return perms;
}

/** Lock or unlock a text channel without discarding its other permission overwrites. */
export async function setChannelLocked(
  bot: Bot,
  guildId: string,
  channelId: string,
  locked: boolean,
): Promise<void> {
  const raw = await bot.helpers.getChannel(channelId);
  const channel = raw as unknown as {
    permissionOverwrites?: Array<{ id: string | bigint; type: number; allow: string | bigint; deny: string | bigint }>;
  };
  const overwrites = [...(channel.permissionOverwrites ?? [])];
  const index = overwrites.findIndex((entry) => String(entry.id) === guildId && Number(entry.type) === 0);
  const everyone = index >= 0
    ? { ...overwrites[index] }
    : { id: guildId, type: 0, allow: "0", deny: "0" };

  const sendMessages = 1n << 11n;
  let allow = BigInt(String(everyone.allow ?? "0"));
  let deny = BigInt(String(everyone.deny ?? "0"));
  // Inherit SEND_MESSAGES when unlocked; explicitly deny it when locked.
  allow &= ~sendMessages;
  deny = locked ? (deny | sendMessages) : (deny & ~sendMessages);
  const updated = { ...everyone, id: guildId, type: 0, allow: allow.toString(), deny: deny.toString() };
  if (index >= 0) overwrites[index] = updated;
  else overwrites.push(updated);

  await bot.helpers.editChannel(channelId, { permissionOverwrites: overwrites } as never);
}
