import type { Bot } from "@discordeno/bot";

/** Discord application command option types. */
export const OptionType = {
  SUB_COMMAND: 1,
  STRING: 3,
  INTEGER: 4,
  BOOLEAN: 5,
  USER: 6,
} as const;

/** Permission bits, checked against the invoking member at runtime. */
export const PERM = {
  ADMINISTRATOR: 1n << 3n,
  KICK_MEMBERS: 1n << 1n,
  BAN_MEMBERS: 1n << 2n,
  MANAGE_MESSAGES: 1n << 13n,
  MODERATE_MEMBERS: 1n << 40n,
  MANAGE_NICKNAMES: 1n << 27n,
  MANAGE_CHANNELS: 1n << 4n,
  MANAGE_GUILD: 1n << 5n,
} as const;

export interface OptionChoice {
  name: string;
  value: string;
}

export interface OptionDef {
  name: string;
  description: string;
  type: number;
  required?: boolean;
  choices?: OptionChoice[];
  min_value?: number;
  max_value?: number;
}

/** A single subcommand, e.g. `,balance`. */
export interface Command {
  name: string;
  description: string;
  options?: OptionDef[];
  execute(ctx: Ctx): Promise<void>;
}

/** A category that holds up to 25 subcommands. */
export interface Group {
  name: string;
  description: string;
  /** Hides the whole group in DMs. */
  guildOnly?: boolean;
  subcommands: Command[];
}

export interface ResolvedUser {
  id: string;
  username: string;
  bot: boolean;
  avatar: string | null;
}

export interface ReplyOptions {
  content?: string;
  embeds?: Record<string, unknown>[];
  components?: Record<string, unknown>[];
  ephemeral?: boolean;
}

/** Everything a subcommand needs. Works the same for prefix and slash input. */
export interface Ctx {
  bot: Bot;
  userId: string;
  username: string;
  /** The invoking user's avatar URL. */
  userAvatar: string;
  guildId?: string;
  channelId?: string;
  /** Time the command was sent, in ms since epoch. */
  createdAt: number;
  reply(input: string | ReplyOptions): Promise<void>;
  str(name: string): string | undefined;
  int(name: string): number | undefined;
  user(name: string): ResolvedUser | undefined;
  /** The mentioned user, or the command user if none was given. */
  userOrSelf(name: string): ResolvedUser;
  /** True if the invoking member has the permission bit (or Administrator). */
  hasPermission(bit: bigint): boolean;
  /** The guild's name and member count, or null outside a server. */
  guildInfo(): Promise<{ name: string; memberCount: number } | null>;
}
