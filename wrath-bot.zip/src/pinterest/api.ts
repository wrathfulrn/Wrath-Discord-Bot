/*
 * Pinterest API v5 client. It only reads the boards and pins of the account
 * that owns PINTEREST_ACCESS_TOKEN, which is the access the trial tier allows.
 */

const API = "https://api.pinterest.com/v5";
const CACHE_MS = 60 * 60 * 1000;

export class PinterestError extends Error {}

export interface Pin {
  id: string;
  title: string;
  imageUrl: string;
}

export interface Board {
  id: string;
  name: string;
}

interface BoardListResponse {
  items?: { id: string; name: string }[];
}

interface PinListResponse {
  items?: {
    id: string;
    title?: string | null;
    description?: string | null;
    media?: { images?: Record<string, { url?: string } | undefined> };
  }[];
}

const pinCache = new Map<string, { at: number; pins: Pin[] }>();

function accessToken(): string {
  const token = process.env.PINTEREST_ACCESS_TOKEN;
  if (!token) throw new PinterestError("PINTEREST_ACCESS_TOKEN is not set in .env.");
  return token;
}

async function get<T>(path: string, query: Record<string, string> = {}): Promise<T> {
  const url = new URL(API + path);
  for (const [key, value] of Object.entries(query)) {
    url.searchParams.set(key, value);
  }

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken()}` },
  });

  if (res.status === 401) {
    throw new PinterestError("Pinterest rejected the access token. It may have expired. Generate a new one.");
  }
  if (!res.ok) {
    throw new PinterestError(`Pinterest returned an error (${res.status}).`);
  }
  return (await res.json()) as T;
}

/** The account's boards, so the board ID can be copied into .env. */
export async function listBoards(): Promise<Board[]> {
  const data = await get<BoardListResponse>("/boards", { page_size: "25" });
  return (data.items ?? []).map((b) => ({ id: b.id, name: b.name }));
}

/** Picks the largest image size the pin has. */
function pickImage(images: Record<string, { url?: string } | undefined> | undefined): string {
  if (!images) return "";
  for (const size of ["originals", "1200x", "600x", "400x300"]) {
    const url = images[size]?.url;
    if (url) return url;
  }
  return "";
}

/** Pins on one board that have an image. Results are cached for an hour. */
export async function boardPins(boardId: string): Promise<Pin[]> {
  const cached = pinCache.get(boardId);
  if (cached && Date.now() - cached.at < CACHE_MS) return cached.pins;

  const data = await get<PinListResponse>(`/boards/${encodeURIComponent(boardId)}/pins`, {
    page_size: "25",
  });

  const pins: Pin[] = (data.items ?? [])
    .map((p) => ({
      id: p.id,
      title: (p.title || p.description || "Untitled pin").slice(0, 256),
      imageUrl: pickImage(p.media?.images),
    }))
    .filter((p) => p.imageUrl !== "");

  pinCache.set(boardId, { at: Date.now(), pins });
  return pins;
}
