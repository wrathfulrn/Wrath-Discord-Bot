export interface Recipe {
  id: string;
  name: string;
  emoji: string;
  ingredients: Record<string, number>;
  output: string;
}

export const RECIPES: Recipe[] = [
  { id: "sandwich", name: "Sandwich", emoji: "🥪", ingredients: { bread: 1, cheese: 1 }, output: "sandwich" },
  { id: "fish_meal", name: "Fish meal", emoji: "🍱", ingredients: { fish: 1, bread: 1 }, output: "fish_meal" },
  { id: "iron_sword", name: "Crafted sword", emoji: "⚔️", ingredients: { iron: 3, wood: 1 }, output: "sword" },
  { id: "wood_shield", name: "Crafted shield", emoji: "🛡️", ingredients: { wood: 4, stone: 1 }, output: "shield" },
  { id: "ring_craft", name: "Crafted ring", emoji: "💍", ingredients: { gold_ore: 1, gem: 1 }, output: "ring" },
  { id: "potion_brew", name: "Brewed potion", emoji: "🧪", ingredients: { apple: 2, fish: 1 }, output: "potion" },
  { id: "cake_bake", name: "Baked cake", emoji: "🎂", ingredients: { bread: 2, apple: 2 }, output: "cake" },
  { id: "amulet_craft", name: "Crafted amulet", emoji: "🔮", ingredients: { gem: 2, gold_ore: 1 }, output: "amulet" },
];

// Ensure recipe outputs exist as shop items (virtual craft-only products)
export const RECIPE_CHOICES = RECIPES.map((r) => ({ name: r.name, value: r.id }));

export function findRecipe(raw: string | null | undefined): Recipe | undefined {
  if (!raw) return undefined;
  const q = raw.trim().toLowerCase();
  return RECIPES.find((r) => r.id === q || r.name.toLowerCase() === q);
}
