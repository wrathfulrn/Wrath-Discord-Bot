export interface Crop {
  id: string;
  name: string;
  emoji: string;
  growMs: number;
  sellPrice: number;
}

export const CROPS: Crop[] = [
  { id: "wheat", name: "Wheat", emoji: "🌾", growMs: 5 * 60 * 1000, sellPrice: 25 },
  { id: "carrot", name: "Carrot", emoji: "🥕", growMs: 8 * 60 * 1000, sellPrice: 35 },
  { id: "potato", name: "Potato", emoji: "🥔", growMs: 10 * 60 * 1000, sellPrice: 40 },
  { id: "corn", name: "Corn", emoji: "🌽", growMs: 12 * 60 * 1000, sellPrice: 50 },
  { id: "tomato", name: "Tomato", emoji: "🍅", growMs: 15 * 60 * 1000, sellPrice: 55 },
  { id: "strawberry", name: "Strawberry", emoji: "🍓", growMs: 20 * 60 * 1000, sellPrice: 70 },
  { id: "pumpkin", name: "Pumpkin", emoji: "🎃", growMs: 30 * 60 * 1000, sellPrice: 100 },
  { id: "grape", name: "Grape", emoji: "🍇", growMs: 25 * 60 * 1000, sellPrice: 85 },
  { id: "melon", name: "Melon", emoji: "🍈", growMs: 35 * 60 * 1000, sellPrice: 120 },
  { id: "truffle", name: "Truffle", emoji: "🍄", growMs: 60 * 60 * 1000, sellPrice: 200 },
];

export const CROP_CHOICES = CROPS.map((c) => ({ name: c.name, value: c.id }));

export function findCrop(raw: string | null | undefined): Crop | undefined {
  if (!raw) return undefined;
  const q = raw.trim().toLowerCase();
  return CROPS.find((c) => c.id === q || c.name.toLowerCase() === q);
}
