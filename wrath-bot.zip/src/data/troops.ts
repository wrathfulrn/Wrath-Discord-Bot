export interface Troop {
  id: string;
  name: string;
  emoji: string;
  cost: number;
  power: number;
}

export const TROOPS: Troop[] = [
  { id: "militia", name: "Militia", emoji: "🗡️", cost: 50, power: 5 },
  { id: "archer", name: "Archer", emoji: "🏹", cost: 80, power: 8 },
  { id: "knight", name: "Knight", emoji: "🛡️", cost: 150, power: 15 },
  { id: "cavalry", name: "Cavalry", emoji: "🐴", cost: 200, power: 20 },
  { id: "mage", name: "Battle mage", emoji: "🪄", cost: 250, power: 25 },
  { id: "siege", name: "Siege engine", emoji: "🏰", cost: 400, power: 40 },
  { id: "dragon_rider", name: "Dragon rider", emoji: "🐉", cost: 800, power: 80 },
];

export const TROOP_CHOICES = TROOPS.map((t) => ({ name: t.name, value: t.id }));

export const TRAINING_COST = 10; // coins per power point
export const BATTLE_COOLDOWN_MS = 30 * 60 * 1000;
export const LOOT_SHARE = 0.1;
export const MAX_LOOT = 500;

export function findTroop(raw: string | null | undefined): Troop | undefined {
  if (!raw) return undefined;
  const q = raw.trim().toLowerCase();
  return TROOPS.find((t) => t.id === q || t.name.toLowerCase() === q);
}
