export interface Job {
  id: string;
  name: string;
  emoji: string;
  minPay: number;
  maxPay: number;
  cooldownMs: number;
  requiredXp: number;
}

export const JOBS: Job[] = [
  { id: "cashier", name: "Cashier", emoji: "🧾", minPay: 25, maxPay: 50, cooldownMs: 30 * 60 * 1000, requiredXp: 0 },
  { id: "farmer", name: "Farmer", emoji: "🧑‍🌾", minPay: 35, maxPay: 70, cooldownMs: 45 * 60 * 1000, requiredXp: 0 },
  { id: "fisher", name: "Fisher", emoji: "🎣", minPay: 40, maxPay: 85, cooldownMs: 45 * 60 * 1000, requiredXp: 25 },
  { id: "miner", name: "Miner", emoji: "⛏️", minPay: 50, maxPay: 100, cooldownMs: 60 * 60 * 1000, requiredXp: 50 },
  { id: "cook", name: "Cook", emoji: "👨‍🍳", minPay: 45, maxPay: 90, cooldownMs: 40 * 60 * 1000, requiredXp: 40 },
  { id: "courier", name: "Courier", emoji: "📦", minPay: 35, maxPay: 75, cooldownMs: 35 * 60 * 1000, requiredXp: 20 },
  { id: "guard", name: "Guard", emoji: "🛡️", minPay: 60, maxPay: 110, cooldownMs: 60 * 60 * 1000, requiredXp: 80 },
  { id: "blacksmith", name: "Blacksmith", emoji: "⚒️", minPay: 70, maxPay: 140, cooldownMs: 75 * 60 * 1000, requiredXp: 120 },
  { id: "merchant", name: "Merchant", emoji: "🛒", minPay: 65, maxPay: 130, cooldownMs: 50 * 60 * 1000, requiredXp: 100 },
  { id: "mage", name: "Mage apprentice", emoji: "🪄", minPay: 80, maxPay: 160, cooldownMs: 90 * 60 * 1000, requiredXp: 150 },
  { id: "captain", name: "Ship captain", emoji: "⚓", minPay: 100, maxPay: 200, cooldownMs: 2 * 60 * 60 * 1000, requiredXp: 220 },
  { id: "ceo", name: "CEO", emoji: "💼", minPay: 150, maxPay: 300, cooldownMs: 3 * 60 * 60 * 1000, requiredXp: 400 },
];

export const JOB_CHOICES = JOBS.map((j) => ({ name: j.name, value: j.id }));

export function findJob(raw: string | null | undefined): Job | undefined {
  if (!raw) return undefined;
  const q = raw.trim().toLowerCase();
  return JOBS.find((j) => j.id === q || j.name.toLowerCase() === q);
}
