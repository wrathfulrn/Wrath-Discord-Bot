export interface ShopItem {
  id: string;
  name: string;
  emoji: string;
  price: number;
  sellPrice: number;
  description: string;
}

export const SHOP: ShopItem[] = [
  { id: "apple", name: "Apple", emoji: "🍎", price: 30, sellPrice: 12, description: "Crisp fruit. Crafting ingredient." },
  { id: "bread", name: "Bread", emoji: "🍞", price: 40, sellPrice: 15, description: "Fresh loaf." },
  { id: "cheese", name: "Cheese", emoji: "🧀", price: 55, sellPrice: 22, description: "Sharp and aged." },
  { id: "fish", name: "Fish", emoji: "🐟", price: 60, sellPrice: 25, description: "Caught this morning." },
  { id: "wood", name: "Wood", emoji: "🪵", price: 25, sellPrice: 10, description: "Basic crafting material." },
  { id: "stone", name: "Stone", emoji: "🪨", price: 20, sellPrice: 8, description: "Hard and heavy." },
  { id: "iron", name: "Iron", emoji: "⛓️", price: 80, sellPrice: 35, description: "Smelted metal bar." },
  { id: "gold_ore", name: "Gold ore", emoji: "✨", price: 200, sellPrice: 90, description: "Shiny ore." },
  { id: "potion", name: "Health potion", emoji: "🧪", price: 120, sellPrice: 40, description: "Restores energy." },
  { id: "sword", name: "Iron sword", emoji: "⚔️", price: 350, sellPrice: 140, description: "A sharp blade." },
  { id: "shield", name: "Wooden shield", emoji: "🛡️", price: 280, sellPrice: 110, description: "Basic protection." },
  { id: "pickaxe", name: "Pickaxe", emoji: "⛏️", price: 220, sellPrice: 90, description: "Mine faster." },
  { id: "fishing_rod", name: "Fishing rod", emoji: "🎣", price: 180, sellPrice: 70, description: "Cast a line." },
  { id: "seed_bag", name: "Seed bag", emoji: "🌱", price: 50, sellPrice: 15, description: "Assorted seeds." },
  { id: "gem", name: "Gem", emoji: "💎", price: 500, sellPrice: 250, description: "Rare jewel." },
  { id: "ring", name: "Silver ring", emoji: "💍", price: 400, sellPrice: 160, description: "Simple jewelry." },
  { id: "amulet", name: "Amulet", emoji: "🔮", price: 600, sellPrice: 240, description: "Slightly magical." },
  { id: "ticket", name: "Lottery ticket", emoji: "🎫", price: 100, sellPrice: 20, description: "Maybe lucky." },
  { id: "coffee", name: "Coffee", emoji: "☕", price: 35, sellPrice: 10, description: "Wake up boost." },
  { id: "cake", name: "Cake", emoji: "🎂", price: 90, sellPrice: 35, description: "Celebration food." },
  { id: "sandwich", name: "Sandwich", emoji: "🥪", price: 70, sellPrice: 30, description: "Crafted snack." },
  { id: "fish_meal", name: "Fish meal", emoji: "🍱", price: 90, sellPrice: 40, description: "Crafted meal." },
];

export const ITEM_CHOICES = SHOP.slice(0, 25).map((i) => ({ name: i.name, value: i.id }));

export function findItem(raw: string | null | undefined): ShopItem | undefined {
  if (!raw) return undefined;
  const q = raw.trim().toLowerCase();
  return SHOP.find((i) => i.id === q || i.name.toLowerCase() === q);
}
