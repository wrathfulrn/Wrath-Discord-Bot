# Wrath

A multipurpose Discord bot built with **TypeScript** and **Discordeno**.

Prefix by default: `,`

## Features

- **Moderation** — kick, ban, purge, timeouts, lock, slowmode, warns  
- **Security** — automod, antiraid, antinuke config, logging, counting  
- **Server tools** — welcome/goodbye, setup, aliases, bump reminders, announce  
- **Roles** — reaction roles, fake permissions, booster role  
- **Levels** — XP and rank  
- **Economy** — balance, work, daily, shop, jobs, farm, pets, war, lottery  
- **Music** — queue + transition planner (Lavalink optional)  
- **AI** — `,ask` via Gemini  
- **Scripts & workflows** — named embeds and simple automations  
- **Last.fm** — `,fm` (optional API key)  
- **Large command pack** — data-driven utility catalog  

## Requirements

- Node.js 20+
- A Discord bot token ([Discord Developer Portal](https://discord.com/developers/applications))

## Setup

```bash
cp .env.example .env
# edit .env — at least DISCORD_TOKEN and CLIENT_ID

npm install
npm run build
npm start
```

Optional:

```env
GEMINI_API_KEY=
LAVALINK_HOST=
LAVALINK_PASSWORD=
LASTFM_API_KEY=
OWNER_ID=
PREFIX=,
BOT_NAME=Wrath
```

Deploy slash command groups (if you use them):

```bash
npm run deploy
```

## Project layout

```
src/
  commands/     # command groups
  modules/      # background systems (automod, levels, voice, …)
  db/           # JSON key-value store
  music/        # queue + transition planner
  packs/        # large data-driven command catalog
  events/       # gateway handlers
```

## License

Use and modify for your own servers. Add a license file before publishing if you want formal terms.
