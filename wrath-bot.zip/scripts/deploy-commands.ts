import "dotenv/config";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { config } from "../src/config.js";
import { loadGroups, validateGroups } from "../src/loader.js";
import { OptionType } from "../src/types.js";
import { packSlashChunks, packCommands } from "../src/packs/index.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function main(): Promise<void> {
  if (!config.token || !config.clientId) {
    console.error("Set DISCORD_TOKEN and CLIENT_ID in your .env file.");
    process.exit(1);
  }

  const folderGroups = await loadGroups(path.join(__dirname, "..", "src", "commands"));
  validateGroups(folderGroups);

  const reserved = new Set<string>();
  for (const g of folderGroups) for (const s of g.subcommands) reserved.add(s.name);

  const packChunks = packSlashChunks().map((g) => ({
    ...g,
    subcommands: g.subcommands.filter((c) => !reserved.has(c.name)),
  })).filter((g) => g.subcommands.length > 0);

  // Folder groups first (core), then pack slash chunks (economy, economy-2, ...)
  const groups = [...folderGroups, ...packChunks];
  if (groups.length > 100) {
    console.warn(`Warning: ${groups.length} top-level slash commands (Discord max 100). Trimming pack chunks.`);
  }
  const limited = groups.slice(0, 100);

  const payload = limited.map((g) => ({
    name: g.name.slice(0, 32),
    description: g.description.slice(0, 100),
    type: 1,
    options: g.subcommands.slice(0, 25).map((s) => ({
      type: OptionType.SUB_COMMAND,
      name: s.name.slice(0, 32),
      description: s.description.slice(0, 100),
      options: s.options ?? [],
    })),
    dm_permission: g.guildOnly ? false : undefined,
  }));

  const base = `https://discord.com/api/v10/applications/${config.clientId}`;
  const url = config.guildId ? `${base}/guilds/${config.guildId}/commands` : `${base}/commands`;

  const res = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `Bot ${config.token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    console.error("Deploy failed:", res.status, await res.text());
    process.exit(1);
  }
  const packCount = packCommands().filter((c) => !reserved.has(c.name)).length;
  console.log(`Deployed ${payload.length} slash groups (${packCount} pack commands available via prefix).`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
