# Music

## What ships in this repo

- Queue commands: play, skip, stop, queue, nowplaying, automix toggle  
- A **transition planner** that scores pairs (tempo, key, energy, structure) and picks a strategy  
- Lavalink v4 `loadtracks` helper when `LAVALINK_HOST` is set  

## Audio

1. Run [Lavalink v4](https://lavalink.dev/).
2. Set:

```env
LAVALINK_HOST=127.0.0.1:2333
LAVALINK_PASSWORD=youshallnotpass
```

3. Wire voice state → Lavalink player session on your host if you need live audio.

Stock Lavalink is one deck per connection. Overlapping crossfades need a custom audio node.
